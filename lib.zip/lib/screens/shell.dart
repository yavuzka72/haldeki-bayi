import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/cart.dart';

class ShellScaffold extends StatelessWidget {
  final Widget child;
  final int currentIndex;
  const ShellScaffold({super.key, required this.child, required this.currentIndex});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isWide = width >= 1000;

    // Cart’ı dinle (badge & renk için)
    final cart = context.watch<Cart>();
    final lineCount = cart.lines; // kalem sayısı
    final hasItems = lineCount > 0;

    return Scaffold(
      appBar: AppBar(title: const Text('Haldeki Tedarikçi')),
      body: Row(
        children: [
          if (isWide)
            NavigationRail(
              labelType: NavigationRailLabelType.all,
              minWidth: 92,
              useIndicator: true,
              groupAlignment: -1.0,
              // ⬇️ 0..4 (5 sekme)
              selectedIndex: currentIndex.clamp(0, 4),
              leading: const _RailHeader(title: 'Haldeki Tedarikçi'),
              destinations: [
                const NavigationRailDestination(
                  icon: Icon(Icons.dashboard_outlined),
                  selectedIcon: Icon(Icons.dashboard),
                  label: Text('Ana Sayfa'),
                ),
                const NavigationRailDestination(
                  icon: Icon(Icons.store_mall_directory_outlined),
                  selectedIcon: Icon(Icons.store_mall_directory),
                  label: Text('Ürünler'),
                ),
                // --- SEPET: kırmızı + badge ---
                NavigationRailDestination(
                  icon: _BadgeIcon(
                    count: lineCount,
                    child: Icon(
                      Icons.price_change_rounded,
                      color: hasItems ? Colors.red : null,
                    ),
                  ),
                  selectedIcon: _BadgeIcon(
                    count: lineCount,
                    child: Icon(
                      Icons.price_change_rounded,
                      color: hasItems ? Colors.red : null,
                    ),
                  ),
                  label: const Text('Fiyat Listesi'),
                ),
                const NavigationRailDestination(
                  icon: Icon(Icons.receipt_long_outlined),
                  selectedIcon: Icon(Icons.receipt_long),
                  label: Text('Gelen Siparişler'),
                ),
                // ⬇️ YENİ: Tedarikçiler
                const NavigationRailDestination(
                  icon: Icon(Icons.factory_outlined),
                  selectedIcon: Icon(Icons.factory),
                  label: Text('Profil'),
                ),
              ],
              onDestinationSelected: (i) {
                switch (i) {
                  case 0: context.go('/dashboard'); break;
                  case 1: context.go('/market'); break;
                  case 2: context.go('/cart'); break;
                  case 3: context.go('/orders'); break;
                  case 4: context.go('/suppliers'); break; // ⬅️ yeni
                }
              },
            )
          else
            const SizedBox(),
          Expanded(child: child),
        ],
      ),
      bottomNavigationBar: isWide
          ? null
          : NavigationBar(
              // ⬇️ 0..4 (5 sekme)
              selectedIndex: currentIndex.clamp(0, 4),
              destinations: [
                const NavigationDestination(
                  icon: Icon(Icons.dashboard_outlined),
                  selectedIcon: Icon(Icons.dashboard),
                  label: 'Dashboard',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.store_mall_directory_outlined),
                  selectedIcon: Icon(Icons.store_mall_directory),
                  label: 'Market',
                ),
                // --- SEPET: kırmızı + badge ---
                NavigationDestination(
                  icon: _BadgeIcon(
                    count: lineCount,
                    child: Icon(
                      Icons.shopping_cart_outlined,
                      color: hasItems ? Colors.red : null,
                    ),
                  ),
                  selectedIcon: _BadgeIcon(
                    count: lineCount,
                    child: Icon(
                      Icons.shopping_cart,
                      color: hasItems ? Colors.red : null,
                    ),
                  ),
                  label: 'Sepet',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.receipt_long_outlined),
                  selectedIcon: Icon(Icons.receipt_long),
                  label: 'Siparişler',
                ),
                // ⬇️ YENİ: Tedarikçiler
                const NavigationDestination(
                  icon: Icon(Icons.factory_outlined),
                  selectedIcon: Icon(Icons.factory),
                  label: 'Profile',
                ),
              ],
              onDestinationSelected: (i) {
                switch (i) {
                  case 0: context.go('/dashboard'); break;
                  case 1: context.go('/market'); break;
                  case 2: context.go('/cart'); break;
                  case 3: context.go('/orders'); break;
                  case 4: context.go('/suppliers'); break; // ⬅️ yeni
                }
              },
            ),
    );
  }
}

class _RailHeader extends StatelessWidget {
  const _RailHeader({required this.title, this.logoAsset});
  final String title;
  final String? logoAsset;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final avatar = Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(color: cs.primary.withOpacity(.12), shape: BoxShape.circle),
      alignment: Alignment.center,
      child: logoAsset == null
          ? Icon(Icons.apps, color: cs.primary)
          : ClipOval(child: Image.asset(logoAsset!, width: 44, height: 44, fit: BoxFit.cover)),
    );

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Column(
        children: [
          avatar,
          const SizedBox(height: 8),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

/// Basit badge sarmalayıcı (Material 3 Badge yerine sürüm uyumlu)
class _BadgeIcon extends StatelessWidget {
  final int count;
  final Widget child;
  const _BadgeIcon({required this.count, required this.child});

  @override
  Widget build(BuildContext context) {
    if (count <= 0) return child;

    return Stack(
      clipBehavior: Clip.none,
      children: [
        child,
        Positioned(
          right: -6,
          top: -4,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
            decoration: const BoxDecoration(
              color: Colors.red,
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
            child: Text(
              count.toString(),
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.bold,
                height: 1.0,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
