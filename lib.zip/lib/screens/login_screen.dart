import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:dio/dio.dart';

import '../services/api_client.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _obscure = true;
  bool _loading = false;


  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);

    final api = context.read<ApiClient>();
    try {
      final res = await api.login(_email.text.trim(), _password.text);
      final data = res.data;
      String? token;
      if (data is Map) {
        token = (data['token'] ?? data['access_token'] ?? data['data']?['token'])?.toString();
       api.currentUserId  = res.data['id']; 
       print(api.currentUserId.toString());

      }
      if (token == null || token.isEmpty) {
        throw DioException(requestOptions: res.requestOptions, error: 'Token alınamadı');
      }
      await api.setToken(token);
      if (!mounted) return;
      context.go('/dashboard');
    } on DioException catch (e) {
      final msg = e.response?.data is Map && e.response!.data['message'] != null
          ? e.response!.data['message'].toString()
          : (e.message ?? 'Giriş başarısız.');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Beklenmeyen bir hata oluştu.')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      body: LayoutBuilder(
        builder: (context, box) {
          final wide = box.maxWidth >= 980;

          return Stack(
            fit: StackFit.expand,
            children: [
              // --- Background gradient + blobs
              DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      cs.primary.withOpacity(.10),
                      cs.primaryContainer.withOpacity(.06),
                      cs.surface,
                    ],
                  ),
                ),
              ),
              _Blob(top: -80, left: -60, size: 260, color: cs.primary.withOpacity(.25)),
              _Blob(bottom: -60, right: -40, size: 220, color: cs.secondary.withOpacity(.20)),
              _Blob(top: 120, right: -50, size: 140, color: cs.tertiary.withOpacity(.16)),

              // --- Centered glass card
              Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1100),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(24),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                      child: Container(
                        decoration: BoxDecoration(
                          color: cs.surface.withOpacity(.70),
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: cs.outlineVariant.withOpacity(.6)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(.06),
                              blurRadius: 24,
                              offset: const Offset(0, 12),
                            ),
                          ],
                        ),
                        padding: const EdgeInsets.all(18),
                        child: SizedBox(
                          height: wide ? 500 : null,
                          child: Row(
                            children: [
                              if (wide)
                                // ----- Left brand panel
                                Expanded(
                                  child: _BrandPanel(),
                                ),

                              // Divider (wide)
                              if (wide)
                                VerticalDivider(
                                  width: 1,
                                  thickness: 1,
                                  color: cs.outlineVariant,
                                ),

                              // ----- Right: Form
                              Expanded(
                                child: SingleChildScrollView(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: wide ? 36 : 20, vertical: 22),
                                  child: Form(
                                    key: _form,
                                    child: AutofillGroup(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                        children: [
                                          if (!wide) ...[
                                            const SizedBox(height: 4),
                                            _WordmarkInline(),
                                            const SizedBox(height: 18),
                                          ],
                                          Text(
                                            'Hesabınıza giriş yapın',
                                            style: Theme.of(context).textTheme.titleLarge,
                                          ),
                                          const SizedBox(height: 6),
                                          Text(
                                            'E-posta ve şifrenizle devam edin.',
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodyMedium
                                                ?.copyWith(color: cs.onSurfaceVariant),
                                          ),
                                          const SizedBox(height: 22),

                                          // Email
                                          TextFormField(
                                            controller: _email,
                                            decoration: InputDecoration(
                                              labelText: 'E-posta',
                                              prefixIcon:
                                                  const Icon(Icons.mail_outline_rounded, size: 20),
                                              filled: true,
                                              fillColor: cs.surfaceVariant.withOpacity(.35),
                                              border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(14),
                                              ),
                                            ),
                                            keyboardType: TextInputType.emailAddress,
                                            textInputAction: TextInputAction.next,
                                            autofillHints: const [
                                              AutofillHints.username,
                                              AutofillHints.email
                                            ],
                                            validator: (v) => (v == null || !v.contains('@'))
                                                ? 'Geçerli bir e-posta girin'
                                                : null,
                                          ),
                                          const SizedBox(height: 12),

                                          // Password
                                          TextFormField(
                                            controller: _password,
                                            obscureText: _obscure,
                                            decoration: InputDecoration(
                                              labelText: 'Şifre',
                                              prefixIcon:
                                                  const Icon(Icons.lock_outline_rounded, size: 20),
                                              suffixIcon: IconButton(
                                                onPressed: () =>
                                                    setState(() => _obscure = !_obscure),
                                                icon: Icon(
                                                  _obscure
                                                      ? Icons.visibility_outlined
                                                      : Icons.visibility_off_outlined,
                                                ),
                                              ),
                                              filled: true,
                                              fillColor: cs.surfaceVariant.withOpacity(.35),
                                              border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(14),
                                              ),
                                            ),
                                            autofillHints: const [AutofillHints.password],
                                            onFieldSubmitted: (_) => _submit(),
                                            validator: (v) =>
                                                (v == null || v.length < 4) ? 'Şifre çok kısa' : null,
                                          ),
                                          const SizedBox(height: 4),
                                          Align(
                                            alignment: Alignment.centerRight,
                                            child: TextButton(
                                              onPressed: _loading ? null : () {},
                                              child: const Text('Şifremi unuttum'),
                                            ),
                                          ),
                                          const SizedBox(height: 8),

                                          // Buttons
                                          SizedBox(
                                            height: 48,
                                            child: FilledButton(
                                              onPressed: _loading ? null : _submit,
                                              child: _loading
                                                  ? const SizedBox(
                                                      height: 20,
                                                      width: 20,
                                                      child: CircularProgressIndicator(
                                                          strokeWidth: 2),
                                                    )
                                                  : const Text('Giriş'),
                                            ),
                                          ),
                                          const SizedBox(height: 10),
                                          SizedBox(
                                            height: 46,
                                            child: OutlinedButton.icon(
                                              icon: const Icon(Icons.explore_outlined, size: 18),
                                              onPressed: _loading
                                                  ? null
                                                  : () => context.go('/dashboard'),
                                              label: const Text('Misafir olarak devam et'),
                                            ),
                                          ),
                                          const SizedBox(height: 14),
                                          Text(
                                            'Giriş yaparak koşulları kabul etmiş olursunuz.',
                                            textAlign: TextAlign.center,
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodySmall
                                                ?.copyWith(color: cs.onSurfaceVariant),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Sol marka paneli (geniş ekranda)
class _BrandPanel extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 26),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [cs.primary, cs.primaryContainer],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      margin: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Logo/wordmark
          const _WordmarkOnColor(),
          const SizedBox(height: 18),
          Text(
            'İşletme paneli',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(color: cs.onPrimary, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          Text(
            'Siparişleri görün, durum güncelleyin ve stoğu yönetin.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: cs.onPrimary),
          ),
          const Spacer(),
          _Bullet(icon: Icons.local_shipping_outlined, text: 'Canlı durum takibi', onPrimary: true),
          _Bullet(icon: Icons.inventory_2_outlined, text: 'Hızlı stok yönetimi', onPrimary: true),
          _Bullet(icon: Icons.receipt_long_outlined, text: 'Detaylı siparişler', onPrimary: true),
        ],
      ),
    );
  }
}

/// Açık zeminde görünen inline wordmark (logo yerine)
class _WordmarkInline extends StatelessWidget {
  const _WordmarkInline();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: cs.primary.withOpacity(.12),
          ),
          alignment: Alignment.center,
          child: Icon(Icons.eco_rounded, color: cs.primary),
        ),
        const SizedBox(width: 12),
        ShaderMask(
          shaderCallback: (r) => LinearGradient(
            colors: [cs.primary, cs.tertiary],
          ).createShader(r),
          child: Text(
            'Haldeki',
            style:
                Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.w800, fontStyle: FontStyle.italic),
          ),
        ),
      ],
    );
  }
}

/// Koyu/renkli panel üstü için wordmark
class _WordmarkOnColor extends StatelessWidget {
  const _WordmarkOnColor();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Row(
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white),
          alignment: Alignment.center,
          child: Icon(Icons.eco_rounded, color: cs.primary),
        ),
        const SizedBox(width: 12),
        Text(
          'Haldeki.com',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: cs.onPrimary,
                fontWeight: FontWeight.w800,
                fontStyle: FontStyle.italic,
              ),
        ),
      ],
    );
  }
}

class _Bullet extends StatelessWidget {
  const _Bullet({required this.icon, required this.text, this.onPrimary = false});
  final IconData icon;
  final String text;
  final bool onPrimary;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final color = onPrimary ? cs.onPrimary : cs.primary;
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: onPrimary
                  ? Theme.of(context).textTheme.bodyMedium?.copyWith(color: cs.onPrimary)
                  : null,
            ),
          ),
        ],
      ),
    );
  }
}

/// Arka plan dekoratif “blob”
class _Blob extends StatelessWidget {
  const _Blob({
    this.top,
    this.left,
    this.right,
    this.bottom,
    required this.size,
    required this.color,
  });

  final double? top, left, right, bottom;
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: top,
      left: left,
      right: right,
      bottom: bottom,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color, color.withOpacity(0)],
          ),
        ),
      ),
    );
  }
}
