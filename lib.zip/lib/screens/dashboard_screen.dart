// lib/screens/dashboard_screen.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:dio/dio.dart' show DioException;

import '../config.dart';
import '../services/api_client.dart';
import '../models/order.dart';
import '../utils/format.dart';
import '../widgets/donut_chart.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  // ---- DATA ----
  List<Order> _all = const <Order>[];
  List<Order> _visible = const <Order>[];

  // ---- UI state ----
  final _search = TextEditingController();
  String? _statusFilter;
  int? _sortColumnIndex;
  bool _sortAscending = true;

  bool _topSortByRevenue = false;
  List<_TopStat> _topByQty = [];
  List<_TopStat> _topByRevenue = [];

  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _recomputeTop();
    Future.microtask(_loadOrders);
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  // ---------- STATUS HELPERS ----------
  String _normStatus(String? raw) {
    final s = (raw ?? '').toLowerCase().trim();

    if (s.isEmpty) return 'hazırlanıyor';

    if (s.contains('cancel')) return 'iptal';
    if (s == 'canceled' || s == 'cancelled' || s == 'iptal') return 'iptal';

    if (s.contains('deliver')) return 'teslim edildi';
    if (s == 'delivered' || s == 'delivered_full') return 'teslim edildi';

    if (s == 'away' || s.contains('transit') || s.contains('on the way') || s.contains('yol')) {
      return 'yolda';
    }

    if (s == 'shipped' || s.contains('sevk') || s.contains('ship')) return 'sevk edildi';

    if (s == 'pending' || s == 'processing' || s.contains('hazır') || s.contains('confirm')) {
      return 'hazırlanıyor';
    }

    return s; // bilinmiyorsa aynen bırak (gri gösterilecek)
  }

  String _statusLabelFrom(String? status) {
    switch (_normStatus(status)) {
      case 'hazırlanıyor': return 'Hazırlanıyor';
      case 'sevk edildi' : return 'Sevk edildi';
      case 'yolda'       : return 'Yolda';
      case 'teslim edildi':return 'Teslim edildi';
      case 'iptal'       : return 'İptal';
      default            : return _normStatus(status);
    }
  }

  IconData _statusIconFrom(String? status) {
    switch (_normStatus(status)) {
      case 'hazırlanıyor': return Icons.inventory_2_outlined;
      case 'sevk edildi' : return Icons.local_shipping_outlined;
      case 'yolda'       : return Icons.route_outlined;
      case 'teslim edildi':return Icons.check_circle_outline;
      case 'iptal'       : return Icons.cancel_outlined;
      default            : return Icons.info_outline;
    }
  }

  Color _statusBgFrom(String? status) {
    switch (_normStatus(status)) {
      case 'hazırlanıyor': return Colors.amber.withOpacity(.15);
      case 'sevk edildi' : return Colors.blue.withOpacity(.15);
      case 'yolda'       : return Colors.indigo.withOpacity(.15);
      case 'teslim edildi':return Colors.green.withOpacity(.15);
      case 'iptal'       : return Colors.red.withOpacity(.15);
      default            : return Colors.grey.withOpacity(.15);
    }
  }

  /// Aşama: -1 iptal, 0 hazırlanıyor, 1 sevk, 2 yolda, 3 teslim
  int _statusStageFrom(String? status) {
    switch (_normStatus(status)) {
      case 'iptal'        : return -1;
      case 'teslim edildi': return 3;
      case 'yolda'        : return 2;
      case 'sevk edildi'  : return 1;
      case 'hazırlanıyor' :
      default             : return 0;
    }
  }

  // ================== API ==================
  Future<void> _loadOrders() async {
    setState(() { _loading = true; _error = null; });
    try {
      final data = await _fetchOrdersApi();
      if (!mounted) return;
      setState(() {
        _all = data;
        _visible = List.of(_all);
        _applySort();
        _recomputeTop();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'Siparişler yüklenemedi: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  /// previous-orders (POST email) → fallback: GET /orders
  Future<List<Order>> _fetchOrdersApi() async {
    final dio = context.read<ApiClient>().dio;
    const email = 'test@test.com';

    // 1) previous-orders
    try {
      final r = await dio.post(
        AppConfig.previousOrdersPath,
        data: {'email': email},
        queryParameters: {'page': 1},
      );
      final list = _extractList(r.data);
      final parsed = _safeParseOrders(list);
      if (parsed.isNotEmpty) return parsed;
    } on DioException catch (e) {
      debugPrint('previous-orders failed → ${e.message}');
    } catch (e) {
      debugPrint('previous-orders error → $e');
    }

    // 2) fallback: /orders
    try {
      final r2 = await dio.get('orders', queryParameters: {'page': 1});
      final list2 = _extractList(r2.data);
      return _safeParseOrders(list2);
    } on DioException catch (e) {
      throw Exception('Orders isteği başarısız: ${e.message}');
    } catch (e) {
      throw Exception('Orders isteği başarısız: $e');
    }
  }

  /// Tek tek parse eder; hata veren kayıtları atlar ve loglar.
  List<Order> _safeParseOrders(List<Map<String, dynamic>> list) {
    final out = <Order>[];
    for (var i = 0; i < list.length; i++) {
      final e = list[i];
      try {
        out.add(Order.fromJson(e));
      } catch (err, st) {
        debugPrint('Order.fromJson FAILED @ index $i → $err');
        debugPrint(const JsonEncoder.withIndent('  ').convert(e));
      }
    }
    return out;
  }

  // ---- JSON yardımcıları (STRING → NUMBER normalizasyonu) ----
  double _asDouble(dynamic v) {
    if (v == null) return 0.0;
    if (v is num) return v.toDouble();
    if (v is String) {
      final s = v.replaceAll('₺', '').replaceAll(' ', '').replaceAll(',', '.');
      return double.tryParse(s) ?? 0.0;
    }
    return 0.0;
  }

  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    if (v is String) return int.tryParse(v) ?? 0;
    return 0;
  }

  Map<String, dynamic> _normalizeOrderJson(Map<String, dynamic> j) {
    final m = Map<String, dynamic>.from(j);

    for (final k in const [
      'total','total_amount','grand_total','amount',
      'subtotal','sub_total','sum','items_total',
      'vat','tax','kdv',
    ]) {
      if (m.containsKey(k)) m[k] = _asDouble(m[k]);
    }

    final itemsKey = [
      'items','order_items','lines','cart_items',
    ].firstWhere((k) => m[k] is List, orElse: () => '');
    if (itemsKey.isNotEmpty) {
      final list = (m[itemsKey] as List)
          .whereType<Map>()
          .map((raw0) {
            final raw = Map<String, dynamic>.from(raw0);
            for (final k in const [
              'qty','quantity','qtyCases',
              'approxKgPerCase','kg_per_case','weight_per_case','weightPerCase',
              'price','unit_price','average_price','pricePerKg','price_per_kg',
              'line_total','lineTotal','line_amount','total_price','total',
            ]) {
              if (raw.containsKey(k)) {
                if (k == 'qty' || k == 'quantity' || k == 'qtyCases') {
                  raw[k] = _asInt(raw[k]);
                } else {
                  raw[k] = _asDouble(raw[k]);
                }
              }
            }
            return raw;
          })
          .toList();
      m[itemsKey] = list;
    }

    return m;
  }

  /// Map/List/Envelope fark etmeksizin içteki listeyi çıkarır ve normalize eder.
  List<Map<String, dynamic>> _extractList(dynamic payload) {
    dynamic body = payload;
    if (body is Map && body['data'] != null) body = body['data'];

    List rawList;
    if (body is List) {
      rawList = body;
    } else if (body is Map) {
      final m = Map<String, dynamic>.from(body);
      rawList = (m['orders'] ?? m['items'] ?? m['results'] ?? m['data'] ?? const []) as List;
    } else {
      rawList = const [];
    }

    return rawList
        .whereType<Map>()
        .map((e) => _normalizeOrderJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  // ================== Filtre & Sıralama ==================
  void _applyFilters() {
    final q = _search.text.trim().toLowerCase();
    setState(() {
      _visible = _all.where((o) {
        final okStatus = _statusFilter == null || _normStatus(o.status) == _statusFilter;
        final okQuery = q.isEmpty ||
            o.orderNumber.toLowerCase().contains(q) ||
            (o.shippingAddress ?? '').toLowerCase().contains(q) ||
            o.createdByName.toLowerCase().contains(q);
        return okStatus && okQuery;
      }).toList();
      _applySort();
      _recomputeTop();
    });
  }

  void _applySort() {
    if (_sortColumnIndex == null) return;
    _visible.sort((a, b) {
      int cmp = 0;
      switch (_sortColumnIndex) {
        case 0: cmp = a.orderNumber.compareTo(b.orderNumber); break;
        case 1: cmp = _normStatus(a.status).compareTo(_normStatus(b.status)); break;
        // case 2: cmp = a.createdAt?.compareTo(b.createdAt ?? a.createdAt!) ?? 0; break;
        case 3: cmp = a.totalAmount.compareTo(b.totalAmount); break;
      }
      return _sortAscending ? cmp : -cmp;
    });
  }

  void _onSort(int columnIndex, bool ascending) {
    setState(() {
      _sortColumnIndex = columnIndex;
      _sortAscending = ascending;
      _applySort();
    });
  }

  // ================== Tablo (gerçek responsive) ==================
  Widget _ordersResponsiveTable(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isCompact = constraints.maxWidth < 1700;

        if (isCompact) {
          return RefreshIndicator(
            onRefresh: _loadOrders,
            child: ListView.separated(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: _visible.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final o = _visible[i];
                return ListTile(
                  title: Text(o.orderNumber, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Wrap(
                          spacing: 12,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            _statusChip(o.status),
                            // Text(dt(o.createdAt)), // createdAt'ı göstermek istersen
                          ],
                        ),
                        const SizedBox(height: 8),
                        _shipmentTimeline(o.status),
                      ],
                    ),
                  ),
                  trailing: Text(tl(o.totalAmount), style: const TextStyle(fontWeight: FontWeight.w700)),
                );
              },
            ),
          );
        }

        return RefreshIndicator(
          onRefresh: _loadOrders,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            scrollDirection: Axis.horizontal,
            child: ConstrainedBox(
              constraints: BoxConstraints(minWidth: constraints.maxWidth),
              child: SingleChildScrollView(
                child: DataTable(
                  columnSpacing: 32,
                  sortColumnIndex: _sortColumnIndex,
                  sortAscending: _sortAscending,
                  columns: [
                    DataColumn(label: const Text('Sipariş'), onSort: _onSort),
                    DataColumn(label: const Text('Durum'), onSort: _onSort),
                    // DataColumn(label: const Text('Tarih'), onSort: _onSort),
                    DataColumn(numeric: true, label: const Text('Tutar'), onSort: _onSort),
                  ],
                  rows: [
                    for (final o in _visible)
                      DataRow(
                        cells: [
                          DataCell(Text(o.orderNumber)),
                          DataCell(_statusChip(o.status)),
                          // DataCell(Text(dt(o.createdAt))),
                          DataCell(Text(tl(o.totalAmount))),
                        ],
                      ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // Basit timeline (projende özel stage bileşeni yoksa)
  Widget _shipmentTimeline(String? status) {
    final current = _statusStageFrom(status);
    const stages = [
      ('Hazırlanıyor', Icons.inventory_2_outlined),
      ('Sevk Edildi',  Icons.local_shipping_outlined),
      ('Yolda',        Icons.route_outlined),
      ('Teslim Edildi',Icons.verified_outlined),
    ];

    if (current == -1) {
      return Row(
        children: const [
          CircleAvatar(radius: 14, backgroundColor: Color(0xFFFFE5E5), child: Icon(Icons.cancel_outlined, color: Colors.red)),
          SizedBox(width: 8),
          Text('Sipariş İptal Edildi', style: TextStyle(fontWeight: FontWeight.w700)),
        ],
      );
    }

    return Wrap(
      spacing: 8, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center,
      children: List.generate(stages.length, (i) {
        final done = i < current;
        final now  = i == current;
        final color = done ? Colors.green : (now ? Colors.blue : Colors.grey);
        return Chip(
          avatar: Icon(stages[i].$2, size: 16, color: color),
          label: Text(stages[i].$1),
          backgroundColor: color.withOpacity(.12),
        );
      }),
    );
  }

  // ================== Top ürün hesaplama ==================
  void _recomputeTop() {
    final map = <String, _TopStat>{};
    for (final o in _visible) {
      for (final it in o.items) {
        final baseName = it.productTitle.split(' - ').first;
        final ex = map[baseName];
        map[baseName] = ex == null
            ? _TopStat(name: baseName, qtyCases: it.qtyCases, revenue: it.lineTotal)
            : _TopStat(
                name: baseName,
                qtyCases: ex.qtyCases + it.qtyCases,
                revenue: ex.revenue + it.lineTotal,
              );
      }
    }
    _topByQty = map.values.toList()..sort((a, b) => b.qtyCases.compareTo(a.qtyCases));
    _topByRevenue = map.values.toList()..sort((a, b) => b.revenue.compareTo(a.revenue));
  }

  // ================== Status aggregate ==================
  List<_StatusAgg> _computeStatusAgg5() {
    int cPrep = 0, cShip = 0, cTran = 0, cDel = 0, cCan = 0;
    double aPrep = 0, aShip = 0, aTran = 0, aDel = 0, aCan = 0;

    for (final o in _visible) {
      switch (_normStatus(o.status)) {
        case 'hazırlanıyor': cPrep++; aPrep += o.totalAmount; break;
        case 'sevk edildi' : cShip++; aShip += o.totalAmount; break;
        case 'yolda'       : cTran++; aTran += o.totalAmount; break;
        case 'teslim edildi':cDel++;  aDel  += o.totalAmount; break;
        case 'iptal'       : cCan++;  aCan  += o.totalAmount; break;
      }
    }

    return [
      _StatusAgg('hazırlanıyor','Hazırlanıyor', Icons.inventory_2_outlined, Colors.amber,  cPrep, aPrep),
      _StatusAgg('sevk edildi', 'Sevk edildi',  Icons.local_shipping_outlined, Colors.blue,   cShip, aShip),
      _StatusAgg('yolda',       'Yolda',        Icons.route_outlined,          Colors.indigo, cTran, aTran),
      _StatusAgg('teslim edildi','Teslim edildi',Icons.check_circle_outline,  Colors.green,  cDel,  aDel),
      _StatusAgg('iptal',       'İptal',        Icons.cancel_outlined,         Colors.red,    cCan,  aCan),
    ];
  }

  // 1) GRID: en az 2 sütun, ekrana göre 2/3/4 sütun
  Widget _statusAggGrid() {
    final list = _computeStatusAgg5();

    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        int cols;
        if (w >= 1100) {
          cols = 4;
        } else if (w >= 900) {
          cols = 3;
        } else {
          cols = 2;
        }

        const gap = 16.0;
        final itemW = (w - gap * (cols - 1)) / cols;

        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [
            for (final a in list)
              SizedBox(width: itemW, child: _statusAggCard(a)),
          ],
        );
      },
    );
  }

  // 2) KART
  Widget _statusAggCard(_StatusAgg a) {
    return Card(
      child: SizedBox(
        height: 120,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(a.icon, size: 40, color: a.color),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(a.label),
                    Text(tl(a.amount), style: Theme.of(context).textTheme.headlineSmall),
                    const SizedBox(height: 2),
                    Text('${a.count} sipariş', style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ================== Build ==================
  @override
  Widget build(BuildContext context) {
    final totalSales = _visible.fold<double>(0, (s, o) => s + o.totalAmount);
    final preparing  = _visible.where((o) => _normStatus(o.status) == 'hazırlanıyor').length;
    final shipped    = _visible.where((o) => _normStatus(o.status) == 'sevk edildi').length;
    final inTransit  = _visible.where((o) => _normStatus(o.status) == 'yolda').length;
    final delivered  = _visible.where((o) => _normStatus(o.status) == 'teslim edildi').length;
    final canceled   = _visible.where((o) => _normStatus(o.status) == 'iptal').length;
    final ordersCount = _visible.length;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: LayoutBuilder(
        builder: (context, box) {
          final isWide = box.maxWidth >= 1700;

          // DAR EKRAN
          if (!isWide) {
            return ListView(
              children: [
                if (_loading) const LinearProgressIndicator(minHeight: 2),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(_error!, style: const TextStyle(color: Colors.red)),
                  ),
                Wrap(
                  spacing: 16,
                  runSpacing: 16,
                  children: [
                    _metricCard(context, 'Toplam Satış', tl(totalSales), Icons.paid_outlined),
                  ],
                ),
                const SizedBox(height: 12),
                _statusAggGrid(),
                const SizedBox(height: 24),
                // _filtersBar(context), // istersen aç
                const SizedBox(height: 12),
                _statusDonutCard(ordersCount, preparing, shipped, inTransit, delivered, canceled),
                const SizedBox(height: 16),
                _topProductsCard(),
                const SizedBox(height: 16),
                _ordersCard(),
              ],
            );
          }

          // GENİŞ EKRAN
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (_loading) const LinearProgressIndicator(minHeight: 2),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(_error!, style: const TextStyle(color: Colors.red)),
                ),
              Wrap(spacing: 16, runSpacing: 16, children: [
                _metricCard(context, 'Toplam Satış', tl(totalSales), Icons.paid_outlined),
              ]),
              const SizedBox(height: 12),
              _statusAggGrid(),
              const SizedBox(height: 24),
              _filtersBar(context),
              const SizedBox(height: 12),
              Expanded(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(flex: 3, child: _ordersCard()),
                    const SizedBox(width: 16),
                    SizedBox(
                      width: 340,
                      child: _statusDonutCard(
                        ordersCount, preparing, shipped, inTransit, delivered, canceled,
                      ),
                    ),
                    const SizedBox(width: 16),
                    SizedBox(width: 360, child: _topProductsCard()),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // ---------- Kartlar ----------
  Widget _ordersCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Son Siparişler', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            SizedBox(height: 420, child: _ordersResponsiveTable(context)),
          ],
        ),
      ),
    );
  }

  Widget _statusDonutCard(
    int ordersCount, int preparing, int shipped, int inTransit, int delivered, int canceled,
  ) {
    final slices = [
      DonutSlice(value: preparing.toDouble(),  color: Colors.amber,  label: 'Hazırlanıyor'),
      DonutSlice(value: shipped.toDouble(),    color: Colors.blue,   label: 'Sevk edildi'),
      DonutSlice(value: inTransit.toDouble(),  color: Colors.indigo, label: 'Yolda'),
      DonutSlice(value: delivered.toDouble(),  color: Colors.green,  label: 'Teslim edildi'),
      DonutSlice(value: canceled.toDouble(),   color: Colors.red,    label: 'İptal'),
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: LayoutBuilder(
          builder: (context, c) {
            final narrow = c.maxWidth < 420;
            if (narrow) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Durum Dağılımı', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 200,
                    child: DonutChart(slices: slices, thickness: 22, centerText: '$ordersCount\nsipariş'),
                  ),
                  const SizedBox(height: 12),
                  _legendDot(Colors.amber,  'Hazırlanıyor ($preparing)'),
                  _legendDot(Colors.blue,   'Sevk edildi ($shipped)'),
                  _legendDot(Colors.indigo, 'Yolda ($inTransit)'),
                  _legendDot(Colors.green,  'Teslim edildi ($delivered)'),
                  _legendDot(Colors.red,    'İptal ($canceled)'),
                ],
              );
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Durum Dağılımı', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: DonutChart(slices: slices, thickness: 22, centerText: '$ordersCount\nsipariş'),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _legendDot(Colors.amber,  'Hazırlanıyor ($preparing)'),
                        _legendDot(Colors.blue,   'Sevk edildi ($shipped)'),
                        _legendDot(Colors.indigo, 'Yolda ($inTransit)'),
                        _legendDot(Colors.green,  'Teslim edildi ($delivered)'),
                        _legendDot(Colors.red,    'İptal ($canceled)'),
                      ],
                    ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _legendDot(Color c, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(width: 12, height: 12, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Text(text),
        ],
      ),
    );
  }

  Widget _topProductsCard() {
    final list = _topSortByRevenue ? _topByRevenue : _topByQty;
    final maxVal = list.isEmpty ? 1.0 : (_topSortByRevenue ? list.first.revenue : list.first.qtyCases);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text('En Çok Sipariş Verilen Ürünler', style: Theme.of(context).textTheme.titleMedium)),
                FilterChip(label: const Text('Adet'),  selected: !_topSortByRevenue, onSelected: (_) => setState(() => _topSortByRevenue = false)),
                const SizedBox(width: 6),
                FilterChip(label: const Text('Tutar'), selected:  _topSortByRevenue, onSelected: (_) => setState(() => _topSortByRevenue = true)),
              ],
            ),
            const SizedBox(height: 12),
            if (list.isEmpty)
              const Padding(padding: EdgeInsets.all(12), child: Text('Gösterilecek veri yok.'))
            else
              SizedBox(
                height: 420,
                child: ListView.separated(
                  itemCount: list.length.clamp(0, 10),
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, i) {
                    final it = list[i];
                    final value = _topSortByRevenue ? it.revenue : it.qtyCases;
                    final ratio = (value / maxVal).clamp(0.0, 1.0);
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Text(it.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
                            const SizedBox(width: 8),
                            Text(_topSortByRevenue ? tl(it.revenue) : '${it.qtyCases.toStringAsFixed(0)} koli'),
                          ],
                        ),
                        const SizedBox(height: 6),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(value: ratio),
                        ),
                      ],
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ---------- Filtre barı ----------
  Widget _filtersBar(BuildContext context) {
    final statuses = const ['hazırlanıyor', 'sevk edildi', 'yolda', 'teslim edildi', 'iptal'];
    return Wrap(
      spacing: 12,
      runSpacing: 8,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 360),
          child: TextField(
            controller: _search,
            decoration: const InputDecoration(
              hintText: 'Sipariş, adres veya kullanıcı ara…',
              prefixIcon: Icon(Icons.search),
              isDense: true,
            ),
            onChanged: (_) => _applyFilters(),
          ),
        ),
        FilterChip(label: const Text('Hepsi'), selected: _statusFilter == null, onSelected: (_) { _statusFilter = null; _applyFilters(); }),
        for (final s in statuses)
          FilterChip(
            label: Text(_statusLabelFrom(s)),
            selected: _statusFilter == s,
            onSelected: (_) { _statusFilter = s; _applyFilters(); },
            avatar: Icon(_statusIconFrom(s), size: 18),
          ),
      ],
    );
  }

  // ---------- UI yardımcıları ----------
  Widget _metricCard(BuildContext context, String label, String value, IconData icon) {
    return SizedBox(
      width: 280, height: 120,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(icon, size: 40),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(label),
                  Text(value, style: Theme.of(context).textTheme.headlineSmall),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statusChip(String? status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: _statusBgFrom(status), borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(_statusIconFrom(status), size: 16),
          const SizedBox(width: 6),
          Text(_statusLabelFrom(status)),
        ],
      ),
    );
  }
}

// --- küçük struct'lar ---
class _TopStat {
  final String name;
  final double qtyCases;
  final double revenue;
  const _TopStat({required this.name, required this.qtyCases, required this.revenue});
}

class _StatusAgg {
  final String key;
  final String label;
  final IconData icon;
  final Color color;
  final int count;
  final double amount;
  const _StatusAgg(this.key, this.label, this.icon, this.color, this.count, this.amount);
}
