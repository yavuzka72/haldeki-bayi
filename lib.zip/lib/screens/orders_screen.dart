import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../services/api_client.dart';
import '../utils/format.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  // Ham & görünür liste
  List<_Order> _all = [];
  List<_Order> _visible = [];

  // Arama
  final _search = TextEditingController();

  // Sıralama (sadece geniş tabloda)
  int? _sortColumnIndex;
  bool _sortAscending = true;

  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final dio = context.read<ApiClient>().dio;
      const email = 'test@test.com';

      final res = await dio.post(
        AppConfig.previousOrdersPath,
        data: {'email': email},
        queryParameters: {'page': 1},
      );

      final list = _parseOrdersPayload(res.data);
      setState(() {
        _all = list;
        _visible = List.of(_all);
        _applySort();
      });
    } catch (e) {
      setState(() => _error = 'Siparişler yüklenemedi: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // JSON -> _Order list (alan adlarına esnek)
  List<_Order> _parseOrdersPayload(dynamic payload) {
    List items;
    if (payload is List) {
      items = payload;
    } else if (payload is Map) {
      if (payload['data'] is List) {
        items = payload['data'];
      } else if (payload['results'] is List) {
        items = payload['results'];
      } else {
        items = [];
      }
    } else {
      items = [];
    }

    String pickStr(Map m, List<String> keys, {String fallback = ''}) {
      for (final k in keys) {
        final v = m[k];
        if (v == null) continue;
        final s = v.toString();
        if (s.isNotEmpty) return s;
      }
      return fallback;
    }

    double pickNum(Map m, List<String> keys) {
      for (final k in keys) {
        final v = m[k];
        if (v == null) continue;
        if (v is num) return v.toDouble();
        if (v is String) {
          final d = double.tryParse(v.replaceAll(',', '.'));
          if (d != null) return d;
        }
      }
      return 0.0;
    }

    DateTime pickDate(Map m, List<String> keys) {
      for (final k in keys) {
        final v = m[k];
        if (v is String) {
          final d = DateTime.tryParse(v);
          if (d != null) return d;
        }
        if (v is int) {
          final s = v.toString();
          if (s.length >= 13) return DateTime.fromMillisecondsSinceEpoch(v);
          if (s.length >= 10) return DateTime.fromMillisecondsSinceEpoch(v * 1000);
        }
      }
      return DateTime.now();
    }

    String normStatus(String s) {
      final t = s.toLowerCase().trim();
      if (t.contains('hazır')) return 'hazırlanıyor';
      if (t.contains('sevk')) return 'sevk edildi';
      if (t.contains('yol')) return 'yolda';
      if (t.contains('teslim')) return 'teslim edildi';
      if (t.contains('iptal') || t.contains('cancel')) return 'iptal';
      return s;
    }

    return items.whereType<Map>().map((raw0) {
      final raw = Map<String, dynamic>.from(raw0);

      final id = pickStr(raw, ['id', '_id', 'order_id'], fallback: '');
      final number = pickStr(
        raw,
        ['orderNumber', 'order_number', 'number', 'code', 'no'],
        fallback: id.isEmpty ? '—' : '#$id',
      );
      final rawStatus = pickStr(raw, ['status', 'state', 'order_status'], fallback: '');
      final createdAt =
          pickDate(raw, ['createdAt', 'created_at', 'date', 'ordered_at', 'created_at_iso']);
      final total = pickNum(raw, ['total', 'total_amount', 'amount', 'grand_total']);
      final address =
          pickStr(raw, ['shippingAddress', 'shipping_address', 'address', 'delivery_address']);
      final createdBy =
          pickStr(raw, ['createdByName', 'created_by_name', 'user_name', 'customer_name', 'createdBy']);

      return _Order(
        id: id,
        orderNumber: number,
        status: normStatus(rawStatus),
        createdAt: createdAt,
        totalAmount: total,
        shippingAddress: address.isEmpty ? null : address,
        createdByName: createdBy.isEmpty ? '—' : createdBy,
      );
    }).toList();
  }

  void _applyFilters() {
    final q = _search.text.trim().toLowerCase();
    setState(() {
      _visible = _all.where((o) {
        final okQuery = q.isEmpty ||
            o.orderNumber.toLowerCase().contains(q) ||
            (o.shippingAddress ?? '').toLowerCase().contains(q) ||
            o.createdByName.toLowerCase().contains(q);
        return okQuery;
      }).toList();
      _applySort();
    });
  }

  void _applySort() {
    if (_sortColumnIndex == null) return;
    _visible.sort((a, b) {
      int cmp = 0;
      switch (_sortColumnIndex) {
        case 0:
          cmp = a.orderNumber.compareTo(b.orderNumber);
          break;
        case 1:
          cmp = a.status.compareTo(b.status);
          break;
        case 2:
          cmp = a.createdAt.compareTo(b.createdAt);
          break;
        case 3:
          cmp = a.totalAmount.compareTo(b.totalAmount);
          break;
      }
      return _sortAscending ? cmp : -cmp;
    });
  }

  void _onSort(int columnIndex, bool ascending) {
    setState(() {
      _sortColumnIndex = columnIndex;
      _sortAscending = ascending;
      _applySort();
    });
  }

  // ---------- BUILD ----------
  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_outlined, size: 48),
            const SizedBox(height: 8),
            Text(_error!),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _load,
              icon: const Icon(Icons.refresh),
              label: const Text('Tekrar dene'),
            ),
          ],
        ),
      );
    }

    final total = _visible.fold<double>(0, (s, o) => s + o.totalAmount);
    final delivered = _visible.where((o) => _isDelivered(o.status)).length;
    final preparing = _visible.where((o) => o.status == 'hazırlanıyor').length;

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _load,
        child: LayoutBuilder(
          builder: (context, box) {
            final isWide = box.maxWidth >= 900;
            final cols = box.maxWidth >= 700 ? 2 : 1;

            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // --- Üst metrikler (responsive grid) ---
                _metricsGrid(cols: cols, total: total, delivered: delivered, preparing: preparing),
                const SizedBox(height: 16),

                // --- Arama (filtre çipleri kaldırıldı) ---
                ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 480),
                  child: TextField(
                    controller: _search,
                    decoration: InputDecoration(
                      hintText: 'Sipariş no, adres veya kullanıcı ara…',
                      prefixIcon: const Icon(Icons.search),
                      isDense: true,
                      suffixIcon: _search.text.isEmpty
                          ? null
                          : IconButton(
                              tooltip: 'Temizle',
                              onPressed: () {
                                setState(() => _search.clear());
                                _applyFilters();
                              },
                              icon: const Icon(Icons.close),
                            ),
                    ),
                    onChanged: (_) => _applyFilters(),
                  ),
                ),
                const SizedBox(height: 12),

                // --- Liste / Tablo (tek scroll: shrinkWrap + NeverScrollable) ---
                Card(
                  clipBehavior: Clip.antiAlias,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: _visible.isEmpty
                        ? _emptyState()
                        : (isWide ? _ordersWideTable(shrinkWrap: true) : _ordersCardsList(shrinkWrap: true)),
                  ),
                ),

                const SizedBox(height: 24),
              ],
            );
          },
        ),
      ),
    );
  }

  // ---------- Parçalar ----------

  Widget _metricsGrid({
    required int cols,
    required double total,
    required int delivered,
    required int preparing,
  }) {
    final items = <Widget>[
      _metricCard(context, 'Toplam Tutar', tl(total), Icons.paid_outlined),
      _metricCard(context, 'Teslim edilen', '$delivered', Icons.check_circle_outline),
      _metricCard(context, 'Hazırlanan', '$preparing', Icons.inventory_2_outlined),
      _metricCard(context, 'Sipariş', '${_visible.length}', Icons.receipt_long_outlined),
    ];

    return LayoutBuilder(
      builder: (context, box) {
        final gap = 16.0;
        final cardW = (box.maxWidth - gap * (cols - 1)) / cols;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [
            for (final w in items)
              SizedBox(width: cardW, child: w),
          ],
        );
      },
    );
  }

  /// DAR ekran kart listesi (tek scroll için shrinkWrap + NeverScrollable)
  Widget _ordersCardsList({required bool shrinkWrap}) {
    return ListView.separated(
      shrinkWrap: shrinkWrap,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _visible.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        final o = _visible[i];
        return InkWell(
          onTap: () => context.go('/orders/${o.orderNumber}'),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 2))],
            ),
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(o.orderNumber, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        spacing: 10,
                        children: [
                          _statusChip(o.status),
                          Text(dt(o.createdAt), style: const TextStyle(color: Colors.black54)),
                        ],
                      ),
                      if (o.shippingAddress != null && o.shippingAddress!.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(
                          o.shippingAddress!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.black54),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(tl(o.totalAmount), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 8),
                    const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.black38),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// GENİŞ ekran DataTable (tek scroll için shrinkWrap + NeverScrollable)
  Widget _ordersWideTable({required bool shrinkWrap}) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const NeverScrollableScrollPhysics(),
      child: ConstrainedBox(
        constraints: const BoxConstraints(minWidth: 900),
        child: DataTable(
          columnSpacing: 28,
          sortColumnIndex: _sortColumnIndex,
          sortAscending: _sortAscending,
          columns: [
            DataColumn(label: const Text('Sipariş'), onSort: _onSort),
            DataColumn(label: const Text('Durum'), onSort: _onSort),
            DataColumn(label: const Text('Tarih'), onSort: _onSort),
            DataColumn(numeric: true, label: const Text('Tutar'), onSort: _onSort),
            const DataColumn(label: Text('Aksiyon')),
          ],
          rows: [
            for (final o in _visible)
              DataRow(
                cells: [
                  DataCell(
                    TextButton(
                      onPressed: () => context.go('/orders/${o.orderNumber}'),
                      child: Text(o.orderNumber),
                    ),
                  ),
                  DataCell(_statusChip(o.status)),
                  DataCell(Text(dt(o.createdAt))),
                  DataCell(Text(tl(o.totalAmount))),
                  DataCell(
                    IconButton(
                      tooltip: 'Detay',
                      onPressed: () => context.go('/orders/${o.orderNumber}'),
                      icon: const Icon(Icons.open_in_new),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  // ---- UI yardımcıları ----
  Widget _emptyState() => const Padding(
        padding: EdgeInsets.all(8.0),
        child: Center(child: Text('Eşleşen sipariş bulunamadı')),
      );

  Widget _metricCard(BuildContext context, String label, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, size: 36),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(label),
                Text(value, style: Theme.of(context).textTheme.headlineSmall),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusChip(String status) {
    final icon = _statusIcon(status);
    final bg = _statusBg(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 6),
          Text(_statusLabel(status)),
        ],
      ),
    );
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'hazırlanıyor': return 'Hazırlanıyor';
      case 'sevk edildi':  return 'Sevk edildi';
      case 'yolda':        return 'Yolda';
      case 'teslim edildi':
      case 'teslim edil':  return 'Teslim edildi';
      case 'iptal':        return 'İptal';
      default:             return status;
    }
  }

  IconData _statusIcon(String status) {
    switch (status) {
      case 'hazırlanıyor': return Icons.inventory_2_outlined;
      case 'sevk edildi':  return Icons.local_shipping_outlined;
      case 'yolda':        return Icons.route_outlined;
      case 'teslim edildi':
      case 'teslim edil':  return Icons.check_circle_outline;
      case 'iptal':        return Icons.cancel_outlined;
      default:             return Icons.info_outline;
    }
  }

  Color _statusBg(String status) {
    switch (status) {
      case 'hazırlanıyor': return Colors.amber.withOpacity(.15);
      case 'sevk edildi':  return Colors.blue.withOpacity(.15);
      case 'yolda':        return Colors.indigo.withOpacity(.15);
      case 'teslim edildi':
      case 'teslim edil':  return Colors.green.withOpacity(.15);
      case 'iptal':        return Colors.red.withOpacity(.15);
      default:             return Colors.grey.withOpacity(.15);
    }
  }

  bool _isDelivered(String s) => s == 'teslim edildi' || s == 'teslim edil';
}

// Basit view-model
class _Order {
  final String id;
  final String orderNumber;
  final String status;
  final DateTime createdAt;
  final double totalAmount;
  final String? shippingAddress;
  final String createdByName;

  _Order({
    required this.id,
    required this.orderNumber,
    required this.status,
    required this.createdAt,
    required this.totalAmount,
    required this.shippingAddress,
    required this.createdByName,
  });
}
