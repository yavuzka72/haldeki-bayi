import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:haldeki_admin_web/config.dart';
import 'package:haldeki_admin_web/models/cart.dart';
import 'package:haldeki_admin_web/widgets/QtyInput.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../utils/format.dart';

// Modeller
import '../models/category.dart';
import '../models/variant.dart';
import '../models/product.dart';
import '../models/cart_model.dart';

class MarketScreen extends StatefulWidget {
  const MarketScreen({super.key});

  @override
  State<MarketScreen> createState() => _MarketScreenState();
}

class _MarketScreenState extends State<MarketScreen> {
  final _search = TextEditingController();

  bool _loadingCats = true;
  bool _loadingProds = true;

  List<Category> _cats = const [];
  int? _selectedCat;

  List<Product> _products = const [];
  int _page = 1;
  bool _more = true;
  bool _loadingMore = false;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _loadAll() async {
    await Future.wait([_loadCategories(), _fetchProducts(reset: true)]);
  }

  Future<void> _loadCategories() async {
    setState(() => _loadingCats = true);
    try {
      final api = context.read<ApiClient>().dio;
      final res = await api.get('categories');
      final data = res.data;
      List list;
      if (data is List) {
        list = data;
      } else if (data is Map && data['data'] is List) {
        list = data['data'];
      } else if (data is Map && data['results'] is List) {
        list = data['results'];
      } else {
        list = [];
      }
      _cats = list
          .whereType<Map>()
          .map((j) => Category.fromJson(Map<String, dynamic>.from(j)))
          .toList();
    } finally {
      if (mounted) setState(() => _loadingCats = false);
    }
  }

  Future<void> _fetchProducts({bool reset = false}) async {
    if (reset) {
      _page = 1;
      _more = true;
      _products = const [];
      setState(() {});
    }
    if (!_more) return;

    if (reset) {
      setState(() => _loadingProds = true);
    } else {
      setState(() => _loadingMore = true);
    }

    try {
      final api = context.read<ApiClient>().dio;

      final params = <String, dynamic>{
        'page': _page,
        if (_search.text.trim().isNotEmpty) 'q': _search.text.trim(),
        if (_selectedCat != null) ...{
          'category_id': _selectedCat,
          'filters[category_id]': _selectedCat,
        },
      };

      final res = await api.get('products', queryParameters: params);

      final parsed = _parseProductsPayload(res.data);
      _products = [..._products, ...parsed];

      int? currentPage, lastPage;
      final root = res.data;
      if (root is Map) {
        if (root['data'] is Map) {
          final d = root['data'] as Map;
          if (d['current_page'] is num) currentPage = (d['current_page'] as num).toInt();
          if (d['last_page'] is num) lastPage = (d['last_page'] as num).toInt();
        }
        if (root['current_page'] is num) currentPage = (root['current_page'] as num).toInt();
        if (root['last_page'] is num) lastPage = (root['last_page'] as num).toInt();
      }

      if (currentPage != null && lastPage != null) {
        _more = currentPage < lastPage;
        if (_more) _page = currentPage + 1;
      } else {
        _more = parsed.isNotEmpty;
        if (_more) _page += 1;
      }
    } on DioException catch (e) {
      debugPrint('products error: ${e.message}');
    } finally {
      if (!mounted) return;
      _loadingProds = false;
      _loadingMore = false;
      setState(() {});
    }
  }

  List<Product> _parseProductsPayload(dynamic payload) {
    List items;
    if (payload is Map && payload['data'] is Map && (payload['data'] as Map)['data'] is List) {
      items = ((payload['data'] as Map)['data'] as List);
    } else if (payload is Map && payload['data'] is List) {
      items = (payload['data'] as List);
    } else if (payload is List) {
      items = payload;
    } else if (payload is Map && payload['results'] is List) {
      items = payload['results'] as List;
    } else {
      items = const [];
    }

    return items.whereType<Map>().map((raw) {
      final j = Map<String, dynamic>.from(raw);

      final id = _asInt(j['id']);
      final name = (j['name'] ?? j['title'] ?? '').toString();
      final catId = _asInt(j['category_id'] ?? j['categoryId']);

      final imagePath = j['image']?.toString() ?? '';
      final imageUrl = AppConfig.imageUrl(imagePath);

      List<ProductVariant> variants = [];
      if (j['variants'] is List) {
        variants = (j['variants'] as List).whereType<Map>().map((vv) {
          final v = Map<String, dynamic>.from(vv);
          return ProductVariant(
            id: _asInt(v['id']),
            name: (v['name'] ?? 'Standart').toString(),
            price: _asDouble(v['price'] ?? v['average_price']),
            unit: (v['unit'] ?? 'adet').toString(),
            sku: v['sku']?.toString(),
            image: v['image']?.toString(),
          );
        }).toList();
      } else {
        variants = [
          ProductVariant(
            id: id,
            name: (j['variant_name'] ?? 'Standart').toString(),
            price: _asDouble(j['price']),
            unit: (j['unit'] ?? 'adet').toString(),
            sku: j['sku']?.toString(),
            image: j['variant_image']?.toString(),
          ),
        ];
      }

      return Product(
        id: id,
        categoryId: catId,
        name: name,
        image: imageUrl,
        variants: variants,
      );
    }).toList();
  }

  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is String) return int.tryParse(v) ?? 0;
    if (v is num) return v.toInt();
    return 0;
  }

  double _asDouble(dynamic v) {
    if (v is double) return v;
    if (v is int) return v.toDouble();
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v.replaceAll(',', '.')) ?? 0.0;
    return 0.0;
  }

  Future<void> _onSearch() async {
    await _fetchProducts(reset: true);
  }

  // Sepet yardımcıları
  void _cartDec(Product p, ProductVariant v, int qty) {
    Cart.I.add(p, v, qtyCases: -1);
    setState(() {});
  }

  void _cartInc(Product p, ProductVariant v) {
    Cart.I.add(p, v, qtyCases: 1);
    setState(() {});
  }

  void _cartRemove(Product p, ProductVariant v, double qty) {
    Cart.I.add(p, v, qtyCases: - qty);
    setState(() {});
  }

  void _cartClearAll(Cart cart) {
    for (final line in List.of(cart.items as Iterable)) {
      final p = line.product as Product;
      final v = line.variant as ProductVariant;
      final qty = (line.qtyCases ?? line.qty ?? 1) as double;
      Cart.I.add(p, v, qtyCases: -qty);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        final showRightCart = box.maxWidth >= 900;
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              // SOL taraf (ürün listesi)
              Expanded(
                child: Column(
                  children: [
                    // Arama
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _search,
                            decoration: const InputDecoration(
                              hintText: 'Ürün veya varyant ara…',
                              prefixIcon: Icon(Icons.search),
                              isDense: true,
                            ),
                            onSubmitted: (_) => _onSearch(),
                          ),
                        ),
                        const SizedBox(width: 8),
                        FilledButton.icon(
                          onPressed: _onSearch,
                          icon: const Icon(Icons.search),
                          label: const Text('Ara'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Kategoriler
                    if (_loadingCats)
                      const CircularProgressIndicator()
                    else
                      _categoriesBar(),
                    const SizedBox(height: 12),

                    // Ürün grid
                    Expanded(
                      child: _loadingProds
                          ? const Center(child: CircularProgressIndicator())
                          : _products.isEmpty
                              ? const Center(child: Text('Ürün bulunamadı'))
                              : _grid(),
                    ),
                  ],
                ),
              ),

              if (showRightCart) const SizedBox(width: 16),
              if (showRightCart) SizedBox(width: 320, child: _cartPanel()),
            ],
          ),
        );
      },
    );
  }

  Widget _categoriesBar() {
    return SizedBox(
      height: 40,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _cats.length,
        itemBuilder: (_, i) {
          final c = _cats[i];
          final selected = _selectedCat == c.id;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text(c.name),
              selected: selected,
              onSelected: (_) {
                setState(() => _selectedCat = selected ? null : c.id);
                _fetchProducts(reset: true);
              },
            ),
          );
        },
      ),
    );
  }

  Widget _grido() {
    return GridView.builder(
      padding: const EdgeInsets.only(top: 4),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        mainAxisExtent: 210,
      ),
      itemCount: _products.length,
      itemBuilder: (_, i) => _productCard(_products[i]),
    );
  }
Widget _555grid() {
  return LayoutBuilder(
    builder: (context, box) {
      final w = box.maxWidth;
      int cross;
      double extent; // kart yüksekliği

      if (w < 600) {          // mobil
        cross = 2;
        extent = 260;         // 230–250 arası deneyebilirsin
      } else if (w < 1200) {  // tablet
        cross = 3;
        extent = 240;
      } else {                // desktop
        cross = 4;
        extent = 240;
      }

      return GridView.builder(
        padding: const EdgeInsets.all(8),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: cross,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          mainAxisExtent: extent, // <-- sabit yükseklik
        ),
        itemCount: _products.length,
        itemBuilder: (_, i) => _productCard(_products[i]),
      );
    },
  );
}
Widget _grid() {
  return LayoutBuilder(builder: (context, box) {
    final w = box.maxWidth;
    final maxExtent = w >= 1400 ? 360 : w >= 900 ? 320 : 300;
    final ratio     = w >= 1400 ? 0.78 : 0.80; // geniş ekranda biraz daha kısa

    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: maxExtent.toDouble(),
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: ratio,
      ),
      itemCount: _products.length,
      itemBuilder: (_, i) => _productCard(_products[i]),
    );
  });
}


Widget _productCard3(Product p) {
  final cs = Theme.of(context).colorScheme;
  final url = p.image.startsWith('http') ? p.image : AppConfig.imageUrl(p.image);

  return Card(
    clipBehavior: Clip.antiAlias,
    color: cs.surfaceVariant.withOpacity(.35),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Resim
        AspectRatio(
          aspectRatio: 4/3,
          child: Image.network(
            url,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Icon(Icons.image_not_supported_outlined, size: 40),
          ),
        ),
        // İsim
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
          child: Text(
            p.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ),
        const Spacer(),

        // “Seç / Ekle” butonu – varyantları alt sayfada göster
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          child: FilledButton.tonal(
            onPressed: () => _showVariantsSheet(p),
            child: const Text('Paket Seç'),
          ),
        ),
      ],
    ),
  );
}
Widget _productCard4(Product p) {
  final cs = Theme.of(context).colorScheme;
  final url = p.image.startsWith('http') ? p.image : AppConfig.imageUrl(p.image);

  return Card(
    clipBehavior: Clip.antiAlias,
    color: cs.surfaceVariant.withOpacity(.35),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Görsel
        AspectRatio(
          aspectRatio: 4 / 3,
          child: Image.network(
            url,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) =>
                const Icon(Icons.image_not_supported_outlined, size: 40),
          ),
        ),

        // İsim (sadece 8px alt boşluk)
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
          child: Text(
            p.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ),

        // Daha az boşluk
        const SizedBox(height: 6),

        // Paket Seç butonu — yoğun değil
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          child: FilledButton(
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(40), // daha kısa
              padding: const EdgeInsets.symmetric(vertical: 10),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () => _showVariantsSheet(p),
            child: const Text('Paket Seç'),
          ),
        ),
      ],
    ),
  );
}
Widget _productCard55(Product p) {
  final url = p.image.startsWith('http') ? p.image : AppConfig.imageUrl(p.image);

  return Card(
    clipBehavior: Clip.antiAlias,
    child: Column(
      mainAxisSize: MainAxisSize.min,                 // <-- önemli
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Görsel
        AspectRatio(
          aspectRatio: 4/3,
          child: Image.network(
            url,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Icon(Icons.image_not_supported_outlined),
          ),
        ),

        // Ürün adı (çok az alt boşluk)
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
          child: Text(
            p.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ),

        // Paket Seç butonu — küçük ve yakın
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
          child: SizedBox(
            height: 38,                                 // düşük yükseklik
            child: FilledButton(
              onPressed: () => _showVariantsSheet(p),
              child: const Text('Paket Seç'),
            ),
          ),
        ),
      ],
    ),
  );
}
Widget _productCard(Product p) {
  final url = p.image.startsWith('http') ? p.image : AppConfig.imageUrl(p.image);

  return Card(
    clipBehavior: Clip.antiAlias,
    child: Column(
      mainAxisSize: MainAxisSize.min,               // içeriği kadar yükseklik
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Görsel: genişliğe göre yükseklik, taşma yok
        AspectRatio(
          aspectRatio: 4/3,                         // 1.33: resim alanı
          child: Image.network(
            url,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Icon(Icons.image_not_supported_outlined),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
          child: Text(
            p.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
          child: SizedBox(
            height: 36,                              // küçük, sabit buton
            child: FilledButton(
              onPressed: () => _showVariantsSheet(p),
              child: const Text('Paket Seç'),
            ),
          ),
        ),
      ],
    ),
  );
}

 void _showVariantsSheet(Product p) {
  final cs = Theme.of(context).colorScheme;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (_) {
      final Map<int, double> qty = { for (final v in p.variants) v.id : 1 };

      return StatefulBuilder(
        builder: (context, setS) {
          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text(p.name, style: Theme.of(context).textTheme.titleLarge)),
                      IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
                    ],
                  ),
                  const SizedBox(height: 8),

                  ...p.variants.map((v) {
                    final q = qty[v.id] ?? 1;
                    final lineTotal = v.price * q;

                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: cs.surfaceVariant.withOpacity(.50),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(v.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.titleMedium),
                                const SizedBox(height: 2),
                                Text('${tl(v.price)} / ${v.unit}',
                                  style: Theme.of(context).textTheme.bodySmall),
                              ],
                            ),
                          ),

                          // Miktar: anlık güncelleniyor
                          QtyInput(
                            value: q,
                            min: 0, // 0 istersen 1 yap
                            onChanged: (val) => setS(() => qty[v.id] = val),
                          ),
                          const SizedBox(width: 8),

                          FilledButton.tonal(
                            onPressed: q <= 0
                                ? null
                                : () {
                                    // 1) odakı kapat (son girilen değer commit olsun)
                                    FocusManager.instance.primaryFocus?.unfocus();

                                    // 2) en güncel miktarı al
                                    final currentQ = qty[v.id] ?? 1;

                                    // 3) sepete ekle ve toplamı bildir
                                    Cart.I.add(p, v, qtyCases: currentQ);
                                    Navigator.pop(context);
                                /*      ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text(
                                        '${p.name} - ${v.name} x $currentQ eklendi (Toplam: ${tl(v.price * currentQ)})',
                                      )),
                                    );*/
                                    setState(() {}); // üst listeyi tazelemek istersen
                                  },
                            child: Text('Ekle\n${tl(lineTotal)}', textAlign: TextAlign.center),
                          ),
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

void _showVariantsSheet2(Product p) {
  final cs = Theme.of(context).colorScheme;
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (_) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(p.name, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            ...p.variants.map((v) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: cs.surfaceVariant.withOpacity(.5),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text('${v.name} • ${tl(v.price)} / ${v.unit}',
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  ),
                  IconButton.filledTonal(
                    onPressed: () {
                      Cart.I.add(p, v, qtyCases: 1);
                      Navigator.pop(context);
                   /*   ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('${p.name} - ${v.name} eklendi')),
                      );*/
                      setState(() {});
                    },
                    icon: const Icon(Icons.add_shopping_cart),
                  ),
                ],
              ),
            )),
            const SizedBox(height: 8),
          ],
        ),
      ),
    ),
  );
}
  Widget _productCard2(Product p) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            flex: 5,
            child: Image.network(
              p.image,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  const Icon(Icons.image_not_supported_outlined),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(p.name,
                maxLines: 1, overflow: TextOverflow.ellipsis),
          ),
          Expanded(
            flex: 3,
            child: ListView.builder(
              itemCount: p.variants.length,
              itemBuilder: (_, i) {
                final v = p.variants[i];
                return ListTile(
                  dense: true,
                  title: Text('${v.name} • ${tl(v.price)} / ${v.unit}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.add_shopping_cart),
                    onPressed: () {
                      Cart.I.add(p, v, qtyCases: 1);
                      setState(() {});
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _cartPanel() {
    return Consumer<Cart>(
      builder: (context, cart, _) {
        final lines = cart.items;
        final total = cart.total;

        return Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.shopping_cart),
                title: const Text('Sepet'),
                trailing: lines.isNotEmpty
                    ? TextButton(
                        onPressed: () => _cartClearAll(cart),
                        child: const Text('Temizle'),
                      )
                    : null,
              ),
              if (lines.isEmpty)
                const Expanded(child: Center(child: Text('Sepet boş')))
              else
                Expanded(
                  child: ListView.builder(
                    itemCount: lines.length,
                    itemBuilder: (_, i) {
                      final line = lines[i];
                      final p = line!.product as Product;
                      final v = line.variant as ProductVariant;
                      final qty = line.qtyCases ?? 1;
                      return ListTile(
                        title: Text('${p.name} - ${v.name}'),
                        subtitle: Text('${tl(v.price)} x $qty'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                                icon: const Icon(Icons.remove),
                                onPressed: () => _cartDec(p, v, qty as int)),
                            Text('$qty'),
                            IconButton(
                                icon: const Icon(Icons.add),
                                onPressed: () => _cartInc(p, v)),
                            IconButton(
                                icon: const Icon(Icons.close),
                                onPressed: () => _cartRemove(p, v, qty as double)),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              if (lines.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      const Expanded(child: Text('Toplam')),
                      Text(tl(total)),
                    ],
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
