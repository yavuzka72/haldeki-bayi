class ApiConfig {
  /// iOS Sim: http://127.0.0.1:8000
  /// Android Emu: http://10.0.2.2:8000
  /// Prod: https://haldeki.com
  static String base = 'https://haldeki.com'; // değiştirilebilir
  static String get v1 => '$base/api/v1';
}
