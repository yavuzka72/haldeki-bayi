// lib/services/api_client.dart
import 'dart:convert';
import 'dart:io'; // File için
import 'package:dio/dio.dart';
import 'package:haldeki_admin_web/models/category.dart';
import 'package:haldeki_admin_web/models/paginated.dart';
import 'package:haldeki_admin_web/models/supplier.dart';
import 'package:haldeki_admin_web/services/session.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../config.dart';
import 'package:http/http.dart' as http;
class ApiClient {
  // --- Singleton ---
  ApiClient._internal();
  static final ApiClient _i = ApiClient._internal();
  
  factory ApiClient() => _i;

  late final Dio _dio;
  late final SharedPreferences _prefs;
   int? currentUserId;   
  Dio get dio => _dio;
     
  UserSession? _session;
  UserSession? get session => _session;
 

Uri _u(String path, [Map<String, dynamic>? q]) => Uri.parse('$AppConfig.apiBase$path').replace(
queryParameters: (q?.map((k, v) => MapEntry(k, v?.toString())) ?? {}),
);

Map<String, String> get _jsonHeaders => {
HttpHeaders.contentTypeHeader: 'application/json; charset=utf-8',
HttpHeaders.acceptHeader: 'application/json',
};

Future<Paginated<T>> _getPage<T>(String path, T Function(Map<String, dynamic>) fromJson,
{Map<String, dynamic>? query}) async {
final r = await http.get(_u(path, query));
if (r.statusCode >= 400) throw HttpException('GET $path failed: ${r.statusCode} ${r.body}');
final m = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
return Paginated<T>.fromLaravel(m, fromJson);
}

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();

    // baseUrl'in sonuna "/" ekliyoruz ki alt path'lerde başa "/" koymadan kullanabilelim.
    _dio = Dio(
      BaseOptions(
        baseUrl: '${AppConfig.apiBase}/',
        connectTimeout: const Duration(seconds: 15),
        receiveTimeout: const Duration(seconds: 20),
        headers: const {
          'Accept': 'application/json',
          'Accept-Language': 'tr-TR',
        },
      ),
    );
 
    // Token varsa header'a koy
    final token = _prefs.getString('token');
    if (token?.isNotEmpty == true) {
      _dio.options.headers['Authorization'] = 'Bearer $token';
    }

    // Log + 401 yakalama
    _dio.interceptors.add(LogInterceptor(
      requestBody: true,
      responseBody: false,
      requestHeader: false,
    ));

    _dio.interceptors.add(
      InterceptorsWrapper(
        onError: (e, handler) async {
          if (e.response?.statusCode == 401) {
            await setToken(null); // oturumu düşür
          }
          handler.next(e);
        },
      ),
    );
  }


 Future<void> setSession(UserSession session) async {
    _session = session;
    await _prefs.setString('user_session', session.toEncoded());
  }
  // ---- Token Yönetimi ----
  Future<bool> isLoggedIn() async => _prefs.getString('token') != null;

  Future<void> setToken(String? token) async {
    if (token == null || token.isEmpty) {
      await _prefs.remove('token');
      _dio.options.headers.remove('Authorization');
    } else {
      await _prefs.setString('token', token);
      _dio.options.headers['Authorization'] = 'Bearer $token';
    }
  }

  // ---- AUTH ----
  // DİKKAT: baseUrl zaten ayarlı; absolute URL vermiyoruz.
  Future<Response> login(String email, String password) =>
      _dio.post('login', data: {'email': email, 'password': password});

  Future<Response> me() => _dio.get('auth/me');

  Future<void> logout() async {
    try {
      await _dio.post('logout');
    } catch (_) {}
    await setToken(null);
  }

  // ---- JSON yardımcıları (Dashboard/Orders gibi ekranlar için pratik) ----
  Future<Map<String, dynamic>> getJson(
    String path, {
    Map<String, dynamic>? query,
  }) async {
    final res = await _dio.get(path, queryParameters: query);
    final data = res.data;
    if (data is Map<String, dynamic>) return data;
    return {'data': data};
  }

  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, dynamic> body, {
    Map<String, dynamic>? query,
    Map<String, String>? headers,
  }) async {
    final res = await _dio.post(
      path,
      data: body,
      queryParameters: query,
      options: headers == null ? null : Options(headers: headers),
    );
    final data = res.data;
    if (data is Map<String, dynamic>) return data;
    return {'data': data};
  }

  // ---- CATALOG / ORDERS (istersen direkt kullan) ----
  Future<Response> categories() => _dio.get('categories');

  Future<Response> listings({String? q, int? categoryId, int page = 1}) =>
      _dio.get('listings', queryParameters: {
        if (q != null && q.isNotEmpty) 'q': q,
        if (categoryId != null) 'category_id': categoryId,
        'page': page,
      });

  Future<Response> listing(int id) => _dio.get('listings/$id');

  Future<bool> toggleFavorite(int id) async {
    final r = await _dio.post('listings/$id/favorite');
    final d = r.data;
    if (d is Map) return d['liked'] == true;
    return true; // true/false sunucunun döndürdüğüne göre değişir.
  }

  // lib/services/api_client.dart  (ApiClient sınıfına ekle)
  Future<List<dynamic>> previousOrdersByEmail(String email) async {
    final res = await _dio.post('previous-orders', data: {'email': email});
    final data = res.data;

    if (data is List) return data.cast<dynamic>();
    if (data is Map) {
      // data: [...]  veya  data: { data: [...] } durumlarını yakala
      final d = data['data'];
      if (d is List) return d.cast<dynamic>();
      if (d is Map && d['data'] is List) return (d['data'] as List).cast<dynamic>();
    }
    return const [];
  }

  // İstersen yardımcı kısa yollar:
  Future<Map<String, dynamic>> previousOrdersJson() => getJson('previous-orders');
  Future<Map<String, dynamic>> ordersJson() => getJson('orders');

  // ============================================================
  // AŞAĞIDAKİLER: Senin istediğin Product / Variant / Upload fonksiyonları
  // http yerine DIO kullanacak şekilde uyarlandı.
  // ============================================================

  // toJson() olan objeyi Map'e çevir; Map ise direkt kullan
  dynamic _body(dynamic req) {
    try {
      // ignore: avoid_dynamic_calls
      final m = req?.toJson();
      if (m is Map<String, dynamic>) return m;
    } catch (_) {}
    if (req is Map<String, dynamic>) return req;
    return req; // son çare
  }

  // -------------------------------
  // Products
  // -------------------------------
  Future<int> createProduct(dynamic req) async {
    final res = await _dio.post('api/products', data: _body(req));
    final m = res.data;
    if (m is Map && m['id'] != null) {
      return (m['id'] as num).toInt();
    }
    throw DioException(
      requestOptions: res.requestOptions,
      response: res,
      message: 'createProduct: Beklenen yanıt alınamadı',
    );
  }

  Future<void> updateProduct(int id, dynamic req) async {
    final res = await _dio.put('api/products/$id', data: _body(req));
    if (res.statusCode != null && res.statusCode! >= 400) {
      throw DioException(
        requestOptions: res.requestOptions,
        response: res,
        message: 'updateProduct başarısız (${res.statusCode})',
      );
    }
  }

  Future<void> deleteProduct(int id) async {
    final res = await _dio.delete('api/products/$id');
    if (res.statusCode != null && res.statusCode! >= 400) {
      throw DioException(
        requestOptions: res.requestOptions,
        response: res,
        message: 'deleteProduct başarısız (${res.statusCode})',
      );
    }
  }

  // -------------------------------
  // Variants & Prices
  // -------------------------------
  /// Laravel sayfalama yapısını `Map<String,dynamic>` olarak döndürür.
  /// (İstersen bunun için bir `Paginated<T>` modeli yazıp parse edebilirsin.)
  Future<Map<String, dynamic>> variants(
    int productId, {
    String? q,
    int page = 1,
  }) async {
    final res = await _dio.get(
      'api/products/$productId/variants',
      queryParameters: {
        if (q != null && q.isNotEmpty) 'q': q,
        'page': page,
      },
    );
    final data = res.data;
    if (data is Map<String, dynamic>) return data;
    return {'data': data};
  }

  Future<int> createVariant(int productId, dynamic req) async {
    final res = await _dio.post(
      'products/$productId/variants',
      data: _body(req),
    );
    final m = res.data;
    if (m is Map && m['id'] != null) {
      return (m['id'] as num).toInt();
    }
    throw DioException(
      requestOptions: res.requestOptions,
      response: res,
      message: 'createVariant: Beklenen yanıt alınamadı',
    );
  }

  Future<void> setVariantPrice(int variantId, dynamic req) async {
    final res = await _dio.post(
      'api/variants/$variantId/set-price',
      data: _body(req),
    );
    if (res.statusCode != null && res.statusCode! >= 400) {
      throw DioException(
        requestOptions: res.requestOptions,
        response: res,
        message: 'setVariantPrice başarısız (${res.statusCode})',
      );
    }
  }

  // -------------------------------
  // Upload
  // -------------------------------
  Future<String> uploadImage(File file) async {
    final form = FormData.fromMap({
      'image': await MultipartFile.fromFile(file.path),
    });
    final res = await _dio.post('api/upload', data: form);
    final m = res.data;
    if (m is Map && m['path'] is String) return m['path'] as String;
    throw DioException(
      requestOptions: res.requestOptions,
      response: res,
      message: 'uploadImage: Beklenen yanıt alınamadı',
    );
  }


 Future<Paginated<Supplier>> suppliers({String? q, int page = 1}) => _getPage<Supplier>(
'/api/suppliers',
(e) => Supplier.fromJson(e),
query: {if (q?.isNotEmpty == true) 'q': q, 'page': page},
);


Future<int> createSupplier(SupplierCreate req) async {
final r = await http.post(_u('/api/suppliers'), headers: _jsonHeaders, body: jsonEncode(req.toJson()));
if (r.statusCode >= 400) throw HttpException('createSupplier failed: ${r.statusCode} ${r.body}');
final m = jsonDecode(r.body) as Map<String, dynamic>;
return (m['id'] as num).toInt();
}

Future<void> updateSupplier(int id, SupplierUpdate req) async {
final r = await http.put(_u('/api/suppliers/$id'), headers: _jsonHeaders, body: jsonEncode(req.toJson()));
if (r.statusCode >= 400) throw HttpException('updateSupplier failed: ${r.statusCode} ${r.body}');
}


Future<void> deleteSupplier(int id) async {
final r = await http.delete(_u('/api/suppliers/$id'));
if (r.statusCode >= 400) throw HttpException('deleteSupplier failed: ${r.statusCode} ${r.body}');
}


// ===============================
// Categories
// ===============================
Future<Paginated<Category>> categories2({int? supplierId, String? q, int page = 1}) => _getPage<Category>(
'/api/categories',
(e) => Category.fromJson(e),
query: {
if (supplierId != null) 'supplier_id': supplierId,
if (q?.isNotEmpty == true) 'q': q,
'page': page,
},
);


Future<int> createCategory(CategoryCreate req) async {
final r = await http.post(_u('/api/categories'), headers: _jsonHeaders, body: jsonEncode(req.toJson()));
if (r.statusCode >= 400) throw HttpException('createCategory failed: ${r.statusCode} ${r.body}');
final m = jsonDecode(r.body) as Map<String, dynamic>;
return (m['id'] as num).toInt();
}


Future<void> updateCategory(int id, CategoryUpdate req) async {
final r = await http.put(_u('/api/categories/$id'), headers: _jsonHeaders, body: jsonEncode(req.toJson()));
if (r.statusCode >= 400) throw HttpException('updateCategory failed: ${r.statusCode} ${r.body}');
}


Future<void> deleteCategory(int id) async {
final r = await http.delete(_u('/api/categories/$id'));
if (r.statusCode >= 400) throw HttpException('deleteCategory failed: ${r.statusCode} ${r.body}');
}


}
