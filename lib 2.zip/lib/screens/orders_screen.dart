import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:haldeki_admin_web/models/supplier.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../services/api_client.dart';
import '../utils/format.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  // Veri
  List<_Order> _all = [];
  List<_Order> _visible = [];

  // Arama & sıralama
  final _search = TextEditingController();
  int? _sortColumnIndex;
  bool _sortAscending = true;

  // UI state
  bool _loading = true;
  String? _error;

  // Durum seçenekleri (UI/Türkçe)
  static const List<String> _statusOptions = [
    'bekliyor',
    'onaylandı',
 
    'iptal',
  ];

    static const List<String> _statusDealerOptions = [
    'hazırlanıyor',
    'sevk edildi',
    'yolda',
    'teslim edildi',
    'iptal',
  ];
  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  // İngilizce/çeşitli varyasyonları UI-Türkçe’ye çevir (dealer_status için)
  String _toUiSupStatus(String input) {
  final raw = (input ?? '').trim();
  if (raw.isEmpty) return 'bekliyor';

  // normalize: lowercase + TR karakter sadeleştirme
  final t = raw
      .toLowerCase()
      .replaceAll('ı', 'i')
      .replaceAll('ş', 's')
      .replaceAll('ğ', 'g')
      .replaceAll('ü', 'u')
      .replaceAll('ö', 'o')
      .replaceAll('ç', 'c');

  // --- Türkçe ipuçları ---
  if (t.contains('bekli'))                    return 'bekliyor';
  if (t.contains('hazir'))                    return 'hazırlanıyor';
  if (t.contains('sevk') ||   t.contains('kargo') || t.contains('transit'))
                                              return 'sevk edildi';
  if (t.contains('teslim'))                   return 'teslim edildi';
  if (t.contains('iptal')) return 'iptal';

  // --- İngilizce -> Türkçe ---
  // backend’inde var dediğin set: waiting, pending, shipped, delivered, cancelled
  switch (t) {
    case 'wait':
    case 'waiting':
      return 'bekliyor';

    case 'pending':
    case 'prepare':
    case 'preparing':
      return 'hazırlanıyor';

    case 'shipped':
    case 'in_transit':
    case 'on_the_way':
    case 'transit':
      return 'sevk edildi';

    case 'delivered':
    case 'complete':
    case 'completed':
      return 'teslim edildi';

    case 'cancel':
    case 'canceled':
    case 'cancelled':
    case 'rejected':
      return 'iptal';
  }

  // tanınmazsa boş kalmasın
  return 'bekliyor';
}


    String _toUiStatus(String input) {
    final t = input.toLowerCase().trim();

    // Türkçe anahtarlar
    if (t.contains('bekliyor')) return 'bekliyor';
    if (t.contains('onay')) return 'onaylandı';
 
   
    if (t.contains('iptal')) return 'iptal';

    // İngilizce -> Türkçe (dealer akışı)
    if (t == 'pending' || t == 'prepare' || t == 'preparing') return 'bekliyor';
    if (t == 'confirmed' || t == 'confirm' || t == 'approved' || t == 'accepted' || t == 'shipped') {
      return 'onaylandı';
    } 
    if (t == 'cancel' || t == 'canceled' || t == 'cancelled') return 'iptal';

    return input; // tanınmazsa olduğu gibi bırak
  }
  String _toUiDealerStatus(String input) {
    final t = input.toLowerCase().trim();

    // Türkçe anahtarlar
    if (t.contains('hazır')) return 'hazırlanıyor';
    if (t.contains('sevk')) return 'sevk edildi';
    if (t.contains('yol')) return 'yolda';
    if (t.contains('teslim')) return 'teslim edildi';
    if (t.contains('iptal')) return 'iptal';

    // İngilizce -> Türkçe (dealer akışı)
    if (t == 'pending' || t == 'prepare' || t == 'preparing') return 'hazırlanıyor';
    if (t == 'confirmed' || t == 'confirm' || t == 'approved' || t == 'accepted' || t == 'shipped') {
      return 'sevk edildi';
    }
    if (t == 'away' || t == 'in_transit' || t == 'on_the_way' || t == 'transit') return 'yolda';
    if (t == 'delivered' || t == 'complete' || t == 'completed') return 'teslim edildi';
    if (t == 'cancel' || t == 'canceled' || t == 'cancelled') return 'iptal';

    return input; // tanınmazsa olduğu gibi bırak
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final dio = context.read<ApiClient>().dio;
      const email = 'bayi@bayi.com'; // TODO: login’den al

      final res = await dio.post(
        AppConfig.dealerOrdersPath,
        data: {'email': email},
        queryParameters: {'page': 1},
      );

      final list = _parseOrdersPayload(res.data);
      setState(() {
        _all = list;
        _visible = List.of(_all);
        _applySort();
      });
    } catch (e) {
      setState(() => _error = 'Siparişler yüklenemedi: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // JSON -> _Order[]
  List<_Order> _parseOrdersPayload(dynamic payload) {
    List items;
    if (payload is List) {
      items = payload;
    } else if (payload is Map) {
      if (payload['data'] is List) {
        items = payload['data'];
      } else if (payload['results'] is List) {
        items = payload['results'];
      } else {
        items = [];
      }
    } else {
      items = [];
    }

    String pickStr(Map m, List<String> keys, {String fallback = ''}) {
      for (final k in keys) {
        final v = m[k];
        if (v == null) continue;
        final s = v.toString();
        if (s.isNotEmpty) return s;
      }
      return fallback;
    }

    double pickNum(Map m, List<String> keys) {
      for (final k in keys) {
        final v = m[k];
        if (v == null) continue;
        if (v is num) return v.toDouble();
        if (v is String) {
          final d = double.tryParse(v.replaceAll(',', '.'));
          if (d != null) return d;
        }
      }
      return 0.0;
    }

    DateTime pickDate(Map m, List<String> keys) {
      for (final k in keys) {
        final v = m[k];
        if (v is String) {
          final d = DateTime.tryParse(v);
          if (d != null) return d;
        }
        if (v is int) {
          final s = v.toString();
          if (s.length >= 13) return DateTime.fromMillisecondsSinceEpoch(v);
          if (s.length >= 10) return DateTime.fromMillisecondsSinceEpoch(v * 1000);
        }
      }
      return DateTime.now();
    }

    return items.whereType<Map>().map((raw0) {
      final raw = Map<String, dynamic>.from(raw0);

      final id = pickStr(raw, ['id', '_id', 'order_id'], fallback: '');
      final number = pickStr(
        raw,
        ['orderNumber', 'order_number', 'number', 'code', 'no'],
        fallback: id.isEmpty ? '—' : '#$id',
      );

      // dealer_status'i oku (önce EN, sonra TR alias)
      final rawDealerStatus = pickStr(
        raw,
        ['dealer_status', 'dealer_status_ui', 'status', 'state'],
        fallback: '',
      );
      final rawStatus = pickStr(
        raw,
        ['status', 'status_ui', 'status', 'state', 'status'],
        fallback: '',
      );

       final rawStatuSup = pickStr(
        raw,
        ['status', 'status_ui', 'status', 'state', 'status'],
        fallback: '',
      );
      final rawSupplierStatus = pickStr(
        raw,
        ['supplier_status', 'supplierStatus', 'supplier_status_ui', 'supplierState'],
        fallback: '',
      );


      final createdAt =
          pickDate(raw, ['createdAt', 'created_at', 'date', 'ordered_at', 'created_at_iso']);
      final total = pickNum(raw, ['total', 'total_amount', 'amount', 'grand_total']);
      final address =
          pickStr(raw, ['shippingAddress', 'shipping_address', 'address', 'delivery_address']);

      // JOIN ile gelebilecek alias'lar
      final buyerName = pickStr(raw, ['buyer_name', 'buyerName']);
      final buyerCity = pickStr(raw, ['buyer_city', 'buyerCity']);
      final buyerDistrict = pickStr(raw, ['buyer_district', 'buyerDistrict']);

      final createdBy = pickStr(
        raw,
        ['createdByName', 'created_by_name', 'user_name', 'customer_name', 'createdBy'],
        fallback: buyerName,
      );

      return _Order(
        id: id,
        orderNumber: number,
        status: _toUiStatus(rawStatus), // UI’da
        dealer_status: _toUiDealerStatus(rawDealerStatus), 
        supplier_status:  _toUiSupStatus(rawSupplierStatus),
        // UI’da TR olarak tutuluyor
        createdAt: createdAt,
        totalAmount: total,
        shippingAddress: address.isEmpty ? null : address,
        createdByName: createdBy.isEmpty ? '—' : createdBy,
        buyerName: buyerName.isEmpty ? null : buyerName,
        buyerCity: buyerCity.isEmpty ? null : buyerCity,
        buyerDistrict: buyerDistrict.isEmpty ? null : buyerDistrict,
      );
    }).toList();
  }

  void _applyFilters() {
    final q = _search.text.trim().toLowerCase();
    setState(() {
      _visible = _all.where((o) {
        final okQuery = q.isEmpty ||
            o.orderNumber.toLowerCase().contains(q) ||
            (o.shippingAddress ?? '').toLowerCase().contains(q) ||
            o.createdByName.toLowerCase().contains(q) ||
            (o.buyerName ?? '').toLowerCase().contains(q) ||
            (o.buyerCity ?? '').toLowerCase().contains(q) ||
            (o.buyerDistrict ?? '').toLowerCase().contains(q);
        return okQuery;
      }).toList();
      _applySort();
    });
  }


    Future<void> _pickAndUpdateStatus(_Order o) async {
    String selected = o.status;

    final newStatus = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Durumu Güncelle'),
        content: StatefulBuilder(
          builder: (ctx, setS) {
            return DropdownButton<String>(
              value: _statusOptions.contains(selected) ? selected : _statusOptions.first,
              isExpanded: true,
              items: _statusOptions
                  .map((s) => DropdownMenuItem<String>(value: s, child: Text(_statusLabel(s))))
                  .toList(),
              onChanged: (v) => setS(() => selected = v ?? selected),
            );
          },
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, selected), child: const Text('Kaydet')),
        ],
      ),
    );

    if (newStatus == null || newStatus == o.status) return;

    try {
      await _sendStatusUpdate(o.orderNumber, newStatus);
      // Lokale yansıt
      setState(() {
        final ix = _all.indexWhere((e) => e.orderNumber == o.orderNumber);
        if (ix >= 0) _all[ix] = _all[ix].copyWith(status: newStatus);
        final vx = _visible.indexWhere((e) => e.orderNumber == o.orderNumber);
        if (vx >= 0) _visible[vx] = _visible[vx].copyWith(status: newStatus);
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Durum güncellendi: ${_statusLabel(newStatus)}')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Güncelleme başarısız: $e')),
      );
    }
  }




  Future<void> _pickDealerAndUpdateStatus(_Order o) async {
    String selected = o.dealer_status;

    final newStatus = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Durumu Güncelle'),
        content: StatefulBuilder(
          builder: (ctx, setS) {
            return DropdownButton<String>(
              value: _statusDealerOptions.contains(selected) ? selected : _statusDealerOptions.first,
              isExpanded: true,
              items: _statusDealerOptions
                  .map((s) => DropdownMenuItem<String>(value: s, child: Text(_statusDealerLabel(s))))
                  .toList(),
              onChanged: (v) => setS(() => selected = v ?? selected),
            );
          },
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, selected), child: const Text('Kaydet')),
        ],
      ),
    );

    if (newStatus == null || newStatus == o.dealer_status) return;

    try {
      await _sendDealerStatusUpdate(o.orderNumber, newStatus);
      // Lokale yansıt
      setState(() {
        final ix = _all.indexWhere((e) => e.orderNumber == o.orderNumber);
        if (ix >= 0) _all[ix] = _all[ix].copyWith(dealer_status: newStatus);
        final vx = _visible.indexWhere((e) => e.orderNumber == o.orderNumber);
        if (vx >= 0) _visible[vx] = _visible[vx].copyWith(dealer_status: newStatus);
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Durum güncellendi: ${_statusLabel(newStatus)}')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Güncelleme başarısız: $e')),
      );
    }
  }

  Future<void> _sendStatusUpdate(String orderNumber, String uiStatusTr) async {
    final dio = context.read<ApiClient>().dio;
    const email = 'bayi@bayi.com'; // TODO: login’den al

    // Backend TR->EN map yaptığı için UI’daki TR’yi gönderiyoruz.
    // Geçiş sürecinde uyumluluk için dealer_status + status beraber.
    await dio.post(
      'order-update-status',
      data: {
        'email': email,
        'order_number': orderNumber,
      
        'status': uiStatusTr,        // geriye uyumluluk
      },
    );
  }



  Future<void> _sendDealerStatusUpdate(String orderNumber, String uiStatusTr) async {
    final dio = context.read<ApiClient>().dio;
    const email = 'bayi@bayi.com'; // TODO: login’den al

    // Backend TR->EN map yaptığı için UI’daki TR’yi gönderiyoruz.
    // Geçiş sürecinde uyumluluk için dealer_status + status beraber.
    await dio.post(
      'dealer-order-update-status',
      data: {
        'email': email,
        'order_number': orderNumber,
        'dealer_status': uiStatusTr, // tercih edilen parametre
           // geriye uyumluluk
      },
    );
  }
  void _applySort() {
    if (_sortColumnIndex == null) return;
    final col = _sortColumnIndex!;
    _visible.sort((a, b) {
      int cmp;
      switch (col) {
        case 0: // Sipariş
          cmp = a.orderNumber.compareTo(b.orderNumber);
          break;
        case 1: // İşletme
          cmp = (a.buyerName ?? '').compareTo(b.buyerName ?? '');
          break;
        case 2: // Şehir
          cmp = (a.buyerCity ?? '').compareTo(b.buyerCity ?? '');
          break;
        case 3: // İlçe
          cmp = (a.buyerDistrict ?? '').compareTo(b.buyerDistrict ?? '');
          break;
        case 4: // Bayi Durumu
           cmp = a.status.compareTo(b.status);
          break;
         case 5: // Sipariş Durumu
    
               cmp = a.dealer_status.compareTo(b.dealer_status);
          break;
        case 6: // Tarih
          cmp = a.createdAt.compareTo(b.createdAt);
          break;
        case 7: // Tutar
          cmp = a.totalAmount.compareTo(b.totalAmount);
          break;
        default:
          cmp = 0;
      }
      return _sortAscending ? cmp : -cmp;
    });
  }

  void _onSort(int columnIndex, bool ascending) {
    setState(() {
      _sortColumnIndex = columnIndex;
      _sortAscending = ascending;
      _applySort();
    });
  }

  // ---------- BUILD ----------
  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_outlined, size: 48),
            const SizedBox(height: 8),
            Text(_error!),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _load,
              icon: const Icon(Icons.refresh),
              label: const Text('Tekrar dene'),
            ),
          ],
        ),
      );
    }

    final total = _visible.fold<double>(0, (s, o) => s + o.totalAmount);
    final delivered = _visible.where((o) => _isDelivered(o.dealer_status)).length;
    final preparing = _visible.where((o) => _toUiStatus(o.dealer_status) == 'hazırlanıyor').length;

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _load,
        child: LayoutBuilder(
          builder: (context, box) {
            final isWide = box.maxWidth >= 900;
            final cols = box.maxWidth >= 700 ? 2 : 1;

            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                _metricsGrid(cols: cols, total: total, delivered: delivered, preparing: preparing),
                const SizedBox(height: 16),

                ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 480),
                  child: TextField(
                    controller: _search,
                    decoration: InputDecoration(
                      hintText: 'Sipariş no, işletme veya adres ara…',
                      prefixIcon: const Icon(Icons.search),
                      isDense: true,
                      suffixIcon: _search.text.isEmpty
                          ? null
                          : IconButton(
                              tooltip: 'Temizle',
                              onPressed: () {
                                setState(() => _search.clear());
                                _applyFilters();
                              },
                              icon: const Icon(Icons.close),
                            ),
                    ),
                    onChanged: (_) => _applyFilters(),
                  ),
                ),
                const SizedBox(height: 12),

                Card(
                  clipBehavior: Clip.antiAlias,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: _visible.isEmpty
                        ? _emptyState()
                        : (isWide ? _ordersWideTable(shrinkWrap: true) : _ordersCardsList(shrinkWrap: true)),
                  ),
                ),

                const SizedBox(height: 24),
              ],
            );
          },
        ),
      ),
    );
  }

  // ---------- Parçalar ----------

  Widget _metricsGrid({
    required int cols,
    required double total,
    required int delivered,
    required int preparing,
  }) {
    final items = <Widget>[
      _metricCard(context, 'Toplam Tutar', tl(total), Icons.paid_outlined),
      _metricCard(context, 'Teslim edilen', '$delivered', Icons.check_circle_outline),
      _metricCard(context, 'Hazırlanan', '$preparing', Icons.inventory_2_outlined),
      _metricCard(context, 'Sipariş', '${_visible.length}', Icons.receipt_long_outlined),
    ];

    return LayoutBuilder(
      builder: (context, box) {
        final gap = 16.0;
        final cardW = (box.maxWidth - gap * (cols - 1)) / cols;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [for (final w in items) SizedBox(width: cardW, child: w)],
        );
      },
    );
  }

  Widget _statusBuyyerWithEdit(_Order o) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _statusDealerChip(o.dealer_status),
        const SizedBox(width: 6),
        IconButton(
          tooltip: 'Durumu güncelle',
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
          icon: const Icon(Icons.edit_outlined, size: 16),
          onPressed: () => _pickDealerAndUpdateStatus
          (o),
        ),
      ],
    );
  }

  Widget _statusWithEdit(_Order o) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _statusChip(o.status),
        const SizedBox(width: 6),
        IconButton(
          tooltip: 'Durumu güncelle',
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
          icon: const Icon(Icons.edit_outlined, size: 16),
          onPressed: () => _pickAndUpdateStatus(o),
        ),
      ],
    );
  }

  /// Dar ekran kart listesi
  Widget _ordersCardsList({required bool shrinkWrap}) {
    return ListView.separated(
      shrinkWrap: shrinkWrap,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _visible.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        final o = _visible[i];
        final buyerLine = [
          if (o.buyerName != null && o.buyerName!.isNotEmpty) o.buyerName!,
          if ((o.buyerCity ?? '').isNotEmpty && (o.buyerDistrict ?? '').isNotEmpty)
            '${o.buyerCity}/${o.buyerDistrict}'
          else if ((o.buyerCity ?? '').isNotEmpty)
            o.buyerCity!
          else if ((o.buyerDistrict ?? '').isNotEmpty)
            o.buyerDistrict!,
        ].join(' • ');

        return InkWell(
          onTap: () => context.go('/orders/${Uri.encodeComponent(o.orderNumber)}'),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 2))],
            ),
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(o.orderNumber, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      if (buyerLine.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Text(
                            buyerLine,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.black87),
                          ),
                        ),
                              Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        spacing: 10,
                        children: [
                          _statusWithEdit(o),
                  
                        ],
                      ),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        spacing: 10,
                        children: [
                          _statusBuyyerWithEdit(o),
                          Text(dt(o.createdAt), style: const TextStyle(color: Colors.black54)),
                        ],
                      ),
                      if (o.shippingAddress != null && o.shippingAddress!.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(
                          o.shippingAddress!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.black54),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(tl(o.totalAmount), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 8),
                    const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.black38),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Geniş ekran DataTable
  Widget _ordersWideTable({required bool shrinkWrap}) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const NeverScrollableScrollPhysics(),
      child: ConstrainedBox(
        constraints: const BoxConstraints(minWidth: 900),
        child: DataTable(
          columnSpacing: 28,
          sortColumnIndex: _sortColumnIndex,
          sortAscending: _sortAscending,
          columns: [
            DataColumn(label: const Text('Sipariş'), onSort: _onSort),
            DataColumn(label: const Text('İşletme'), onSort: _onSort),
            DataColumn(label: const Text('Şehir'), onSort: _onSort),
            DataColumn(label: const Text('İlçe'), onSort: _onSort),
            DataColumn(label: const Text('Sipariş Durumu'), onSort: _onSort),

                DataColumn(label: const Text('İşletme Durumu'), onSort: _onSort),
                       DataColumn(label: const Text('Tedarikçi Durumu'), onSort: _onSort),
            DataColumn(label: const Text('Tarih'), onSort: _onSort),
            DataColumn(numeric: true, label: const Text('Tutar'), onSort: _onSort),
            const DataColumn(label: Text('Aksiyon')),
          ],
          rows: [
            for (final o in _visible)
              DataRow(
                cells: [
                  DataCell(
                    TextButton(
                      onPressed: () => context.go('/orders/${Uri.encodeComponent(o.orderNumber)}'),
                      child: Text(o.orderNumber),
                    ),
                  ),
                  DataCell(Text(o.buyerName ?? '—')),
                  DataCell(Text(o.buyerCity ?? '—')),
                  DataCell(Text(o.buyerDistrict ?? '—')),
                     DataCell(_statusWithEdit(o)),
                  DataCell(_statusBuyyerWithEdit(o)),
                      DataCell( Text(o.supplier_status)),
                  DataCell(Text(dt(o.createdAt))),
                  DataCell(Text(tl(o.totalAmount))),
                  DataCell(
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          tooltip: 'Detay',
                          onPressed: () => context.go('/orders/${Uri.encodeComponent(o.orderNumber)}'),
                          icon: const Icon(Icons.open_in_new),
                        ),
                    
                    
                      ],
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  // ---- UI yardımcıları ----
  Widget _emptyState() => const Padding(
        padding: EdgeInsets.all(8.0),
        child: Center(child: Text('Eşleşen sipariş bulunamadı')),
      );

  Widget _metricCard(BuildContext context, String label, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(icon, size: 36),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(label),
                Text(value, style: Theme.of(context).textTheme.headlineSmall),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusChip(String status) {
    final s = _toUiStatus(status);
    final icon = _statusIcon(s);
    final bg = _statusBg(s);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 6),
          Text(_statusLabel(s)),
        ],
      ),
    );
  }

    Widget _statusSupChip(String statusSup) {
    final s = _toUiSupStatus(statusSup);
    final icon = _statusSupIcon(s);
    final bg = _statusSupBg(s);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 6),
          Text(_statusSupLabel(s)),
        ],
      ),
    );
  }
  Widget _statusDealerChip(String dealer_status) {
    final s = _toUiDealerStatus(dealer_status);
    final icon = _statusIconDealer(s);
    final bg = _statusBg(s);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 6),
          Text(_statusDealerLabel(s)),
        ],
      ),
    );
  }
  String _statusLabel(String status) {
    final s = _toUiStatus(status);
    switch (s) {
      case 'bekliyor': return 'Bekliyor';
      case 'onaylandı':  return 'onaylandı';
      case 'iptal':        return 'İptal';
      default:             return s;
    }
  }
  String _statusSupLabel(String s) {
  switch (s) {
    case 'bekliyor':      return 'Bekliyor';
    case 'hazırlanıyor':  return 'Hazırlanıyor';
    case 'sevk edildi':   return 'Sevk edildi';
    case 'teslim edildi': return 'Teslim edildi';
    case 'iptal':         return 'İptal';
    default:              return 'Bekliyor';
  }
}
  String _statusDealerLabel(String status) {
    final s = _toUiDealerStatus(status);
    switch (s) {
      case 'bekliyor': return 'Bekliyor';
      case 'sevk edildi':  return 'Sevk edildi';
      case 'yolda':        return 'Yolda';
      case 'teslim edildi':return 'Teslim edildi';
      case 'iptal':        return 'İptal';
      default:             return s;
    }
  }
  IconData _statusIcon(String status) {
    final s = _toUiStatus(status);
    switch (s) {
      case 'bekliypr': return Icons.warning_outlined;
      case 'onaylandı':  return Icons.confirmation_num_outlined;
    
      case 'iptal':        return Icons.cancel_outlined;
      default:             return Icons.info_outline;
    }
  }

    IconData _statusIconDealer(String status) {
    final s = _toUiDealerStatus(status);
    switch (s) {
      case 'bekliypr': return Icons.inventory_2_outlined;
      case 'sevk edildi':  return Icons.local_shipping_outlined;
      case 'yolda':        return Icons.route_outlined;
      case 'teslim edildi':return Icons.check_circle_outline;
      case 'iptal':        return Icons.cancel_outlined;
      default:             return Icons.info_outline;
    }
  }

  Color _statusBg(String status) {
    final s = _toUiStatus(status);
    switch (s) {
      case 'bekliypr': return Colors.amber.withOpacity(.15);
      case 'Onaylandı':  return Colors.blue.withOpacity(.15);
     
      case 'iptal':        return Colors.red.withOpacity(.15);
      default:             return Colors.grey.withOpacity(.15);
    }
  }

  Color _statusBgDelaer(String status) {
    final s = _toUiDealerStatus(status);
    switch (s) {
      case 'bekliypr': return Colors.amber.withOpacity(.15);
      case 'sevk edildi':  return Colors.blue.withOpacity(.15);
      case 'yolda':        return Colors.indigo.withOpacity(.15);
      case 'teslim edildi':return Colors.green.withOpacity(.15);
      case 'iptal':        return Colors.red.withOpacity(.15);
      default:             return Colors.grey.withOpacity(.15);
    }
  }


IconData _statusSupIcon(String s) {
  switch (s) {
    case 'bekliyor':      return Icons.hourglass_bottom_outlined;
    case 'hazırlanıyor':  return Icons.inventory_2_outlined;
    case 'sevk edildi':   return Icons.local_shipping_outlined;
    case 'teslim edildi': return Icons.check_circle_outline;
    case 'iptal':         return Icons.cancel_outlined;
    default:              return Icons.info_outline;
  }
}

Color _statusSupBg(String s) {
  switch (s) {
    case 'bekliyor':      return Colors.grey.withOpacity(.15);
    case 'hazırlanıyor':  return Colors.amber.withOpacity(.15);
    case 'sevk edildi':   return Colors.blue.withOpacity(.15);
    case 'teslim edildi': return Colors.green.withOpacity(.15);
    case 'iptal':         return Colors.red.withOpacity(.15);
    default:              return Colors.grey.withOpacity(.15);
  }
}
  bool _isDelivered(String s) => _toUiStatus(s) == 'teslim edildi';
    
}

// --------------------- View-model ---------------------

class _Order {
  final String id;
  final String orderNumber;
    final String status;
  final String dealer_status; 
   final String supplier_status;// UI’da TR tutuluyor
  final DateTime createdAt;
  final double totalAmount;
  final String? shippingAddress;
  final String createdByName;

  // Opsiyonel buyer alanları
  final String? buyerName;     // backend: buyer_name
  final String? buyerCity;     // backend: buyer_city
  final String? buyerDistrict; // backend: buyer_district

  _Order({
    required this.id,
    required this.orderNumber,
     required this.status,
    required this.dealer_status,
     required this.supplier_status,
    required this.createdAt,
    required this.totalAmount,
    required this.shippingAddress,
    required this.createdByName,
    this.buyerName,
    this.buyerCity,
    this.buyerDistrict,
  });

  _Order copyWith({
    String? id,
    String? orderNumber,
      String? status,
    String? dealer_status,
     String? supplier_status,
    DateTime? createdAt,
    double? totalAmount,
    String? shippingAddress,
    String? createdByName,
    String? buyerName,
    String? buyerCity,
    String? buyerDistrict,
  }) {
    return _Order(
      id: id ?? this.id,
      orderNumber: orderNumber ?? this.orderNumber,
      status: status ?? this.status,
      dealer_status: dealer_status ?? this.dealer_status,
        supplier_status: supplier_status ?? this.supplier_status,
      createdAt: createdAt ?? this.createdAt,
      totalAmount: totalAmount ?? this.totalAmount,
      shippingAddress: shippingAddress ?? this.shippingAddress,
      createdByName: createdByName ?? this.createdByName,
      buyerName: buyerName ?? this.buyerName,
      buyerCity: buyerCity ?? this.buyerCity,
      buyerDistrict: buyerDistrict ?? this.buyerDistrict,
    );
  }
}
