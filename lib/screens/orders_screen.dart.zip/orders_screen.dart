import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../services/api_client.dart';
import '../utils/format.dart';
import 'haldeki_ui.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  // Veri
  List<_Order> _all = [];
  List<_Order> _visible = [];

  // Arama & sıralama
  final _search = TextEditingController();
  int? _sortColumnIndex;
  bool _sortAscending = true;

  // UI state
  bool _loading = true;
  String? _error;

  // Dealer durum seçenekleri — ENUM (EN)
  static const List<String> _statusDealerOptions = [
    'pending',
    'courier',
    'delivered',
    'closed',
    'cancelled',
  ];

  // NORMAL (legacy TR) seçenekler — backend geriye uyumluluk için
  static const List<String> _statusOptions = [
    'bekliyor',
    'onaylandı',
    'yolda',
    'teslim',
    'iptal',
  ];

  // Üst bar filtre (dealer enum) — segment gibi çalışsın
  String? _dealerFilter; // null = tümü

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  // ---------------- API ----------------

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      // SADECE provider'daki ApiClient'ı kullan
      final api = context.read<ApiClient>();
      final dio = api.dio;

      final dealerEmail = api.currentEmail;

      if (dealerEmail == null || dealerEmail.isEmpty) {
        // Oturum yoksa login’e at veya hata göster
        setState(() {
          _error = 'Oturum bulunamadı. Lütfen tekrar giriş yapın.';
        });

        // İstersen login sayfasına yönlendir:
        if (mounted) {
          context.go('/login'); // senin route neyse
        }

        return; // devam etme
      }

      final res = await dio.post(
        AppConfig.dealerOrdersPath,
        data: {'email': dealerEmail},
        queryParameters: {'page': 1},
      );

      final list = _parseOrdersPayload(res.data);
      setState(() {
        _all = list;
        _visible = List.of(_all);
        _applyFilters();
        _applySort();
      });
    } catch (e) {
      setState(() => _error = 'Siparişler yüklenemedi: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _load2() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final dio = context.read<ApiClient>().dio;
      final api = ApiClient(); // veya context.read<ApiClient>();
      final dealerEmail = api.currentEmail;

      final String email = dealerEmail!;
      // 'denizli@haldeki.com'; // TODO: login’den al

      final res = await dio.post(
        AppConfig.dealerOrdersPath,
        data: {'email': email},
        queryParameters: {'page': 1},
      );

      final list = _parseOrdersPayload(res.data);
      setState(() {
        _all = list;
        _visible = List.of(_all);
        _applyFilters();
        _applySort();
      });
    } catch (e) {
      setState(() => _error = 'Siparişler yüklenemedi: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // JSON -> _Order[]
  List<_Order> _parseOrdersPayload(dynamic payload) {
    List items;
    if (payload is List) {
      items = payload;
    } else if (payload is Map) {
      if (payload['data'] is List) {
        items = payload['data'];
      } else if (payload['results'] is List) {
        items = payload['results'];
      } else {
        items = [];
      }
    } else {
      items = [];
    }

    debugPrint(
        '[OrdersScreen] payload type: ${payload.runtimeType}, items: ${items.length}');

    String pickStr(Map m, List<String> keys, {String fallback = ''}) {
      for (final k in keys) {
        final v = m[k];
        if (v == null) continue;
        final s = v.toString();
        if (s.isNotEmpty) return s;
      }
      return fallback;
    }

    double pickNum(Map m, List<String> keys) {
      for (final k in keys) {
        final v = m[k];
        if (v == null) continue;
        if (v is num) return v.toDouble();
        if (v is String) {
          final d = double.tryParse(v.replaceAll(',', '.'));
          if (d != null) return d;
        }
      }
      return 0.0;
    }

    DateTime pickDate(Map m, List<String> keys) {
      for (final k in keys) {
        final v = m[k];
        if (v is String) {
          final d = DateTime.tryParse(v);
          if (d != null) return d;
        }
        if (v is int) {
          final s = v.toString();
          if (s.length >= 13) return DateTime.fromMillisecondsSinceEpoch(v);
          if (s.length >= 10) {
            return DateTime.fromMillisecondsSinceEpoch(v * 1000);
          }
        }
      }
      return DateTime.now();
    }

    return items.whereType<Map>().map((raw0) {
      final raw = Map<String, dynamic>.from(raw0);

      // delivery_status parse
      final deliveryStatus = pickInt(raw, ['delivery_status'], fallback: 0);

      final id = pickStr(raw, ['id', '_id', 'order_id'], fallback: '');
      final number = pickStr(
        raw,
        ['orderNumber', 'order_number', 'number', 'code', 'no'],
        fallback: id.isEmpty ? '—' : '#$id',
      );

      final rawDealerStatus = pickStr(
        raw,
        ['dealer_status', 'dealer_status_ui', 'status', 'state'],
        fallback: '',
      );

      final rawStatus = pickStr(
        raw,
        ['status', 'status_ui', 'state'],
        fallback: '',
      );

      final rawSupplierStatus = pickStr(
        raw,
        [
          'supplier_status',
          'supplierStatus',
          'supplier_status_ui',
          'supplierState',
        ],
        fallback: '',
      );

      final createdAt = pickDate(raw, [
        'createdAt',
        'created_at',
        'date',
        'ordered_at',
        'created_at_iso',
      ]);

      final total =
          pickNum(raw, ['total', 'total_amount', 'amount', 'grand_total']);

      final address = pickStr(raw, [
        'shippingAddress',
        'shipping_address',
        'address',
        'delivery_address',
      ]);

      // JOIN ile gelebilecek alias'lar
      final buyerName = pickStr(raw, ['buyer_name', 'buyerName']);
      final buyerCity = pickStr(raw, ['buyer_city', 'buyerCity']);
      final buyerDistrict = pickStr(raw, ['buyer_district', 'buyerDistrict']);

      final createdBy = pickStr(
        raw,
        [
          'createdByName',
          'created_by_name',
          'user_name',
          'customer_name',
          'createdBy',
        ],
        fallback: buyerName,
      );

      // 🔍 DEBUG: delivery_status ham + parse edilmiş
      debugPrint(
          '[OrdersScreen] order=$number raw.delivery_status=${raw['delivery_status']} parsedDeliveryStatus=$deliveryStatus');

      return _Order(
        id: id,
        orderNumber: number,
        status: _toUiStatus(rawStatus), // legacy/TR
        dealer_status: _normalizeDealerStatusEnum(rawDealerStatus), // ENUM (EN)
        supplier_status: _toUiSupStatus(rawSupplierStatus), // TR
        createdAt: createdAt,
        totalAmount: total,
        shippingAddress: address.isEmpty ? null : address,
        createdByName: createdBy.isEmpty ? '—' : createdBy,
        buyerName: buyerName.isEmpty ? null : buyerName,
        buyerCity: buyerCity.isEmpty ? null : buyerCity,
        buyerDistrict: buyerDistrict.isEmpty ? null : buyerDistrict,
        deliveryStatus: deliveryStatus,
      );
    }).toList();
  }

  // ---------------- Filters & Sort ----------------

  void _applyFilters() {
    final q = _search.text.trim().toLowerCase();
    setState(() {
      Iterable<_Order> list = _all;

      if (_dealerFilter != null) {
        list = list.where((o) => o.dealer_status == _dealerFilter);
      }

      if (q.isNotEmpty) {
        list = list.where((o) =>
            o.orderNumber.toLowerCase().contains(q) ||
            (o.shippingAddress ?? '').toLowerCase().contains(q) ||
            o.createdByName.toLowerCase().contains(q) ||
            (o.buyerName ?? '').toLowerCase().contains(q) ||
            (o.buyerCity ?? '').toLowerCase().contains(q) ||
            (o.buyerDistrict ?? '').toLowerCase().contains(q));
      }

      _visible = list.toList();
    });
  }

  void _applySort() {
    if (_sortColumnIndex == null) return;
    final col = _sortColumnIndex!;
    _visible.sort((a, b) {
      int cmp;
      switch (col) {
        case 0: // Sipariş
          cmp = a.orderNumber.compareTo(b.orderNumber);
          break;
        case 1: // İşletme
          cmp = (a.buyerName ?? '').compareTo(b.buyerName ?? '');
          break;
        case 2: // Şehir
          cmp = (a.buyerCity ?? '').compareTo(b.buyerCity ?? '');
          break;
        case 3: // İlçe
          cmp = (a.buyerDistrict ?? '').compareTo(b.buyerDistrict ?? '');
          break;
        case 4: // NORMAL (TR) status
          cmp = _statusLabel(a.status).compareTo(_statusLabel(b.status));
          break;
        case 5: // Dealer ENUM
          cmp = _statusDealerLabel(a.dealer_status)
              .compareTo(_statusDealerLabel(b.dealer_status));
          break;
        case 6: // Tedarikçi TR status
          cmp = _statusSupLabel(a.supplier_status)
              .compareTo(_statusSupLabel(b.supplier_status));
          break;
        case 7: // Tarih
          cmp = a.createdAt.compareTo(b.createdAt);
          break;
        case 8: // Tutar
          cmp = a.totalAmount.compareTo(b.totalAmount);
          break;
        default:
          cmp = 0;
      }
      return _sortAscending ? cmp : -cmp;
    });
  }

  void _onSort(int columnIndex, bool ascending) {
    setState(() {
      _sortColumnIndex = columnIndex;
      _sortAscending = ascending;
      _applySort();
    });
  }

  // ---------------- Status helpers ----------------

  // Dealer ENUM normalize (EN)
  String _normalizeDealerStatusEnum(String? v) {
    final t = (v ?? '').toLowerCase().trim();
    if (_statusDealerOptions.contains(t)) return t;

    if (t == 'prepare' ||
        t == 'preparing' ||
        t.contains('hazır') ||
        t.contains('bekle')) {
      return 'pending';
    }
    if (t == 'shipped' ||
        t == 'in_transit' ||
        t == 'on_the_way' ||
        t == 'transit' ||
        t == 'away' ||
        t.contains('sevk') ||
        t.contains('kuryede') ||
        t.contains('yol')) {
      return 'courier';
    }
    if (t == 'delivered' ||
        t == 'completed' ||
        t == 'complete' ||
        t.contains('teslim')) {
      return 'delivered';
    }
    if (t == 'cancel' ||
        t == 'canceled' ||
        t == 'cancelled' ||
        t.contains('iptal')) {
      return 'cancelled';
    }
    if (t == 'closed' || t == 'done' || t == 'finished' || t == 'archived') {
      return 'closed';
    }
    return 'pending';
  }

  // Legacy/TR status → TR label kümeleri
  String _toUiStatus(String input) {
    final t = input.toLowerCase().trim();
    if (t.contains('bekli')) return 'bekliyor';
    if (t.contains('onay')) return 'onaylandı';
    if (t.contains('yol')) return 'yolda';
    if (t.contains('teslim')) return 'teslim';
    if (t.contains('iptal')) return 'iptal';

    // EN → TR
    if (t == 'pending' || t == 'prepare' || t == 'preparing') return 'bekliyor';
    if (t == 'confirmed' ||
        t == 'confirm' ||
        t == 'approved' ||
        t == 'accepted') {
      return 'onaylandı';
    }
    if (t == 'shipped' ||
        t == 'in_transit' ||
        t == 'on_the_way' ||
        t == 'away') {
      return 'yolda';
    }
    if (t == 'delivered' || t == 'completed' || t == 'complete') {
      return 'teslim';
    }
    if (t == 'cancel' || t == 'canceled' || t == 'cancelled') return 'iptal';

    return 'bekliyor';
  }

  /// Her satırı 3 oval bloğa bölen özel row
  Widget _orderSegmentRow(_Order o, int index, ColorScheme cs) {
    final rowBaseColor =
        index.isEven ? cs.surface : cs.primary.withOpacity(0.02);

    return Material(
      color: rowBaseColor,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(
          children: [
            // 1. BLOK — Sipariş, İşletme, Şehir, İlçe
            Expanded(
              flex: 4,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: cs.surfaceVariant.withOpacity(.45),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: TextButton(
                          onPressed: () => context.go(
                            '/orders/${Uri.encodeComponent(o.orderNumber)}',
                          ),
                          child: Text(o.orderNumber),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(o.buyerName ?? '—'),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(o.buyerCity ?? '—'),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(o.buyerDistrict ?? '—'),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(width: 8),

            // 2. BLOK — Sipariş Durumu + Tedarikçi Durumu
            Expanded(
              flex: 3,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: cs.primary.withOpacity(.05),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  children: [
                    Expanded(child: _statusLegacyWithEdit(o)),
                    const SizedBox(width: 8),
                    Expanded(child: _statusDealerWithEdit(o)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(_statusSupLabel(o.supplier_status)),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(width: 8),

            // 3. BLOK — Tarih, Tutar, Detay, Kuryelere Ata
            Expanded(
              flex: 3,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: cs.secondaryContainer.withOpacity(.55),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  children: [
                    // Tarih + Tutar
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            dt(o.createdAt),
                            style: const TextStyle(fontSize: 12),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            tl(o.totalAmount),
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Detay butonu
                    IconButton(
                      tooltip: 'Detay',
                      onPressed: () => context.go(
                        '/orders/${Uri.encodeComponent(o.orderNumber)}',
                      ),
                      icon: const Icon(Icons.open_in_new),
                    ),

                    // Kuryelere ata
                    IconButton(
                      tooltip: o.deliveryStatus == 1
                          ? 'Zaten kuryelere aktarılmış'
                          : 'Kuryelere Ata',
                      onPressed: o.deliveryStatus == 1
                          ? null
                          : () async {
                              try {
                                final resp = await context
                                    .read<ApiClient>()
                                    .handoffByOrderNumber(o.orderNumber);

                                final ok = (resp['success'] == true);
                                final msg = ok
                                    ? 'Kuryelere aktarıldı ✅'
                                    : (resp['message'] ?? 'İşlem tamamlandı');

                                if (ok) {
                                  setState(() {
                                    final ix = _all.indexWhere(
                                        (e) => e.orderNumber == o.orderNumber);
                                    if (ix >= 0) {
                                      _all[ix] =
                                          _all[ix].copyWith(deliveryStatus: 1);
                                    }
                                    final vx = _visible.indexWhere(
                                        (e) => e.orderNumber == o.orderNumber);
                                    if (vx >= 0) {
                                      _visible[vx] = _visible[vx]
                                          .copyWith(deliveryStatus: 1);
                                    }
                                  });
                                }

                                if (!mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text(msg)),
                                );
                              } catch (e) {
                                if (!mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Aktarma başarısız ❌'),
                                  ),
                                );
                              }
                            },
                      icon: Icon(
                        Icons.delivery_dining_outlined,
                        color: o.deliveryStatus == 1
                            ? Colors.purple.withOpacity(0.3)
                            : Colors.purple,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Supplier için TR normalize
  String _toUiSupStatus(String input) {
    final raw = (input).trim();
    if (raw.isEmpty) return 'bekliyor';
    final t = raw
        .toLowerCase()
        .replaceAll('ı', 'i')
        .replaceAll('ş', 's')
        .replaceAll('ğ', 'g')
        .replaceAll('ü', 'u')
        .replaceAll('ö', 'o')
        .replaceAll('ç', 'c');

    if (t.contains('bekli')) return 'bekliyor';
    if (t.contains('hazir')) return 'hazırlanıyor';
    if (t.contains('sevk') || t.contains('kargo') || t.contains('transit')) {
      return 'sevk edildi';
    }
    if (t.contains('teslim')) return 'teslim edildi';
    if (t.contains('iptal')) return 'iptal';

    switch (t) {
      case 'wait':
      case 'waiting':
      case 'pending':
        return 'bekliyor';
      case 'prepare':
      case 'preparing':
        return 'hazırlanıyor';
      case 'shipped':
      case 'in_transit':
      case 'on_the_way':
      case 'transit':
        return 'sevk edildi';
      case 'delivered':
      case 'complete':
      case 'completed':
        return 'teslim edildi';
      case 'cancel':
      case 'canceled':
      case 'cancelled':
      case 'rejected':
        return 'iptal';
    }
    return 'bekliyor';
  }

  String _statusLabel(String statusTr) {
    switch (statusTr) {
      case 'bekliyor':
        return 'Bekliyor';
      case 'onaylandı':
        return 'Onaylandı';
      case 'yolda':
        return 'Yolda';
      case 'teslim':
        return 'Teslim Edildi';
      case 'iptal':
        return 'İptal';
      default:
        return statusTr;
    }
  }

  String _statusSupLabel(String s) {
    switch (s) {
      case 'bekliyor':
        return 'Bekliyor';
      case 'hazırlanıyor':
        return 'Hazırlanıyor';
      case 'sevk edildi':
        return 'Sevk edildi';
      case 'teslim edildi':
        return 'Teslim Edildi';
      case 'iptal':
        return 'İptal';
      default:
        return 'Bekliyor';
    }
  }

  // Dealer label — ENUM (EN) → TR
  String _statusDealerLabel(String status) {
    switch (status) {
      case 'pending':
        return 'Bekliyor';
      case 'courier':
        return 'Sevk edildi';
      case 'delivered':
        return 'Teslim edildi';
      case 'closed':
        return 'Kapatıldı';
      case 'cancelled':
        return 'İptal';
      default:
        return status;
    }
  }

  IconData _statusIconDealer(String status) {
    switch (status) {
      case 'pending':
        return Icons.hourglass_bottom_outlined;
      case 'courier':
        return Icons.local_shipping_outlined;
      case 'delivered':
        return Icons.check_circle_outline;
      case 'closed':
        return Icons.inventory_2_outlined;
      case 'cancelled':
        return Icons.cancel_outlined;
      default:
        return Icons.info_outline;
    }
  }

  Color _statusBgDealer(String status) {
    switch (status) {
      case 'pending':
        return Colors.amber.withOpacity(.15);
      case 'courier':
        return Colors.blue.withOpacity(.15);
      case 'delivered':
        return Colors.green.withOpacity(.15);
      case 'closed':
        return Colors.grey.withOpacity(.15);
      case 'cancelled':
        return Colors.red.withOpacity(.15);
      default:
        return Colors.grey.withOpacity(.15);
    }
  }

  // ---------------- Status updaters / helpers ----------------

  int pickInt(Map m, List<String> keys, {int fallback = 0}) {
    for (final k in keys) {
      final v = m[k];
      if (v == null) continue;
      if (v is num) return v.toInt();
      if (v is String) {
        final i = int.tryParse(v);
        if (i != null) return i;
      }
    }
    return fallback;
  }

  Future<void> _pickAndUpdateStatus(_Order o) async {
    String selected = _toUiStatus(o.status);

    final newStatus = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Durumu Güncelle (legacy)'),
        content: StatefulBuilder(
          builder: (ctx, setS) {
            return DropdownButton<String>(
              value: _statusOptions.contains(selected)
                  ? selected
                  : _statusOptions.first,
              isExpanded: true,
              items: _statusOptions
                  .map((s) => DropdownMenuItem<String>(
                        value: s,
                        child: Text(_statusLabel(s)),
                      ))
                  .toList(),
              onChanged: (v) => setS(() => selected = v ?? selected),
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, selected),
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );

    if (newStatus == null || newStatus == _toUiStatus(o.status)) return;

    try {
      await _sendStatusUpdate(o.orderNumber, newStatus);
      setState(() {
        final ix = _all.indexWhere((e) => e.orderNumber == o.orderNumber);
        if (ix >= 0) _all[ix] = _all[ix].copyWith(status: newStatus);
        final vx = _visible.indexWhere((e) => e.orderNumber == o.orderNumber);
        if (vx >= 0) {
          _visible[vx] = _visible[vx].copyWith(status: newStatus);
        }
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Durum güncellendi: ${_statusLabel(newStatus)}'),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Güncelleme başarısız: $e')),
      );
    }
  }

  Future<void> _pickDealerAndUpdateStatus(_Order o) async {
    String selected = o.dealer_status; // ENUM

    final newStatus = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Sipariş Durumu Güncelle'),
        content: StatefulBuilder(
          builder: (ctx, setS) {
            return DropdownButton<String>(
              value: _statusDealerOptions.contains(selected)
                  ? selected
                  : _statusDealerOptions.first,
              isExpanded: true,
              items: _statusDealerOptions
                  .map((s) => DropdownMenuItem<String>(
                        value: s,
                        child: Text(_statusDealerLabel(s)),
                      ))
                  .toList(),
              onChanged: (v) => setS(() => selected = v ?? selected),
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, selected),
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );

    if (newStatus == null || newStatus == o.dealer_status) return;

    try {
      await _sendDealerStatusUpdate(o.orderNumber, newStatus); // ENUM gönder
      setState(() {
        final ix = _all.indexWhere((e) => e.orderNumber == o.orderNumber);
        if (ix >= 0) _all[ix] = _all[ix].copyWith(dealer_status: newStatus);
        final vx = _visible.indexWhere((e) => e.orderNumber == o.orderNumber);
        if (vx >= 0) {
          _visible[vx] = _visible[vx].copyWith(dealer_status: newStatus);
        }
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Durum güncellendi: ${_statusDealerLabel(newStatus)}'),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Güncelleme başarısız: $e')),
      );
    }
  }

  Future<void> _sendStatusUpdate(String orderNumber, String uiStatusTr) async {
    final dio = context.read<ApiClient>().dio;
    const email = 'bayi@bayi.com'; // TODO: login’den al

    await dio.post(
      'order-update-status',
      data: {
        'email': email,
        'order_number': orderNumber,
        'status': uiStatusTr, // geriye uyumluluk
      },
    );
  }

  Future<void> _sendDealerStatusUpdate(
      String orderNumber, String dealerEnum) async {
    final dio = context.read<ApiClient>().dio;
    const email = 'bayi@bayi.com'; // TODO: login’den al

    await dio.post(
      'dealer-order-update-status',
      data: {
        'email': email,
        'order_number': orderNumber,
        'dealer_status': dealerEnum, // ENUM (EN)
      },
    );
  }

  // ---------------- BUILD ----------------

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final themed = HaldekiUI.withRectButtons(context, cs).copyWith(
      inputDecorationTheme: HaldekiUI.inputDense(context),
      dataTableTheme: HaldekiUI.dataTableTheme(cs),
    );

    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_outlined, size: 48),
            const SizedBox(height: 8),
            Text(_error!),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _load,
              icon: const Icon(Icons.refresh),
              label: const Text('Tekrar dene'),
            ),
          ],
        ),
      );
    }

    final total = _visible.fold<double>(0, (s, o) => s + o.totalAmount);
    final delivered =
        _visible.where((o) => o.dealer_status == 'delivered').length;
    final preparing =
        _visible.where((o) => o.dealer_status == 'pending').length;

    return Theme(
      data: themed,
      child: SafeArea(
        child: RefreshIndicator(
          onRefresh: _load,
          child: LayoutBuilder(
            builder: (context, box) {
              final isWide = box.maxWidth >= 900;
              final cols = box.maxWidth >= 700 ? 2 : 1;

              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _metricsGrid(
                    cols: cols,
                    total: total,
                    delivered: delivered,
                    preparing: preparing,
                  ),
                  const SizedBox(height: 16),

                  // Filtre satırı: dealer durum segmentleri + arama
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      ...[
                        null,
                        ..._statusDealerOptions,
                      ].map((val) {
                        final selected = _dealerFilter == val ||
                            (_dealerFilter == null && val == null);
                        return HaldekiUI.rectOption(
                          context: context,
                          text: val == null ? 'Tümü' : _statusDealerLabel(val),
                          selected: selected,
                          onTap: () {
                            setState(() {
                              _dealerFilter = val;
                              _applyFilters();
                              _applySort();
                            });
                          },
                        );
                      }).toList(),
                      const SizedBox(width: 6),
                      ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 480),
                        child: TextField(
                          controller: _search,
                          decoration: InputDecoration(
                            hintText: 'Sipariş no, işletme veya adres ara…',
                            prefixIcon: const Icon(Icons.search),
                            isDense: true,
                            suffixIcon: _search.text.isEmpty
                                ? null
                                : IconButton(
                                    tooltip: 'Temizle',
                                    onPressed: () {
                                      setState(() => _search.clear());
                                      _applyFilters();
                                      _applySort();
                                    },
                                    icon: const Icon(Icons.close),
                                  ),
                          ),
                          onChanged: (_) {
                            _applyFilters();
                            _applySort();
                          },
                        ),
                      ),
                      const SizedBox(width: 6),
                      OutlinedButton.icon(
                        onPressed: () {
                          _applyFilters();
                          _applySort();
                        },
                        icon: const Icon(Icons.tune),
                        label: const Text('Filtrele'),
                      ),
                      const SizedBox(width: 6),
                      IconButton(
                        tooltip: 'Yenile',
                        onPressed: _load,
                        icon: const Icon(Icons.refresh),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // Liste / Tablo
                  DecoratedBox(
                    decoration: BoxDecoration(
                      color: cs.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: cs.outlineVariant),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: _visible.isEmpty
                          ? _emptyState()
                          : (isWide
                              ? _ordersWideTable(shrinkWrap: true)
                              : _ordersCardsList(shrinkWrap: true)),
                    ),
                  ),

                  const SizedBox(height: 24),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  // ---------- Parçalar ----------

  Widget _metricsGrid({
    required int cols,
    required double total,
    required int delivered,
    required int preparing,
  }) {
    final items = <Widget>[
      _metricCard(context, 'Toplam Tutar', tl(total), Icons.paid_outlined),
      _metricCard(
        context,
        'Teslim edilen',
        '$delivered',
        Icons.check_circle_outline,
      ),
      _metricCard(
        context,
        'Hazırlanan',
        '$preparing',
        Icons.inventory_2_outlined,
      ),
      _metricCard(
        context,
        'Sipariş',
        '${_visible.length}',
        Icons.receipt_long_outlined,
      ),
    ];

    return LayoutBuilder(
      builder: (context, box) {
        final gap = 16.0;
        final cardW = (box.maxWidth - gap * (cols - 1)) / cols;
        return Wrap(
          spacing: gap,
          runSpacing: gap,
          children: [for (final w in items) SizedBox(width: cardW, child: w)],
        );
      },
    );
  }

  Widget _statusDealerWithEdit(_Order o) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _statusDealerChip(o.dealer_status),
        const SizedBox(width: 6),
        IconButton(
          tooltip: 'Durumu güncelle',
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
          icon: const Icon(Icons.edit_outlined, size: 16),
          onPressed: () => _pickDealerAndUpdateStatus(o),
        ),
      ],
    );
  }

  Widget _statusLegacyWithEdit(_Order o) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _statusLegacyChip(o.status),
        const SizedBox(width: 6),
        IconButton(
          tooltip: 'Durumu güncelle',
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
          icon: const Icon(Icons.edit_outlined, size: 16),
          onPressed: () => _pickAndUpdateStatus(o),
        ),
      ],
    );
  }

  /// Dar ekran kart listesi
  Widget _ordersCardsList({required bool shrinkWrap}) {
    return ListView.separated(
      shrinkWrap: shrinkWrap,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _visible.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        final o = _visible[i];
        final buyerLine = [
          if (o.buyerName != null && o.buyerName!.isNotEmpty) o.buyerName!,
          if ((o.buyerCity ?? '').isNotEmpty &&
              (o.buyerDistrict ?? '').isNotEmpty)
            '${o.buyerCity}/${o.buyerDistrict}'
          else if ((o.buyerCity ?? '').isNotEmpty)
            o.buyerCity!
          else if ((o.buyerDistrict ?? '').isNotEmpty)
            o.buyerDistrict!,
        ].join(' • ');

        return InkWell(
          onTap: () =>
              context.go('/orders/${Uri.encodeComponent(o.orderNumber)}'),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        o.orderNumber,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 6),
                      if (buyerLine.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Text(
                            buyerLine,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.black87),
                          ),
                        ),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        spacing: 10,
                        children: [
                          _statusLegacyWithEdit(o),
                        ],
                      ),
                      Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        spacing: 10,
                        children: [
                          _statusDealerWithEdit(o),
                          Text(
                            dt(o.createdAt),
                            style: const TextStyle(color: Colors.black54),
                          ),
                        ],
                      ),
                      if (o.shippingAddress != null &&
                          o.shippingAddress!.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(
                          o.shippingAddress!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.black54),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      tl(o.totalAmount),
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Icon(
                      Icons.arrow_forward_ios,
                      size: 16,
                      color: Colors.black38,
                    ),
                    const Icon(
                      Icons.access_alarms_outlined,
                      size: 16,
                      color: Colors.black38,
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Her satırı 3 oval bloğa bölen özel row
  Widget _orderSegmentRow2(_Order o, int index, ColorScheme cs) {
    final rowBaseColor =
        index.isEven ? cs.surface : cs.primary.withOpacity(0.01);

    return Material(
      color: rowBaseColor,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(
          children: [
            // 1. BLOK — Sipariş, İşletme, Şehir, İlçe
            Expanded(
              flex: 4,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: cs.surfaceVariant.withOpacity(.45),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: TextButton(
                          onPressed: () => context.go(
                            '/orders/${Uri.encodeComponent(o.orderNumber)}',
                          ),
                          child: Text(o.orderNumber),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 3,
                      child: Text(o.buyerName ?? '—'),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(o.buyerCity ?? '—'),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(o.buyerDistrict ?? '—'),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(width: 8),

            // 2. BLOK — Sipariş Durumu + Tedarikçi Durumu
            Expanded(
              flex: 3,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: cs.primary.withOpacity(.05),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  children: [
                    Expanded(child: _statusLegacyWithEdit(o)),
                    const SizedBox(width: 8),
                    Expanded(child: _statusDealerWithEdit(o)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(_statusSupLabel(o.supplier_status)),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(width: 8),

            // 3. BLOK — Tarih, Tutar, Detay, Kuryelere Ata
            Expanded(
              flex: 3,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: cs.secondaryContainer.withOpacity(.55),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Row(
                  children: [
                    // Tarih + Tutar
                    Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            dt(o.createdAt),
                            style: const TextStyle(fontSize: 12),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            tl(o.totalAmount),
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Detay
                    IconButton(
                      tooltip: 'Detay',
                      onPressed: () => context.go(
                        '/orders/${Uri.encodeComponent(o.orderNumber)}',
                      ),
                      icon: const Icon(Icons.open_in_new),
                    ),

                    // Kuryelere ata
                    IconButton(
                      tooltip: o.deliveryStatus == 1
                          ? 'Zaten kuryelere aktarılmış'
                          : 'Kuryelere Ata',
                      onPressed: o.deliveryStatus == 1
                          ? null
                          : () async {
                              try {
                                final resp = await context
                                    .read<ApiClient>()
                                    .handoffByOrderNumber(o.orderNumber);

                                final ok = (resp['success'] == true);
                                final msg = ok
                                    ? 'Kuryelere aktarıldı ✅'
                                    : (resp['message'] ?? 'İşlem tamamlandı');

                                if (ok) {
                                  setState(() {
                                    final ix = _all.indexWhere(
                                        (e) => e.orderNumber == o.orderNumber);
                                    if (ix >= 0) {
                                      _all[ix] =
                                          _all[ix].copyWith(deliveryStatus: 1);
                                    }
                                    final vx = _visible.indexWhere(
                                        (e) => e.orderNumber == o.orderNumber);
                                    if (vx >= 0) {
                                      _visible[vx] = _visible[vx]
                                          .copyWith(deliveryStatus: 1);
                                    }
                                  });
                                }

                                if (!mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text(msg)),
                                );
                              } catch (e) {
                                if (!mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Aktarma başarısız ❌'),
                                  ),
                                );
                              }
                            },
                      icon: Icon(
                        Icons.delivery_dining_outlined,
                        color: o.deliveryStatus == 1
                            ? Colors.purple.withOpacity(0.3)
                            : Colors.purple,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Geniş ekran: 3 oval bloğa bölünmüş özel tablo görünümü
  Widget _ordersWideTable({required bool shrinkWrap}) {
    final cs = Theme.of(context).colorScheme;

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: ConstrainedBox(
        constraints: const BoxConstraints(minWidth: 1100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Üst başlık satırı
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: Row(
                children: [
                  Expanded(
                    flex: 4,
                    child: Text(
                      'Sipariş • İşletme • Şehir • İlçe',
                      style: Theme.of(context)
                          .textTheme
                          .labelMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 3,
                    child: Text(
                      'Sipariş Durumu • Tedarikçi Durumu',
                      style: Theme.of(context)
                          .textTheme
                          .labelMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 3,
                    child: Text(
                      'Tarih • Tutar • Kuryelere Ata',
                      style: Theme.of(context)
                          .textTheme
                          .labelMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 4),

            // Satırlar
            for (int i = 0; i < _visible.length; i++) ...[
              _orderSegmentRow(_visible[i], i, cs),
              const SizedBox(height: 6),
            ],
          ],
        ),
      ),
    );
  }

  /// Geniş ekran: 3 oval bloğa bölünmüş özel tablo görünümü

  /// Geniş ekran: 3 oval bloğa bölünmüş özel tablo görünümü

  /// Geniş ekran DataTable (soldan hizalı, zebra + hover)
  Widget _ordersWideTable2({required bool shrinkWrap}) {
    final cs = Theme.of(context).colorScheme;

    final table = DataTable(
      columnSpacing: 28,
      sortColumnIndex: _sortColumnIndex,
      sortAscending: _sortAscending,
      headingRowColor: MaterialStatePropertyAll(cs.primary.withOpacity(.04)),
      columns: [
        DataColumn(
          label: const Align(
            alignment: Alignment.centerLeft,
            child: Text('Sipariş'),
          ),
          onSort: _onSort,
        ),
        DataColumn(
          label: const Align(
            alignment: Alignment.centerLeft,
            child: Text('İşletme'),
          ),
          onSort: _onSort,
        ),
        DataColumn(
          label: const Align(
            alignment: Alignment.centerLeft,
            child: Text('Şehir'),
          ),
          onSort: _onSort,
        ),
        DataColumn(
          label: const Align(
            alignment: Alignment.centerLeft,
            child: Text('İlçe'),
          ),
          onSort: _onSort,
        ),
        DataColumn(
          label: const Align(
            alignment: Alignment.centerLeft,
            child: Text('Sipariş Durumu'),
          ),
          onSort: _onSort,
        ),
        DataColumn(
          label: const Align(
            alignment: Alignment.centerLeft,
            child: Text('Sipariş Durumu'),
          ),
          onSort: _onSort,
        ),
        DataColumn(
          label: const Align(
            alignment: Alignment.centerLeft,
            child: Text('Tedarikçi Durumu'),
          ),
          onSort: _onSort,
        ),
        DataColumn(
          label: const Align(
            alignment: Alignment.centerLeft,
            child: Text('Tarih'),
          ),
          onSort: _onSort,
        ),
        DataColumn(
          numeric: true,
          label: const Align(
            alignment: Alignment.centerLeft,
            child: Text('Tutar'),
          ),
          onSort: _onSort,
        ),
        const DataColumn(
          label: Align(
            alignment: Alignment.centerLeft,
            child: Text('Detay'),
          ),
        ),
        const DataColumn(
          label: Align(
            alignment: Alignment.centerLeft,
            child: Text('Kuryelere Ata'),
          ),
        ),
      ],
      rows: List.generate(_visible.length, (i) {
        final o = _visible[i];

        // 🔍 Debug: UI tarafında hangi deliveryStatus geldiğini görelim
        debugPrint(
            '[OrdersScreen] row order=${o.orderNumber} deliveryStatus=${o.deliveryStatus}');

        final base = i.isEven ? cs.surface : cs.primary.withOpacity(.015);
        return DataRow(
          color: MaterialStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.hovered)) {
              return cs.primary.withOpacity(.06);
            }
            return base;
          }),
          cells: [
            DataCell(
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton(
                  onPressed: () => context
                      .go('/orders/${Uri.encodeComponent(o.orderNumber)}'),
                  child: Text(o.orderNumber),
                ),
              ),
            ),
            DataCell(
              Align(
                alignment: Alignment.centerLeft,
                child: Text(o.buyerName ?? '—'),
              ),
            ),
            DataCell(
              Align(
                alignment: Alignment.centerLeft,
                child: Text(o.buyerCity ?? '—'),
              ),
            ),
            DataCell(
              Align(
                alignment: Alignment.centerLeft,
                child: Text(o.buyerDistrict ?? '—'),
              ),
            ),
            DataCell(
              Align(
                alignment: Alignment.centerLeft,
                child: _statusLegacyWithEdit(o),
              ),
            ),
            DataCell(
              Align(
                alignment: Alignment.centerLeft,
                child: _statusDealerWithEdit(o),
              ),
            ),
            DataCell(
              Align(
                alignment: Alignment.centerLeft,
                child: Text(_statusSupLabel(o.supplier_status)),
              ),
            ),
            DataCell(
              Align(
                alignment: Alignment.centerLeft,
                child: Text(dt(o.createdAt)),
              ),
            ),
            DataCell(
              Align(
                alignment: Alignment.centerLeft,
                child: Text(tl(o.totalAmount)),
              ),
            ),
            DataCell(
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    tooltip: 'Detay',
                    onPressed: () => context
                        .go('/orders/${Uri.encodeComponent(o.orderNumber)}'),
                    icon: const Icon(Icons.open_in_new),
                  ),
                ],
              ),
            ),
            DataCell(
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    tooltip: o.deliveryStatus == 1
                        ? 'Zaten kuryelere aktarılmış'
                        : 'Kuryelere Ata',
                    onPressed: o.deliveryStatus == 1
                        ? null // ✅ PASİF
                        : () async {
                            try {
                              final resp = await context
                                  .read<ApiClient>()
                                  .handoffByOrderNumber(o.orderNumber);

                              final ok = (resp['success'] == true);
                              final msg = ok
                                  ? 'Kuryelere aktarıldı ✅'
                                  : (resp['message'] ?? 'İşlem tamamlandı');

                              if (ok) {
                                setState(() {
                                  final ix = _all.indexWhere(
                                      (e) => e.orderNumber == o.orderNumber);
                                  if (ix >= 0) {
                                    _all[ix] =
                                        _all[ix].copyWith(deliveryStatus: 1);
                                  }
                                  final vx = _visible.indexWhere(
                                      (e) => e.orderNumber == o.orderNumber);
                                  if (vx >= 0) {
                                    _visible[vx] = _visible[vx]
                                        .copyWith(deliveryStatus: 1);
                                  }
                                });
                              }

                              if (!mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(msg)),
                              );
                            } catch (e) {
                              if (!mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Aktarma başarısız ❌'),
                                ),
                              );
                            }
                          },
                    icon: Icon(
                      Icons.delivery_dining_outlined,
                      color: o.deliveryStatus == 1
                          ? Colors.purple.withOpacity(0.3) // 🔴 PASİF MOR
                          : Colors.purple, // 🟣 AKTİF MOR
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      }),
    );

    // Orta ekranlarda hizayı bozmasın, soldan hizalı dursun
    return Scrollbar(
      thumbVisibility: true,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: ConstrainedBox(
          constraints: const BoxConstraints(minWidth: 1100),
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: table,
          ),
        ),
      ),
    );
  }

  Widget _emptyState() => const Padding(
        padding: EdgeInsets.all(8.0),
        child: Center(child: Text('Eşleşen sipariş bulunamadı')),
      );

  Widget _metricCard(
    BuildContext context,
    String label,
    String value,
    IconData icon,
  ) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      decoration: BoxDecoration(
        color: cs.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cs.outlineVariant),
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(icon, size: 36),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(label, style: TextStyle(color: cs.tertiary)),
              Text(value, style: Theme.of(context).textTheme.headlineSmall),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statusLegacyChip(String statusLegacyTr) {
    final s = _toUiStatus(statusLegacyTr);
    Color bg;
    IconData icon;
    switch (s) {
      case 'bekliyor':
        bg = Colors.amber.withOpacity(.15);
        icon = Icons.hourglass_bottom_outlined;
        break;
      case 'onaylandı':
        bg = Colors.blue.withOpacity(.15);
        icon = Icons.confirmation_num_outlined;
        break;
      case 'yolda':
        bg = Colors.indigo.withOpacity(.15);
        icon = Icons.local_shipping_outlined;
        break;
      case 'teslim':
        bg = Colors.green.withOpacity(.15);
        icon = Icons.check_circle_outline;
        break;
      case 'iptal':
        bg = Colors.red.withOpacity(.15);
        icon = Icons.cancel_outlined;
        break;
      default:
        bg = Colors.grey.withOpacity(.15);
        icon = Icons.info_outline;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration:
          BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 6),
          Text(_statusLabel(s)),
        ],
      ),
    );
  }

  Widget _statusDealerChip(String dealerStatusEnum) {
    final icon = _statusIconDealer(dealerStatusEnum);
    final bg = _statusBgDealer(dealerStatusEnum);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration:
          BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 6),
          Text(_statusDealerLabel(dealerStatusEnum)),
        ],
      ),
    );
  }
}

// --------------------- View-model ---------------------
class _Order {
  final String id;
  final String orderNumber;
  final String status; // legacy/TR
  final String dealer_status; // ENUM (EN)
  final String supplier_status; // TR
  final int deliveryStatus; // 0 = aktarılmadı, 1 = kuryelere aktarıldı
  final DateTime createdAt;
  final double totalAmount;
  final String? shippingAddress;
  final String createdByName;

  // Opsiyonel buyer alanları
  final String? buyerName;
  final String? buyerCity;
  final String? buyerDistrict;

  _Order({
    required this.id,
    required this.orderNumber,
    required this.status,
    required this.dealer_status,
    required this.supplier_status,
    required this.createdAt,
    required this.totalAmount,
    required this.shippingAddress,
    required this.createdByName,
    required this.deliveryStatus,
    this.buyerName,
    this.buyerCity,
    this.buyerDistrict,
  });

  _Order copyWith({
    String? id,
    String? orderNumber,
    String? status,
    String? dealer_status,
    String? supplier_status,
    DateTime? createdAt,
    double? totalAmount,
    String? shippingAddress,
    String? createdByName,
    String? buyerName,
    String? buyerCity,
    String? buyerDistrict,
    int? deliveryStatus,
  }) {
    return _Order(
      id: id ?? this.id,
      orderNumber: orderNumber ?? this.orderNumber,
      status: status ?? this.status,
      dealer_status: dealer_status ?? this.dealer_status,
      supplier_status: supplier_status ?? this.supplier_status,
      createdAt: createdAt ?? this.createdAt,
      totalAmount: totalAmount ?? this.totalAmount,
      shippingAddress: shippingAddress ?? this.shippingAddress,
      createdByName: createdByName ?? this.createdByName,
      buyerName: buyerName ?? this.buyerName,
      buyerCity: buyerCity ?? this.buyerCity,
      buyerDistrict: buyerDistrict ?? this.buyerDistrict,
      deliveryStatus: deliveryStatus ?? this.deliveryStatus,
    );
  }
}
