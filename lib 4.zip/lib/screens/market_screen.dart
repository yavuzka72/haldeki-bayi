import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:haldeki_admin_web/config.dart';
import 'package:haldeki_admin_web/models/cart.dart';
import 'package:haldeki_admin_web/models/cart_model.dart';
import 'package:haldeki_admin_web/models/category.dart';
import 'package:haldeki_admin_web/models/product.dart';
import 'package:haldeki_admin_web/models/variant.dart';
import 'package:haldeki_admin_web/services/api_client.dart';
import 'package:haldeki_admin_web/services/order_api.dart';
import 'package:haldeki_admin_web/utils/format.dart';
import 'package:haldeki_admin_web/widgets/QtyInput.dart';

/// Market ekranı
/// - Normal kullanım: const MarketScreen()
/// - OrderDetail içinden: MarketScreen(onAddToOrder: (p, v, qty) { ... })
class MarketScreen extends StatefulWidget {
  /// Opsiyonel: Sipariş detayından ürün eklemek için callback
  final void Function(Product product, ProductVariant variant, double qtyCases)?
      onAddToOrder;

  const MarketScreen({super.key, this.onAddToOrder});

  @override
  State<MarketScreen> createState() => _MarketScreenState();
}

class _MarketScreenState extends State<MarketScreen> {
  final _search = TextEditingController();

  bool _loadingCats = true;
  bool _loadingProds = true;

  List<Category> _cats = const [];
  int? _selectedCat;

  List<Product> _products = const [];
  int _page = 1;
  bool _more = true;
  bool _loadingMore = false;

  static const double _minimumOrder = 0.0;

  /// Ödeme yöntemi: 'cod' = Kapıda Ödeme, 'bank' = Havale/EFT
  String _paymentMethod = 'cod';

  bool get _usedAsPicker => widget.onAddToOrder != null;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _loadAll() async {
    await Future.wait([_loadCategories(), _fetchProducts(reset: true)]);
  }

  Future<void> _loadCategories() async {
    setState(() => _loadingCats = true);
    try {
      final api = context.read<ApiClient>().dio;
      final res = await api.get('categories');
      final data = res.data;
      List list;
      if (data is List) {
        list = data;
      } else if (data is Map && data['data'] is List) {
        list = data['data'] as List;
      } else if (data is Map && data['results'] is List) {
        list = data['results'] as List;
      } else {
        list = [];
      }
      _cats = list
          .whereType<Map>()
          .map((j) => Category.fromJson(Map<String, dynamic>.from(j)))
          .toList();
    } finally {
      if (mounted) setState(() => _loadingCats = false);
    }
  }

  Future<void> _fetchProducts({bool reset = false}) async {
    if (reset) {
      _page = 1;
      _more = true;
      _products = const [];
      setState(() {});
    }
    if (!_more) return;

    if (reset) {
      setState(() => _loadingProds = true);
    } else {
      setState(() => _loadingMore = true);
    }

    try {
      final api = context.read<ApiClient>().dio;

      final params = <String, dynamic>{
        'page': _page,
        if (_search.text.trim().isNotEmpty) 'q': _search.text.trim(),
        if (_selectedCat != null) ...{
          'category_id': _selectedCat,
          'filters[category_id]': _selectedCat,
        },
      };

      final res = await api.get('products', queryParameters: params);

      final parsed = _parseProductsPayload(res.data);
      _products = [..._products, ...parsed];

      int? currentPage, lastPage;
      final root = res.data;
      if (root is Map) {
        if (root['data'] is Map) {
          final d = root['data'] as Map;
          if (d['current_page'] is num) {
            currentPage = (d['current_page'] as num).toInt();
          }
          if (d['last_page'] is num) {
            lastPage = (d['last_page'] as num).toInt();
          }
        }
        if (root['current_page'] is num) {
          currentPage = (root['current_page'] as num).toInt();
        }
        if (root['last_page'] is num) {
          lastPage = (root['last_page'] as num).toInt();
        }
      }

      if (currentPage != null && lastPage != null) {
        _more = currentPage < lastPage;
        if (_more) _page = currentPage + 1;
      } else {
        _more = parsed.isNotEmpty;
        if (_more) _page += 1;
      }
    } on DioException catch (e) {
      //debugprint('products error: ${e.message}');
    } finally {
      if (!mounted) return;
      _loadingProds = false;
      _loadingMore = false;
      setState(() {});
    }
  }

  List<Product> _parseProductsPayload(dynamic payload) {
    List items;
    if (payload is Map &&
        payload['data'] is Map &&
        (payload['data'] as Map)['data'] is List) {
      items = ((payload['data'] as Map)['data'] as List);
    } else if (payload is Map && payload['data'] is List) {
      items = (payload['data'] as List);
    } else if (payload is List) {
      items = payload;
    } else if (payload is Map && payload['results'] is List) {
      items = payload['results'] as List;
    } else {
      items = const [];
    }

    return items.whereType<Map>().map((raw) {
      final j = Map<String, dynamic>.from(raw);

      final id = _asInt(j['id']);
      final name = (j['name'] ?? j['title'] ?? '').toString();
      final catId = _asInt(j['category_id'] ?? j['categoryId']);

      final imagePath = j['image']?.toString() ?? '';
      final imageUrl = AppConfig.imageUrl(imagePath);

      List<ProductVariant> variants = [];
      if (j['variants'] is List) {
        variants = (j['variants'] as List).whereType<Map>().map((vv) {
          final v = Map<String, dynamic>.from(vv);
          return ProductVariant(
            id: _asInt(v['id']),
            name: (v['name'] ?? 'Standart').toString(),
            // backend fiyatınız average_price döndürüyorsa fallback
            price:
                _asDouble(v['price'] ?? v['average_price']) * 1.30, // %30 artır
            unit: (v['unit'] ?? 'adet').toString(),
            sku: v['sku']?.toString(),
            image: v['image']?.toString(),
          );
        }).toList();
      } else {
        // varyant listesi yoksa tekil ürün-varyantı
        variants = [
          ProductVariant(
            id: id,
            name: (j['variant_name'] ?? 'Standart').toString(),
            price: _asDouble(j['price']) * 1.30, // %30 artır
            unit: (j['unit'] ?? 'adet').toString(),
            sku: j['sku']?.toString(),
            image: j['variant_image']?.toString(),
          ),
        ];
      }

      return Product(
        id: id,
        categoryId: catId,
        name: name,
        image: imageUrl,
        variants: variants,
      );
    }).toList();
  }

  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is String) return int.tryParse(v) ?? 0;
    if (v is num) return v.toInt();
    return 0;
  }

  double _asDouble(dynamic v) {
    if (v is double) return v;
    if (v is int) return v.toDouble();
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v.replaceAll(',', '.')) ?? 0.0;
    return 0.0;
  }

  Future<void> _onSearch() async => _fetchProducts(reset: true);

  // Sepet yardımcıları (normal kullanımda)
  void _cartDec(Product p, ProductVariant v) {
    Cart.I.add(p, v, qtyCases: -1);
    setState(() {});
  }

  void _cartInc(Product p, ProductVariant v) {
    Cart.I.add(p, v, qtyCases: 1);
    setState(() {});
  }

  void _cartRemove(Product p, ProductVariant v, double qty) {
    Cart.I.add(p, v, qtyCases: -qty);
    setState(() {});
  }

  void _cartClearAll(Cart cart) {
    for (final line in List.of(cart.items)) {
      final p = line.product as Product;
      final v = line.variant as ProductVariant;
      final qty = (line.qtyCases ?? 1);
      final dQty = qty is num ? qty.toDouble() : 1.0;
      Cart.I.add(p, v, qtyCases: -dQty);
    }
    setState(() {});
  }

  // --- API'ye gönder (Cart içeriğinden)
  Future<void> _sendOrderRestaurant() async {
    final cart = Cart.I;
    if (cart.items.isEmpty) return;

    if (cart.total < _minimumOrder) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Minimum sipariş tutarı ${tl(_minimumOrder)}.')),
      );
      return;
    }

    final api = context.read<ApiClient>();
    // Sabit bilgiler (form yoksa)
    final String name = api.session!.name.toString();
    final String email = api.session!.email.toString();
    const String phone = '+905551112233';
    final String address = '${api.session!.city}/${api.session!.district}';

    // payload
    final payloadItems = cart.items.map<Map<String, dynamic>>((it) {
      final double unit = it.unitPrice;
      final int qty = (it.qtyCases is int)
          ? it.qtyCases as int
          : (it.qtyCases as num).round();
      final double total = it.lineTotal;

      return {
        'product_variant_id': it.variant.id,
        'quantity': qty,
        'unit_price': double.parse(unit.toStringAsFixed(2)),
        'total_price': double.parse(total.toStringAsFixed(2)),
      };
    }).toList();

    // Ödeme metodunu insan okunur hale getir
    final paymentHuman =
        _paymentMethod == 'cod' ? 'Kapıda Ödeme' : 'Havale/EFT';

    try {
      final loading = ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sipariş gönderiliyor…')),
      );

      final data = await OrderApiDio.I.createOrderRestaurant(
        name: name,
        email: email,
        phone: phone,
        address: address,
        items: payloadItems,
        totalAmount: double.parse(cart.total.toStringAsFixed(2)),
        note: 'işletme web / sepet | ödeme: $paymentHuman',
      );

      loading.close();

      final orderNo =
          (data['order_number'] ?? data['number'] ?? data['code'] ?? '')
              .toString();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            orderNo.isEmpty
                ? 'Sipariş oluşturuldu'
                : 'Sipariş oluşturuldu: $orderNo',
          ),
        ),
      );
      _cartClearAll(cart);
    } catch (e) {
      final msg = kIsWeb
          ? 'İstek başarısız. (Muhtemel CORS) — sunucuda Access-Control-Allow-Origin gerekli.\nHata: $e'
          : 'Hata: $e';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        // Picker olarak kullanılıyorsa sağda sepet paneline gerek yok
        final showRightCart = box.maxWidth >= 900 && !_usedAsPicker;

        return Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              // SOL taraf (ürün listesi)
              Expanded(
                child: Column(
                  children: [
                    // Arama
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _search,
                            decoration: const InputDecoration(
                              hintText: 'Ürün veya varyant ara…',
                              prefixIcon: Icon(Icons.search),
                              isDense: true,
                            ),
                            onSubmitted: (_) => _onSearch(),
                          ),
                        ),
                        const SizedBox(width: 8),
                        FilledButton.icon(
                          onPressed: _onSearch,
                          icon: const Icon(Icons.search),
                          label: const Text('Ara'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Kategoriler
                    if (_loadingCats)
                      const CircularProgressIndicator()
                    else
                      _categoriesBar(),
                    const SizedBox(height: 12),

                    // Ürün grid
                    Expanded(
                      child: _loadingProds
                          ? const Center(child: CircularProgressIndicator())
                          : _products.isEmpty
                              ? const Center(child: Text('Ürün bulunamadı'))
                              : _grid(),
                    ),

                    if (_loadingMore) ...[
                      const SizedBox(height: 8),
                      const Center(child: CircularProgressIndicator()),
                      const SizedBox(height: 8),
                    ],
                  ],
                ),
              ),

              if (showRightCart) const SizedBox(width: 16),
              if (showRightCart) SizedBox(width: 340, child: _cartPanel()),
            ],
          ),
        );
      },
    );
  }

  Widget _categoriesBar() {
    return SizedBox(
      height: 40,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _cats.length,
        itemBuilder: (_, i) {
          final c = _cats[i];
          final selected = _selectedCat == c.id;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text(c.name),
              selected: selected,
              onSelected: (_) {
                setState(() => _selectedCat = selected ? null : c.id);
                _fetchProducts(reset: true);
              },
            ),
          );
        },
      ),
    );
  }

  Widget _grid() {
    return LayoutBuilder(builder: (context, box) {
      final w = box.maxWidth;
      final maxExtent = w >= 1400
          ? 360
          : w >= 900
              ? 320
              : 300;
      final ratio = w >= 1400 ? 0.78 : 0.80;

      return GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: maxExtent.toDouble(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: ratio,
        ),
        itemCount: _products.length,
        itemBuilder: (_, i) => _productCard(_products[i]),
      );
    });
  }

  Widget _productCard(Product p) {
    final url =
        p.image.startsWith('http') ? p.image : AppConfig.imageUrl(p.image);

    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          AspectRatio(
            aspectRatio: 4 / 3,
            child: Image.network(
              url,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  const Icon(Icons.image_not_supported_outlined),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
            child: Text(
              p.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
            child: SizedBox(
              height: 36,
              child: FilledButton(
                onPressed: () => _showVariantsSheet(p),
                child: const Text('Paket Seç'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showVariantsSheet(Product p) {
    final cs = Theme.of(context).colorScheme;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) {
        final Map<int, double> qty = {for (final v in p.variants) v.id: 1};

        return StatefulBuilder(
          builder: (context, setS) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            p.name,
                            style: Theme.of(context).textTheme.titleLarge,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.close),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    ...p.variants.map((v) {
                      final q = qty[v.id] ?? 1;
                      final lineTotal = v.price * q;

                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: cs.surfaceVariant.withOpacity(.50),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    v.name,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style:
                                        Theme.of(context).textTheme.titleMedium,
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    '${tl(v.price)} / ${v.unit}',
                                    style:
                                        Theme.of(context).textTheme.bodySmall,
                                  ),
                                ],
                              ),
                            ),
                            QtyInput(
                              value: q,
                              min: 0,
                              onChanged: (val) => setS(() => qty[v.id] = val),
                            ),
                            const SizedBox(width: 8),
                            FilledButton.tonal(
                              onPressed: q <= 0
                                  ? null
                                  : () {
                                      FocusManager.instance.primaryFocus
                                          ?.unfocus();
                                      final currentQ =
                                          (qty[v.id] ?? 1).toDouble();

                                      // Eğer OrderDetail'den picker olarak kullanılıyorsa:
                                      if (widget.onAddToOrder != null) {
                                        widget.onAddToOrder!(p, v, currentQ);
                                      } else {
                                        // Normal kullanım: sepete ekle
                                        Cart.I.add(p, v, qtyCases: currentQ);
                                        if (mounted) {
                                          setState(() {});
                                        }
                                      }

                                      Navigator.pop(context);
                                    },
                              child: Text(
                                'Ekle\n${tl(lineTotal)}',
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _cartPanel() {
    return Consumer<Cart>(
      builder: (context, cart, _) {
        final lines = cart.items;
        final total = cart.total;
        final belowMin = total < _minimumOrder;

        return Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.shopping_cart),
                title: const Text('Sepet'),
                trailing: lines.isNotEmpty
                    ? TextButton(
                        onPressed: () => _cartClearAll(cart),
                        child: const Text('Temizle'),
                      )
                    : null,
              ),
              if (lines.isEmpty)
                const Expanded(child: Center(child: Text('Sepet boş')))
              else
                Expanded(
                  child: ListView.builder(
                    itemCount: lines.length,
                    itemBuilder: (_, i) {
                      final line = lines[i];
                      final p = line.product as Product;
                      final v = line.variant as ProductVariant;
                      final qtyAny = (line.qtyCases ?? 1);
                      final qtyInt =
                          qtyAny is int ? qtyAny : (qtyAny as num).round();

                      return ListTile(
                        title: Text('${p.name} - ${v.name}'),
                        subtitle: Text('${tl(v.price)} x $qtyInt'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.remove),
                              onPressed: () => _cartDec(p, v),
                            ),
                            Text('$qtyInt'),
                            IconButton(
                              icon: const Icon(Icons.add),
                              onPressed: () => _cartInc(p, v),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close),
                              onPressed: () => _cartRemove(
                                p,
                                v,
                                (qtyAny is num) ? qtyAny.toDouble() : 1.0,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),

              // ------ ÖDEME SEÇİMİ (Sepet doluyken göster) ------
              if (lines.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Ödeme Şekli',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      Card(
                        child: Column(
                          children: [
                            RadioListTile<String>(
                              value: 'cod',
                              groupValue: _paymentMethod,
                              onChanged: (v) =>
                                  setState(() => _paymentMethod = v!),
                              title: const Text('Kapıda Ödeme'),
                              subtitle:
                                  const Text('Teslimatta nakit / POS (varsa)'),
                              dense: true,
                              visualDensity: VisualDensity.compact,
                            ),
                            const Divider(height: 0),
                            RadioListTile<String>(
                              value: 'bank',
                              groupValue: _paymentMethod,
                              onChanged: (v) =>
                                  setState(() => _paymentMethod = v!),
                              title: const Text('Havale / EFT'),
                              subtitle:
                                  const Text('Onay sonrası IBAN ile ödeme'),
                              dense: true,
                              visualDensity: VisualDensity.compact,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

              if (lines.isNotEmpty) ...[
                if (belowMin)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.amber.withOpacity(.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'Minimum sipariş tutarı: ${tl(_minimumOrder)}. '
                        'Devam etmek için ${tl(_minimumOrder - total)} daha ekleyin.',
                      ),
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                  child: Row(
                    children: [
                      const Expanded(child: Text('Toplam')),
                      Text(tl(total)),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: (!belowMin && lines.isNotEmpty)
                          ? () => _sendOrderRestaurant()
                          : null,
                      icon: const Icon(Icons.check),
                      label: const Text('Sepeti Kaydet (API)'),
                    ),
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}
