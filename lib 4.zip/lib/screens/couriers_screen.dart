// lib/screens/couriers_screen.dart
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import 'form/create_account_form.dart';

/// =====================
///  UI TOKENS (görseldeki stil)
/// =====================
class _UI {
  // Backgrounds
  static const Color bg = Color(0xFFF6F7FB); // ekran arkası
  static const Color card = Colors.white; // kart
  static const Color border = Color(0xFFE5E7EB);

  // Text
  static const Color text = Color(0xFF0F172A);
  static const Color muted = Color(0xFF64748B);

  // Brand (koyu yeşil)
  static const Color primary = Color(0xFF0D4631);
  static const Color primarySoft = Color(0xFFE7EFEA); // seçili satır bg
  static const Color primarySoft2 = Color(0xFFD9E6DF); // seçili pill bg

  // Table header
  static const Color headerBg = Color(0xFFF1F5F2);

  // Status
  static const Color ok = Color(0xFF0F766E);
  static const Color danger = Color(0xFFB91C1C);
}

/// =====================
///  MODEL
/// =====================
class Courier {
  final int id;
  final String name;
  final String phone;
  final String createdAt;
  final bool isActive;

  // opsiyonel/ek alanlar
  final String? avatarUrl;
  final double balance; // ₺
  final int jobCount;
  final String approvalStatus;

  // ekstra (detail panelde göstermek için)
  final String? plate;
  final String? iban;
  final String? accountHolder;

  Courier({
    required this.id,
    required this.name,
    required this.phone,
    required this.createdAt,
    required this.isActive,
    this.avatarUrl,
    this.balance = 0.0,
    this.jobCount = 0,
    this.approvalStatus = '—',
    this.plate,
    this.iban,
    this.accountHolder,
  });

  /// Backend çok farklı alan isimleri döndürebilir; hepsini tolere et.
  factory Courier.fromAnyJson(Map<String, dynamic> j) {
    T? pick<T>(List<String> keys) {
      for (final k in keys) {
        final v = j[k];
        if (v == null) continue;

        if (T == String) return (v is String ? v : '$v') as T;

        if (T == int) {
          if (v is int) return v as T;
          if (v is num) return v.toInt() as T;
          final p = int.tryParse('$v');
          if (p != null) return p as T;
        }

        if (T == double) {
          if (v is num) return v.toDouble() as T;
          final p = double.tryParse('$v'.replaceAll(',', '.'));
          if (p != null) return p as T;
        }

        if (T == bool) {
          if (v is bool) return v as T;
          if (v is num) return (v != 0) as T;
          final s = '$v'.toLowerCase();
          if (s == '1' || s == 'true' || s == 'aktif' || s == 'active')
            return true as T;
          if (s == '0' || s == 'false' || s == 'pasif' || s == 'inactive')
            return false as T;
        }
      }
      return null;
    }

    String _str(List<String> keys, {String d = ''}) => pick<String>(keys) ?? d;
    int _int(List<String> keys, {int d = 0}) => pick<int>(keys) ?? d;
    double _dbl(List<String> keys, {double d = 0}) => pick<double>(keys) ?? d;
    bool _bool(List<String> keys, {bool d = false}) => pick<bool>(keys) ?? d;

    final id = _int(['id', 'user_id', 'courier_id']);
    final name = _str(['name', 'ad_soyad', 'full_name']);
    final phone = _str(['phone', 'telefon', 'contact_number', 'mobile']);
    final createdAt = _str(['created_at', 'kayit_tarihi', 'createdAt'], d: '');
    final isActive = _bool(['is_active', 'active', 'durum', 'status']);

    final avatarUrl =
        _str(['avatar', 'avatar_url', 'photo', 'image_url'], d: '');
    final balance = _dbl(['balance', 'wallet_balance', 'bakiye']);
    final jobCount = _int(['jobs_count', 'job_count', 'is_sayisi']);
    final approvalStatus = _str(
        ['approval_status', 'approval', 'onay', 'can_take_orders'],
        d: '—');

    final plate = _str(['plate', 'plaka'], d: '');
    final iban = _str(['iban', 'iban_no'], d: '');
    final accountHolder =
        _str(['account_holder', 'hesap_sahibi', 'iban_name'], d: '');

    return Courier(
      id: id,
      name: name.isEmpty ? '—' : name,
      phone: phone.isEmpty ? '—' : phone,
      createdAt: createdAt.isEmpty ? '—' : createdAt,
      isActive: isActive,
      avatarUrl: avatarUrl.isEmpty ? null : avatarUrl,
      balance: balance,
      jobCount: jobCount,
      approvalStatus: approvalStatus,
      plate: plate.isEmpty ? null : plate,
      iban: iban.isEmpty ? null : iban,
      accountHolder: accountHolder.isEmpty ? null : accountHolder,
    );
  }
}

/// =====================
///  SCREEN
/// =====================
class CouriersScreen extends StatefulWidget {
  const CouriersScreen({super.key});

  @override
  State<CouriersScreen> createState() => _CouriersScreenState();
}

class _CouriersScreenState extends State<CouriersScreen> {
  final TextEditingController _searchC = TextEditingController();
  String _statusFilter = 'Tümü'; // Tümü / Aktif / Pasif

  List<Courier> _all = [];
  List<Courier> _filtered = [];
  Courier? _selected;

  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadFromBackend();
  }

  @override
  void dispose() {
    _searchC.dispose();
    super.dispose();
  }

  Future<void> _loadFromBackend() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final api = context.read<ApiClient>();
      final res = await api.getCouriers(page: 1, perPage: 200);

      final items = _extractArray(res);
      final parsed = items
          .whereType<Map>()
          .map((e) => Courier.fromAnyJson(Map<String, dynamic>.from(e)))
          .toList();

      setState(() {
        _all = parsed;
        _filtered = List.of(_all);
        _selected = _filtered.isNotEmpty ? _filtered.first : null;
      });
    } catch (e) {
      setState(() => _error = 'Kuryeler yüklenemedi: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<dynamic> _extractArray(dynamic payload) {
    if (payload is List) return payload;
    if (payload is Map) {
      final data = payload['data'];
      if (data is List) return data;
      if (data is Map && data['data'] is List) return data['data'] as List;
      if (payload['results'] is List) return payload['results'] as List;
    }
    return const [];
  }

  String _trLower(String s) =>
      s.replaceAll('I', 'ı').replaceAll('İ', 'i').toLowerCase();

  int get _totalCount => _all.length;
  int get _activeCount => _all.where((e) => e.isActive).length;
  int get _passiveCount => _all.where((e) => !e.isActive).length;

  void _applyFilter() {
    final q = _trLower(_searchC.text.trim());

    setState(() {
      Iterable<Courier> list = _all;

      if (_statusFilter != 'Tümü') {
        final wantActive = _statusFilter == 'Aktif';
        list = list.where((c) => c.isActive == wantActive);
      }

      if (q.isNotEmpty) {
        list = list.where((c) =>
            _trLower(c.name).contains(q) ||
            _trLower(c.phone).contains(q) ||
            c.id.toString().contains(q));
      }

      _filtered = list.toList();

      // ✅ seçim korunur, yoksa ilk kayıt
      if (_filtered.isEmpty) {
        _selected = null;
      } else if (_selected == null ||
          !_filtered.any((x) => x.id == _selected!.id)) {
        _selected = _filtered.first;
      }
    });
  }

  void _clearAllFilters() {
    setState(() {
      _statusFilter = 'Tümü';
      _searchC.clear();
      _filtered = List.of(_all);
      if (_filtered.isNotEmpty) _selected = _filtered.first;
    });
  }

  Future<void> _openCreateCourierSheet() async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      builder: (_) => FractionallySizedBox(
        heightFactor: 0.98,
        widthFactor: 0.98,
        child: Material(
          color: _UI.card,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
          child: Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1600),
                child: const CreateAccountForm(
                  userType: 'delivery_man',
                  title: 'Yeni Kurye',
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await _loadFromBackend();
  }

  void _openCourier(Courier c) {
    final w = MediaQuery.of(context).size.width;

    // dar ekranda route
    if (w < 980) {
      context.go('/couriers/${c.id}');
      return;
    }

    // wide: sağ panel
    setState(() => _selected = c);
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final isMasterDetail = w >= 980;

    if (_loading) return const Center(child: CircularProgressIndicator());

    if (_error != null) {
      return Scaffold(
        backgroundColor: _UI.bg,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.cloud_off_outlined, size: 48),
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: _UI.text)),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: _loadFromBackend,
                icon: const Icon(Icons.refresh),
                label: const Text('Tekrar dene'),
              ),
            ],
          ),
        ),
      );
    }

    return Theme(
      data: Theme.of(context).copyWith(
        scaffoldBackgroundColor: _UI.bg,
        dividerColor: _UI.border,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: _UI.card,
          isDense: true,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          hintStyle:
              const TextStyle(color: _UI.muted, fontWeight: FontWeight.w600),
          prefixIconColor: _UI.muted,
          suffixIconColor: _UI.muted,
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: _UI.border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide:
                BorderSide(color: _UI.primary.withOpacity(.35), width: 1.4),
          ),
        ),
      ),
      child: Scaffold(
        backgroundColor: _UI.bg,
        body: Padding(
          padding: const EdgeInsets.only(top: 16, right: 16, bottom: 16),
          child: Column(
            children: [
              _topHeader(),
              const SizedBox(height: 10),
              _countsRow(),
              const SizedBox(height: 12),
              Expanded(
                child: Row(
                  children: [
                    Expanded(
                      flex: isMasterDetail ? 7 : 12,
                      child: Column(
                        children: [
                          _filterCard(),
                          const SizedBox(height: 12),
                          Expanded(child: _tableCard()),
                        ],
                      ),
                    ),
                    if (isMasterDetail) ...[
                      const SizedBox(width: 12),
                      Expanded(flex: 5, child: _detailRight()),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// =====================
  ///  TOP HEADER
  /// =====================
  Widget _topHeader() {
    return Row(
      children: [
        const Text(
          'Kuryeler',
          style: TextStyle(
              fontSize: 28, fontWeight: FontWeight.w900, color: _UI.text),
        ),
        const Spacer(),
        _softButton(
          icon: Icons.refresh,
          text: 'Yenile',
          onTap: _loadFromBackend,
        ),
        const SizedBox(width: 10),
        _primaryButton(
          icon: Icons.add_business, // aynı hissiyat
          text: 'Yeni Kurye',
          onTap: _openCreateCourierSheet,
        ),
      ],
    );
  }

  /// =====================
  ///  COUNTS ROW (Toplam/Aktif/Pasif)
  /// =====================
  Widget _countsRow() {
    return Row(
      children: [
        _statPill('Toplam: $_totalCount', selected: true),
        const SizedBox(width: 8),
        _statPill('Aktif: $_activeCount', selected: false),
        const SizedBox(width: 8),
        _statPill('Pasif: $_passiveCount', selected: false),
      ],
    );
  }

  Widget _statPill(String text, {required bool selected}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: selected ? _UI.primarySoft2 : _UI.card,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: _UI.border),
      ),
      child: Text(text,
          style: const TextStyle(fontWeight: FontWeight.w800, color: _UI.text)),
    );
  }

  /// =====================
  ///  FILTER CARD
  /// =====================
  Widget _filterCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _UI.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _UI.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // title row + temizle
          Row(
            children: [
              const Text('Filtreler',
                  style:
                      TextStyle(fontWeight: FontWeight.w900, color: _UI.text)),
              const Spacer(),
              InkWell(
                borderRadius: BorderRadius.circular(999),
                onTap: _clearAllFilters,
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  child: Row(
                    children: [
                      Icon(Icons.close, size: 18, color: _UI.muted),
                      SizedBox(width: 6),
                      Text('Temizle',
                          style: TextStyle(
                              fontWeight: FontWeight.w800, color: _UI.muted)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // pills row
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _pillOption('Tümü', selected: _statusFilter == 'Tümü', onTap: () {
                _statusFilter = 'Tümü';
                _applyFilter();
              }),
              _pillOption('Aktif', selected: _statusFilter == 'Aktif',
                  onTap: () {
                _statusFilter = 'Aktif';
                _applyFilter();
              }),
              _pillOption('Pasif', selected: _statusFilter == 'Pasif',
                  onTap: () {
                _statusFilter = 'Pasif';
                _applyFilter();
              }),
            ],
          ),

          const SizedBox(height: 12),

          TextField(
            controller: _searchC,
            decoration: InputDecoration(
              hintText: 'Kurye no, ad, telefon ara…',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: (_searchC.text.isEmpty)
                  ? null
                  : IconButton(
                      onPressed: () {
                        _searchC.clear();
                        _applyFilter();
                      },
                      icon: const Icon(Icons.close),
                      tooltip: 'Temizle',
                    ),
            ),
            onChanged: (_) => setState(() {}), // suffix icon güncellensin
            onSubmitted: (_) => _applyFilter(),
          ),
        ],
      ),
    );
  }

  Widget _pillOption(String text,
      {required bool selected, required VoidCallback onTap}) {
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? _UI.primarySoft2 : _UI.card,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
              color: selected ? _UI.primary.withOpacity(.22) : _UI.border),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontWeight: FontWeight.w900,
            color: selected ? _UI.primary : _UI.text,
          ),
        ),
      ),
    );
  }

  /// =====================
  ///  TABLE CARD (master)
  /// =====================
  Widget _tableCard() {
    final screenW = MediaQuery.of(context).size.width;

    return Container(
      decoration: BoxDecoration(
        color: _UI.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _UI.border),
      ),
      child: _filtered.isEmpty
          ? const Center(
              child: Text('Kayıt bulunamadı',
                  style:
                      TextStyle(color: _UI.muted, fontWeight: FontWeight.w800)),
            )
          : Theme(
              data: Theme.of(context).copyWith(
                dataTableTheme: DataTableThemeData(
                  headingRowColor: MaterialStateProperty.all(_UI.headerBg),
                  dataRowMinHeight: 56,
                  dataRowMaxHeight: 56, // ✅ EKLE (veya 60/64)
                  headingRowHeight:
                      56, // (opsiyonel ama görselde güzel duruyor)
                  dividerThickness: 0.7,
                  headingTextStyle: const TextStyle(
                      fontWeight: FontWeight.w900, color: _UI.text),
                  dataTextStyle: const TextStyle(
                      color: _UI.text, fontWeight: FontWeight.w700),
                ),
              ),
              child: Scrollbar(
                thumbVisibility: true,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minWidth: screenW),
                    child: SingleChildScrollView(
                      child: DataTable(
                        columns: const [
                          DataColumn(label: Text('No')),
                          DataColumn(label: Text('')),
                          DataColumn(label: Text('Kurye')),
                          DataColumn(label: Text('Telefon')),
                          DataColumn(label: Text('Durum')),
                          DataColumn(label: Text('Kayıt')),
                          DataColumn(label: Text('')),
                        ],
                        rows: List.generate(_filtered.length, (i) {
                          final c = _filtered[i];
                          return _row(c, i);
                        }),
                      ),
                    ),
                  ),
                ),
              ),
            ),
    );
  }

  DataRow _row(Courier c, int index) {
    final isSelected = _selected?.id == c.id;
    final zebra = index.isEven ? _UI.card : const Color(0xFFFBFCFD);

    return DataRow(
      selected: isSelected,
      color: MaterialStateProperty.resolveWith((states) {
        if (isSelected)
          return _UI.primarySoft; // ✅ seçili satır (görseldeki gibi)
        if (states.contains(WidgetState.hovered))
          return _UI.primary.withOpacity(.06);
        return zebra;
      }),
      onSelectChanged: (_) => _openCourier(c),
      cells: [
        DataCell(
          InkWell(
            onTap: () => _openCourier(c),
            child: Text(
              c.id.toString(),
              style: TextStyle(
                fontFeatures: const [FontFeature.tabularFigures()],
                color: _UI.primary,
                decoration: TextDecoration.underline,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ),
        DataCell(_avatarSmall(c)),
        DataCell(
            Text(c.name, style: const TextStyle(fontWeight: FontWeight.w900))),
        DataCell(Text(c.phone, style: const TextStyle(color: _UI.text))),
        DataCell(_activeChip(c.isActive)),
        DataCell(
          Text(
            c.createdAt,
            style: const TextStyle(
                fontFeatures: [FontFeature.tabularFigures()], color: _UI.text),
          ),
        ),
        DataCell(
          IconButton(
            tooltip: 'Aç',
            onPressed: () => _openCourier(c),
            icon: const Icon(Icons.open_in_new, color: _UI.muted),
          ),
        ),
      ],
    );
  }

  /// =====================
  ///  RIGHT DETAIL (master-detail)
  /// =====================
  Widget _detailRight() {
    final c = _selected;

    if (c == null) {
      return Container(
        decoration: BoxDecoration(
          color: _UI.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _UI.border),
        ),
        child: const Center(
          child: Text(
            'Detay için soldan bir kurye seç.',
            style: TextStyle(color: _UI.muted, fontWeight: FontWeight.w800),
          ),
        ),
      );
    }

    return Column(
      children: [
        _profileCard(c),
        const SizedBox(height: 12),
        _balanceCard(c),
        const SizedBox(height: 12),
        _infoRow(Icons.motorcycle, 'Plaka', c.plate ?? '—'),
        const SizedBox(height: 10),
        _infoRow(Icons.account_balance, 'IBAN', c.iban ?? '—'),
        const SizedBox(height: 10),
        _infoRow(Icons.person, 'Hesap Sahibi', c.accountHolder ?? '—'),
        const Spacer(),
      ],
    );
  }

  Widget _profileCard(Courier c) {
    return Container(
      height: 210,
      decoration: BoxDecoration(
        color: _UI.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _UI.border),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFF2F5F4), Color(0xFFE9EFEC)],
        ),
      ),
      child: Stack(
        children: [
          Positioned(top: 14, left: 14, child: _activeChip(c.isActive)),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  radius: 34,
                  backgroundColor: const Color(0xFFD7E2DC),
                  backgroundImage:
                      (c.avatarUrl != null && c.avatarUrl!.isNotEmpty)
                          ? NetworkImage(c.avatarUrl!)
                          : null,
                  child: (c.avatarUrl != null && c.avatarUrl!.isNotEmpty)
                      ? null
                      : Text(
                          _initials(c.name),
                          style: const TextStyle(
                              fontWeight: FontWeight.w900, color: _UI.primary),
                        ),
                ),
                const SizedBox(height: 14),
                Text(c.name,
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: _UI.text)),
                const SizedBox(height: 6),
                Text(
                  c.phone,
                  style: const TextStyle(
                    decoration: TextDecoration.underline,
                    fontWeight: FontWeight.w800,
                    color: _UI.text,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _balanceCard(Courier c) {
    return Container(
      decoration: BoxDecoration(
        color: _UI.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _UI.border),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Text(
            _formatTL(c.balance),
            style: const TextStyle(
                fontSize: 32, fontWeight: FontWeight.w900, color: _UI.text),
          ),
          const SizedBox(height: 6),
          const Text('Bakiye',
              style: TextStyle(color: _UI.muted, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _outlinePillButton(
                  icon: Icons.add,
                  text: 'Yükle',
                  onTap: () {
                    // TODO: bakiye yükleme modalı
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _outlinePillButton(
                  icon: Icons.remove,
                  text: 'Tahsil',
                  onTap: () {
                    // TODO: tahsil modalı
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => context.go('/couriers/${c.id}'),
            icon: const Icon(Icons.open_in_new, size: 18),
            label: const Text('Detaya Git'),
            style: OutlinedButton.styleFrom(
              foregroundColor: _UI.primary,
              side: const BorderSide(color: _UI.border),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(999)),
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Container(
      decoration: BoxDecoration(
        color: _UI.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _UI.border),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      child: Row(
        children: [
          Icon(icon, color: _UI.muted),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                  color: _UI.muted, fontWeight: FontWeight.w900),
            ),
          ),
          Text(value,
              style: const TextStyle(
                  fontWeight: FontWeight.w900, color: _UI.text)),
        ],
      ),
    );
  }

  /// =====================
  ///  SMALL UI PARTS
  /// =====================
  Widget _avatarSmall(Courier c) {
    final hasImg = c.avatarUrl != null && c.avatarUrl!.isNotEmpty;
    return CircleAvatar(
      radius: 16,
      backgroundColor: const Color(0xFFD7E2DC),
      backgroundImage: hasImg ? NetworkImage(c.avatarUrl!) : null,
      child: hasImg
          ? null
          : Text(
              _initials(c.name),
              style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  color: _UI.primary),
            ),
    );
  }

  Widget _activeChip(bool active) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: _UI.primarySoft2,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: _UI.primary.withOpacity(.22)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.check_circle, size: 18, color: _UI.ok),
          const SizedBox(width: 6),
          Text(
            active ? 'Aktif' : 'Pasif',
            style: const TextStyle(
                fontWeight: FontWeight.w900, color: _UI.primary),
          ),
        ],
      ),
    );
  }

  Widget _softButton(
      {required IconData icon,
      required String text,
      required VoidCallback onTap}) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18),
      label: Text(text),
      style: OutlinedButton.styleFrom(
        foregroundColor: _UI.text,
        side: const BorderSide(color: _UI.border),
        backgroundColor: _UI.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        textStyle: const TextStyle(fontWeight: FontWeight.w900),
      ),
    );
  }

  Widget _primaryButton(
      {required IconData icon,
      required String text,
      required VoidCallback onTap}) {
    return FilledButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18),
      label: Text(text),
      style: FilledButton.styleFrom(
        backgroundColor: _UI.primary,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        textStyle: const TextStyle(fontWeight: FontWeight.w900),
      ),
    );
  }

  Widget _outlinePillButton(
      {required IconData icon,
      required String text,
      required VoidCallback onTap}) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18),
      label: Text(text),
      style: OutlinedButton.styleFrom(
        foregroundColor: _UI.primary,
        side: const BorderSide(color: _UI.border),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
        padding: const EdgeInsets.symmetric(vertical: 12),
        textStyle: const TextStyle(fontWeight: FontWeight.w900),
      ),
    );
  }

  String _formatTL(double v) {
    final sign = v < 0 ? '-' : '';
    final abs = v.abs();
    return '$sign${abs.toStringAsFixed(2)} ₺';
  }

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return '?';
    if (parts.length == 1) {
      final s = parts.first;
      return (s.characters.take(2).toString()).toUpperCase();
    }
    return (parts.first.characters.first + parts.last.characters.first)
        .toUpperCase();
  }
}
