import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:haldeki_admin_web/utils/message_dialog.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import '../../../models/models.dart'; // City, UserMinimal, Wallet
import '../../../models/district.dart'
    hide District; // District: {id, name, countryId?}
import '../../../services/api_client.dart'; // ApiClient

class CreateAccountForm extends StatefulWidget {
  /// userType:
  ///  - 'client'  => İşletme
  ///  - 'courier' => Kurye
  ///  - 'user'    => Müşteri
  final String userType;
  final String title;

  const CreateAccountForm({
    super.key,
    required this.userType,
    required this.title,
  });

  @override
  State<CreateAccountForm> createState() => _CreateAccountFormState();
}

class _CreateAccountFormState extends State<CreateAccountForm> {
  final _formKey = GlobalKey<FormState>();

  // --- temel alanlar
  final nameC = TextEditingController();
  final lastNameC = TextEditingController(); // kurye & müşteri için
  final emailC = TextEditingController();
  final passC = TextEditingController();
  final userC = TextEditingController();
  final phoneC = TextEditingController();
  final addrC = TextEditingController();
  final latC = TextEditingController();
  final lngC = TextEditingController();

  // --- kurye ek alanlar
  final plateC = TextEditingController(); // Plaka
  final ibanC = TextEditingController();
  final bankOwnerC = TextEditingController(); // Banka hesap sahibi
  final commissionRateC = TextEditingController(text: '10.00');
  String commissionType = 'percent'; // percent | fixed
  bool canTakeOrders = true;
  bool hasHadi = false;
  final hiddenNoteC = TextEditingController();

  // --- şehir/ilçe
  List<City> cities = []; // country-list -> şehirler
  List<District> districts = []; // city-list -> ilçeler

  int? selectedCityId;
  int? selectedDistrictId;

  // --- belgeler
  File? residencePdf; // İkametgâh (.pdf)
  File? driverFrontImage; // Ehliyet ön (resim/pdf)
  File? goodConductPdf; // İyi hâl (.pdf)
  List<File> extraDocuments = []; // opsiyonel ek belgeler

  // --- sonuç & cüzdan
  UserMinimal? createdUser;
  Wallet? wallet;
  final topupAmountC = TextEditingController();
  final topupNoteC = TextEditingController();

  bool loading = false;
  bool _obscurePass = true;
  Timer? _geoDebounce;

  bool get _isCourier => widget.userType == 'delivery_man';
  bool get _isClient => widget.userType == 'client';
  bool get _isUser => widget.userType == 'user';

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  // İlk yükleme: şehirleri çek → ilk satırı seç → ilçeleri getir
  Future<void> _bootstrap() async {
    try {
      final api = context.read<ApiClient>();
      final cityList = await api.fetchCitiesFromCountries(perPage: -1);

      if (!mounted) return;
      if (cityList.isEmpty) {
        _snack('Şehir listesi boş döndü');
        return;
      }

      setState(() {
        cities = cityList;
        selectedCityId = cityList.first.id; // default ilk satır
      });

      await _loadDistrictsByCity();
    } catch (_) {
      if (!mounted) return;
      _snack('Başlangıç verileri alınamadı');
    }
  }

  @override
  void dispose() {
    nameC.dispose();
    lastNameC.dispose();
    emailC.dispose();
    passC.dispose();
    userC.dispose();
    phoneC.dispose();
    addrC.dispose();
    latC.dispose();
    lngC.dispose();
    plateC.dispose();
    ibanC.dispose();
    bankOwnerC.dispose();
    commissionRateC.dispose();
    hiddenNoteC.dispose();
    topupAmountC.dispose();
    topupNoteC.dispose();
    _geoDebounce?.cancel();
    super.dispose();
  }

  /// Geoapify Geocoding – metin adresini lat/lon’a çevirir
  Future<({double lat, double lon})?> geoapifyGeocode(String address) async {
    const apiKey = '6ca1f774874b4d3099be549f503310a4';

    final url = Uri.parse(
      'https://api.geoapify.com/v1/geocode/search'
      '?text=${Uri.encodeComponent(address)}'
      '&filter=countrycode:tr'
      '&limit=1'
      '&lang=tr'
      '&apiKey=$apiKey',
    );

    final r = await http.get(url);
    if (r.statusCode != 200) {
      print('Geoapify hata: ${r.statusCode}');
      return null;
    }

    final data = jsonDecode(r.body);
    if (data is! Map || data['features'] is! List || data['features'].isEmpty) {
      print('Geoapify: sonuç bulunamadı');
      return null;
    }

    final feature = data['features'][0];
    final geometry = feature['geometry']?['coordinates'];
    if (geometry == null || geometry.length < 2) return null;

    // Geoapify: [lon, lat]
    final lon = (geometry[0] as num).toDouble();
    final lat = (geometry[1] as num).toDouble();
    return (lat: lat, lon: lon);
  }

  Future<void> _loadDistrictsByCity() async {
    final cid = selectedCityId;
    if (cid == null) {
      setState(() {
        districts = [];
        selectedDistrictId = null;
      });
      return;
    }

    try {
      final api = context.read<ApiClient>();
      final L = await api.fetchDistrictsByCountry(countryId: cid, perPage: -1);

      if (!mounted) return;
      setState(() {
        districts = L;
        // İstersen "Konak" öncelik; yoksa ilk ilçe
        final konak =
            L.where((d) => d.name.toLowerCase().startsWith('konak')).toList();
        selectedDistrictId = konak.isNotEmpty
            ? konak.first.id
            : (L.isNotEmpty ? L.first.id : null);
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        districts = [];
        selectedDistrictId = null;
      });
      _snack('İlçeler alınamadı');
    }
  }

  Future<void> _pickGenericDocuments() async {
    final res = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (res == null) return;
    final files = <File>[];
    for (final f in res.files) {
      if (f.path != null) files.add(File(f.path!));
    }
    setState(() => extraDocuments = files);
  }

  Future<void> _pickOne({
    required List<String> extensions,
    required void Function(File) onPick,
  }) async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: extensions,
      allowMultiple: false,
    );
    if (res == null || res.files.isEmpty || res.files.first.path == null) {
      return;
    }
    onPick(File(res.files.first.path!));
  }

  // Adres → Lat/Lng otomatik
  void _onAddressChanged(String _) {
    _geoDebounce?.cancel();
    _geoDebounce = Timer(const Duration(milliseconds: 600), _geocodeAddress);
  }

  Future<void> _geocodeAddress() async {
    final addr = addrC.text.trim();
    if (addr.length < 6) return;

    final cityName = cities
        .firstWhere((c) => c.id == selectedCityId,
            orElse: () => City(id: 0, name: ''))
        .name;

    final districtName = districts
        .firstWhere((d) => d.id == selectedDistrictId,
            orElse: () => District(id: 0, name: '', countryId: 0))
        .name;

    final query = '$addr, $districtName, $cityName, Türkiye';

    final result = await geoapifyGeocode(query);
    if (result != null) {
      setState(() {
        latC.text = result.lat.toStringAsFixed(6);
        lngC.text = result.lon.toStringAsFixed(6);
      });
    } else {
      _snack('Adres bulunamadı');
    }
  }

  double? _toDoubleOrNull(String s) {
    if (s.isEmpty) return null;
    return double.tryParse(s.replaceAll(',', '.'));
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    if (_isCourier) {
      if (ibanC.text.trim().isEmpty) {
        return _snack('IBAN numarası zorunludur');
      }
      if (bankOwnerC.text.trim().isEmpty) {
        return _snack('Hesap sahibi zorunludur');
      }
      if (commissionRateC.text.trim().isEmpty) {
        return _snack('Komisyon oranı zorunludur');
      }
    }

    setState(() => loading = true);
    try {
      final api = context.read<ApiClient>();

      // Kurye & müşteri için: Ad + Soyad birleştir
      final fullName = (_isCourier || _isUser)
          ? [nameC.text.trim(), lastNameC.text.trim()]
              .where((e) => e.isNotEmpty)
              .join(' ')
          : nameC.text.trim();

      // İlçe ve şehir isimleri
      final districtName = districts
          .firstWhere((d) => d.id == selectedDistrictId,
              orElse: () => District(id: 0, name: '', countryId: 0))
          .name;

      final cityName = cities
          .firstWhere(
            (c) => c.id == selectedCityId,
            orElse: () => City(id: 0, name: ''),
          )
          .name;

      // Lat/Lng numeric
      final locLat = _toDoubleOrNull(latC.text.trim());
      final locLng = _toDoubleOrNull(lngC.text.trim());

      // API'ye gidecek gerçek user_type
      final String userTypeForApi =
          _isCourier ? 'delivery_man' : (_isUser ? 'user' : 'client');

      // Kullanıcı oluştur
      final u = await api.createUser(
        // tip bilgisi
        userType: userTypeForApi, // 'client' | 'user' | 'delivery_man'
        isCourier: _isCourier,

        // temel
        name: fullName,
        email: emailC.text.trim().isEmpty ? null : emailC.text.trim(),
        password: passC.text,
        username: userC.text.trim().isEmpty ? null : userC.text.trim(),
        contactNumber: phoneC.text.trim().isEmpty ? null : phoneC.text.trim(),

        // adres/konum
        countryId: selectedCityId,
        cityId: selectedDistrictId,
        address: addrC.text.trim().isEmpty ? null : addrC.text.trim(),
        latitude: locLat == null
            ? (latC.text.trim().isEmpty ? null : latC.text.trim())
            : null,
        longitude: locLng == null
            ? (lngC.text.trim().isEmpty ? null : lngC.text.trim())
            : null,
        locationLat: locLat,
        locationLng: locLng,
        district: districtName.isEmpty ? null : districtName,
        cityName: cityName.isEmpty ? null : cityName,

        // kurye alanları
        vehiclePlate: _isCourier && plateC.text.trim().isNotEmpty
            ? plateC.text.trim()
            : null,
        iban: _isCourier ? ibanC.text.trim() : null,
        bankAccountOwner: _isCourier ? bankOwnerC.text.trim() : null,
        commissionRate: _isCourier ? commissionRateC.text.trim() : null,
        commissionType: commissionType, // sadece courier için anlamlı
        canTakeOrders: _isCourier ? canTakeOrders : null,
        hasHadiAccount: _isCourier ? hasHadi : null,
        secretNote: _isCourier && hiddenNoteC.text.trim().isNotEmpty
            ? hiddenNoteC.text.trim()
            : null,

        dealerId: context.read<ApiClient>().currentUserId,

        // belgeler
        residencePdf: residencePdf,
        driverFront: driverFrontImage,
        goodConductPdf: goodConductPdf,
        documents: extraDocuments.isEmpty ? null : extraDocuments,
      );

      setState(() => createdUser = u);

      // Başarılı mesaj
      showMessageDialog(
        context,
        title: 'Başarılı',
        message: 'Kullanıcı oluşturuldu. ID: ${u.id}',
        type: MessageType.success,
      );

      // Form dialog’unu kapat
      Navigator.of(context).pop(true);

      // Cüzdanı çek (opsiyonel)
      try {
        final w = await api.getWallet(u.id);
        setState(() => wallet = w);
      } on DioException {
        // sessiz
      } catch (_) {
        // sessiz
      }
    } on DioException catch (e) {
      final msg = _prettyDioError(e);
      _snack(msg);
    } catch (_) {
      _snack('Kayıt başarısız. Lütfen tekrar deneyin.');
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  // DioException'ı kullanıcı dostu Türkçe mesaja çevir
  String _prettyDioError(DioException e) {
    final res = e.response;
    final data = res?.data;

    // Laravel tarzı: { message: "...", errors: { field: ["msg", ...] } }
    if (data is Map<String, dynamic>) {
      final errors = data['errors'];
      if (errors is Map) {
        for (final value in errors.values) {
          if (value is List && value.isNotEmpty) {
            final msg = value.first.toString();
            final lower = msg.toLowerCase();

            if (lower.contains('email') &&
                lower.contains('already been taken')) {
              return 'Bu e-posta adresi zaten kayıtlı.';
            }
            if (lower.contains('phone') &&
                lower.contains('already been taken')) {
              return 'Bu telefon numarası zaten kayıtlı.';
            }
            if (lower.contains('required')) {
              return 'Zorunlu alanları doldurun.';
            }

            return msg; // backend mesajını aynen göster
          }
        }
      }

      if (data['message'] != null) {
        return data['message'].toString();
      }
    }

    if (res?.statusCode == 422) {
      return 'Girilen bilgiler eksik veya hatalı. Lütfen formu kontrol edin.';
    }

    if (res?.statusCode == 409) {
      return 'Bu bilgilerle kayıtlı başka bir kullanıcı zaten var.';
    }

    if (e.type == DioExceptionType.connectionTimeout ||
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.connectionError) {
      return 'Sunucuya ulaşılamadı. İnternet bağlantınızı kontrol edin.';
    }

    return 'Kayıt başarısız. Lütfen bilgileri kontrol edip tekrar deneyin.';
  }

  void _snack(String m) {
    showMessageDialog(
      context,
      title: 'Bilgi',
      message: m,
      type: MessageType.warning,
    );
  }

  // ---------------- UI ----------------
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: LayoutBuilder(
        builder: (context, box) {
          final maxW = box.maxWidth > 1600 ? 1600.0 : box.maxWidth;
          return ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxW),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      widget.title,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildFormCardTwoColumns(),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildFormCardTwoColumns() {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: LayoutBuilder(
          builder: (context, c) {
            const gap = 16.0;
            final colW = (c.maxWidth - gap) / 2;
            return Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ----- Temel bilgiler
                  Wrap(
                    spacing: gap,
                    runSpacing: 12,
                    children: [
                      _tf(
                        nameC,
                        _isClient ? 'Ad/Ünvan *' : 'Adı *',
                        width: colW,
                        validator: _req,
                      ),
                      if (!_isClient)
                        _tf(
                          lastNameC,
                          'Soyadı *',
                          width: colW,
                          validator: _req,
                        ),
                      _tf(
                        phoneC,
                        'Telefon Numarası *',
                        width: colW,
                        keyboard: TextInputType.phone,
                        validator: _req,
                      ),

                      // Şifre alanı (göster/gizle)
                      SizedBox(
                        width: colW,
                        child: TextFormField(
                          controller: passC,
                          obscureText: _obscurePass,
                          validator: _req,
                          decoration: InputDecoration(
                            border: const OutlineInputBorder(),
                            labelText: 'Şifre *',
                            suffixIcon: IconButton(
                              tooltip: _obscurePass
                                  ? 'Şifreyi göster'
                                  : 'Şifreyi gizle',
                              icon: Icon(
                                _obscurePass
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                              ),
                              onPressed: () =>
                                  setState(() => _obscurePass = !_obscurePass),
                            ),
                          ),
                        ),
                      ),
                      _tf(
                        userC,
                        'Kullanıcı Adı',
                        width: colW,
                      ),
                      _tf(
                        emailC,
                        'E-posta',
                        width: colW,
                        keyboard: TextInputType.emailAddress,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // ----- Adres / konum
                  Wrap(
                    spacing: gap,
                    runSpacing: 12,
                    children: [
                      _cityDistrictRow(colW * 2),
                      SizedBox(
                        width: colW * 2,
                        child: TextFormField(
                          controller: addrC,
                          maxLines: 3,
                          onChanged: _onAddressChanged,
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Adres (ops.)',
                          ),
                        ),
                      ),
                      SizedBox(
                        width: colW * 2,
                        child: Row(
                          children: [
                            Expanded(
                                child: _tf(latC, 'Latitude (ops.)',
                                    keyboard:
                                        const TextInputType.numberWithOptions(
                                            decimal: true))),
                            const SizedBox(width: gap),
                            Expanded(
                                child: _tf(lngC, 'Longitude (ops.)',
                                    keyboard:
                                        const TextInputType.numberWithOptions(
                                            decimal: true))),
                          ],
                        ),
                      ),
                    ],
                  ),

                  // ----- Kurye özel
                  if (_isCourier) ...[
                    const SizedBox(height: 16),
                    _sectionHeader('Kurye Bilgileri'),
                    Wrap(
                      spacing: gap,
                      runSpacing: 12,
                      children: [
                        _tf(plateC, 'Plaka', width: colW),
                        _tf(
                          ibanC,
                          'IBAN *',
                          width: colW,
                          validator: _req,
                        ),
                        _tf(
                          bankOwnerC,
                          'Hesap Sahibi *',
                          width: colW,
                          validator: _req,
                        ),
                        SizedBox(
                          width: colW,
                          child: DropdownButtonFormField<String>(
                            value: commissionType,
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              labelText: 'Komisyon Tipi *',
                            ),
                            items: const [
                              DropdownMenuItem(
                                value: 'percent',
                                child: Text('Yüzde'),
                              ),
                              DropdownMenuItem(
                                value: 'fixed',
                                child: Text('Sabit Fiyat'),
                              ),
                            ],
                            onChanged: (v) =>
                                setState(() => commissionType = v ?? 'percent'),
                          ),
                        ),
                        _tf(
                          commissionRateC,
                          'Komisyon Oranı *',
                          width: colW,
                          validator: _req,
                          keyboard: const TextInputType.numberWithOptions(
                              decimal: true),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Checkbox(
                          value: canTakeOrders,
                          onChanged: (v) =>
                              setState(() => canTakeOrders = v ?? true),
                        ),
                        const Text('Sipariş alabilir mi?'),
                        const SizedBox(width: 24),
                        Checkbox(
                          value: hasHadi,
                          onChanged: (v) =>
                              setState(() => hasHadi = v ?? false),
                        ),
                        const Text('HADİ Hesabı Var mı?'),
                      ],
                    ),
                    const SizedBox(height: 8),
                    _ta(hiddenNoteC, 'Gizli Not (ops.)', width: colW * 2),
                  ],

                  // (İstersen buraya belge seçimi için butonlar ekleyebilirsin)
                  // Örn:
                  // Row(
                  //   children: [
                  //     TextButton(
                  //       onPressed: () => _pickOne(
                  //         extensions: ['pdf'],
                  //         onPick: (f) => setState(() => residencePdf = f),
                  //       ),
                  //       child: const Text('İkametgah PDF Yükle'),
                  //     ),
                  //     ...
                  //   ],
                  // ),

                  const SizedBox(height: 12),

                  // ----- Kaydet butonu -----
                  SizedBox(
                    width: colW * 2,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        FilledButton.icon(
                          onPressed: loading ? null : _submit,
                          icon: const Icon(Icons.save),
                          label: Text(loading ? 'Kaydediliyor...' : 'Kaydet'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _cityDistrictRow(double width) {
    return SizedBox(
      width: width,
      child: Row(
        children: [
          // Şehir
          Expanded(
            child: DropdownButtonFormField<int>(
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Şehir (İl)',
                border: OutlineInputBorder(),
              ),
              value: selectedCityId,
              items: cities
                  .map(
                    (c) => DropdownMenuItem(value: c.id, child: Text(c.name)),
                  )
                  .toList(),
              onChanged: (v) async {
                setState(() {
                  selectedCityId = v;
                  selectedDistrictId = null;
                  districts = [];
                });
                await _loadDistrictsByCity();
              },
            ),
          ),
          const SizedBox(width: 16),
          // İlçe
          Expanded(
            child: DropdownButtonFormField<int>(
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'İlçe',
                border: OutlineInputBorder(),
              ),
              value: selectedDistrictId,
              items: districts
                  .map(
                    (d) => DropdownMenuItem(value: d.id, child: Text(d.name)),
                  )
                  .toList(),
              onChanged: (v) => setState(() => selectedDistrictId = v),
            ),
          ),
        ],
      ),
    );
  }

  String? _req(String? v) => (v == null || v.trim().isEmpty) ? 'Zorunlu' : null;

  Widget _tf(
    TextEditingController c,
    String label, {
    TextInputType? keyboard,
    bool obscure = false,
    String? Function(String?)? validator,
    double? width,
  }) {
    return SizedBox(
      width: width ?? double.infinity,
      child: TextFormField(
        controller: c,
        keyboardType: keyboard,
        obscureText: obscure,
        decoration: const InputDecoration(
          border: OutlineInputBorder(),
        ).copyWith(labelText: label),
        validator: validator,
      ),
    );
  }

  Widget _ta(TextEditingController c, String label, {double? width}) {
    return SizedBox(
      width: width ?? double.infinity,
      child: TextFormField(
        controller: c,
        maxLines: 3,
        decoration: const InputDecoration(
          border: OutlineInputBorder(),
        ).copyWith(labelText: label),
      ),
    );
  }

  Widget _sectionHeader(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6, top: 4),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 16,
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Text(
            text,
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ],
      ),
    );
  }
}
