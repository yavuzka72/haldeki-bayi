// lib/widgets/shell_scaffold.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/cart.dart';
import '../services/api_client.dart';

class KClientsColors {
  // Brand
  static const purple = Color(0xFF0D4631);
  static const purple2 = Color(0xFF0D4631);
  static const orange = Color(0xFFff23cc);

  // Neutral
  static const bg = Color(0xFFF6F7FB);
  static const card = Color(0xFFFFFFFF);
  static const soft = Color(0xFFF8FAFC);
  static const line = Color(0xFFE6E8EF);

  static const text = Color(0xFF0F172A);
  static const muted = Color(0xFF64748B);

  // Status
  static const passive = Color(0xFF475569);
}

class ShellScaffold extends StatefulWidget {
  final Widget child;

  /// 0:dash, 1:market, 2:cart, 3:orders(any), 4:profile (bottom nav)
  final int currentIndex;

  /// Rail badge sayaçları (opsiyonel)
  final int activeOrdersCount; // /orders
  final int handedOverCount; // /delivery-orders

  /// AppBar bilgileri (opsiyonel)
  final String? userName;

  const ShellScaffold({
    super.key,
    required this.child,
    required this.currentIndex,
    this.activeOrdersCount = 0,
    this.handedOverCount = 0,
    this.userName,
  });

  @override
  State<ShellScaffold> createState() => _ShellScaffoldState();
}

class _ShellScaffoldState extends State<ShellScaffold> {
  bool _ordersExpanded = false;
  bool _reportsExpanded = false;

  @override
  void dispose() {
    super.dispose();
  }

  // ---- Güvenli sepet satır sayısı ----
  int _safeLineCount(dynamic cart) {
    try {
      if (cart == null) return 0;
      final lines = (cart as dynamic).lines;
      if (lines is List) return lines.length;
      if (lines is int) return lines;
      final lc = (cart as dynamic).lineCount;
      if (lc is int) return lc;
    } catch (_) {}
    return 0;
  }

  // ---- Path güvenli okuma (sürüm farklarına dayanıklı) ----
  String _safeCurrentPath(BuildContext context) {
    try {
      return GoRouterState.of(context).uri.path;
    } catch (_) {
      try {
        final loc = GoRouterState.of(context).matchedLocation;
        if (loc.isNotEmpty) return Uri.parse(loc).path;
      } catch (_) {
        try {
          final info = GoRouter.of(context).routeInformationProvider.value;
          final loc = info.location;
          if (loc != null) return Uri.parse(loc).path;
        } catch (_) {}
      }
    }
    return '/';
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final isWide = w >= 1000;
    final isExtended = w >= 1280;

    final cart = context.watch<Cart>();
    final lineCount = _safeLineCount(cart);

    final api = context.watch<ApiClient>();
    final profile = api.currentProfile;

    final upperName =
        ((profile?.name ?? widget.userName ?? 'A BAYİ')).toUpperCase();
    final email = profile?.email ?? '';

    final rail = _buildRailModel(
      context,
      lineCount,
      lineCount > 0,
      widget.activeOrdersCount,
      widget.handedOverCount,
    );

    // "/" gelirse dashboard'a
    final currentPath = _safeCurrentPath(context);
    if (currentPath == '/' || currentPath.isEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.go('/dashboard');
      });
    }

    return Scaffold(
      backgroundColor: KClientsColors.bg,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(58),
        child: _TopBarLight(
          title: 'Haldeki Bayi',
          businessName: upperName,
          businessEmail: email,
          onLogout: () async {
            try {
              await api.logout();
            } catch (_) {}
            if (!mounted) return;
            context.go('/login');
          },
        ),
      ),
      body: Row(
        children: [
          if (isWide)
            _LightRail(
              isExtended: isExtended,
              rail: rail,
              onAction: (action) {
                switch (action.type) {
                  case _ActionType.toggle:
                    setState(() {
                      if (action.toggleKey == 'orders') {
                        _ordersExpanded = !_ordersExpanded;
                      } else if (action.toggleKey == 'reports') {
                        _reportsExpanded = !_reportsExpanded;
                      }
                    });
                    break;
                  case _ActionType.route:
                    final route = action.route;
                    if (route != null) context.go(route);
                    break;
                }
              },
            ),
          if (isWide) _buildVerticalDivider(),
          Expanded(
            child: Container(
              color: KClientsColors.bg,
              child: widget.child,
            ),
          ),
        ],
      ),
      bottomNavigationBar: isWide
          ? _buildStatusBar(context)
          : Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildStatusBar(context),
                Theme(
                  data: Theme.of(context).copyWith(
                    navigationBarTheme: NavigationBarThemeData(
                      backgroundColor: KClientsColors.card,
                      indicatorColor: KClientsColors.purple.withOpacity(.12),
                      labelTextStyle: WidgetStateProperty.all(
                        const TextStyle(
                          fontWeight: FontWeight.w700,
                          color: KClientsColors.text,
                        ),
                      ),
                    ),
                  ),
                  child: NavigationBar(
                    selectedIndex: widget.currentIndex.clamp(0, 5),
                    destinations: const [
                      NavigationDestination(
                        icon: Icon(Icons.dashboard_outlined),
                        selectedIcon: Icon(Icons.dashboard),
                        label: 'Dashboard',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.dashboard_outlined),
                        selectedIcon: Icon(Icons.dashboard),
                        label: 'Operasyon',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.store_mall_directory_outlined),
                        selectedIcon: Icon(Icons.store_mall_directory),
                        label: 'Market',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.shopping_cart_outlined),
                        selectedIcon: Icon(Icons.shopping_cart),
                        label: 'Sepet',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.receipt_long_outlined),
                        selectedIcon: Icon(Icons.receipt_long),
                        label: 'Siparişler',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.account_circle_outlined),
                        selectedIcon: Icon(Icons.account_circle),
                        label: 'Profil',
                      ),
                    ],
                    onDestinationSelected: (i) {
                      switch (i) {
                        case 0:
                          context.go('/dashboard');
                          break;
                        case 10:
                          context.go('/operasyon');
                          break;
                        case 2:
                          context.go('/market');
                          break;
                        case 3:
                          context.go('/cart');
                          break;
                        case 4:
                          context.go('/orders');
                          break;
                        case 5:
                          context.go('/profile');
                          break;
                      }
                    },
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildVerticalDivider() {
    return Container(
      width: 1,
      height: double.infinity,
      color: KClientsColors.line,
    );
  }

  Widget _buildStatusBar(BuildContext context) {
    final api = context.watch<ApiClient>();
    final p = api.currentProfile;

    final rawName = (p?.name ?? widget.userName ?? 'A BAYİ');
    final name = rawName.toUpperCase();

    final city = (p?.city ?? '').trim().toUpperCase();
    final district = (p?.district ?? '').trim().toUpperCase();
    final addr = (p?.address ?? '').trim();

    final locParts = <String>[];
    if (city.isNotEmpty) locParts.add(city);
    if (district.isNotEmpty) locParts.add(district);
    final locPart = locParts.join(' / ');

    String addressLine;
    if (locPart.isEmpty) {
      addressLine = addr;
    } else if (addr.isEmpty) {
      addressLine = locPart;
    } else {
      addressLine = '$locPart, $addr';
    }

    final text = addressLine.trim().isEmpty ? name : '$name — $addressLine';

    return Material(
      color: KClientsColors.card,
      child: SafeArea(
        top: false,
        child: Container(
          height: 30,
          decoration: const BoxDecoration(
            border: Border(top: BorderSide(color: KClientsColors.line)),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              const Icon(Icons.person, size: 16, color: KClientsColors.orange),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  text,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12.5,
                    color: KClientsColors.text,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------- RAIL MODEL ----------
  _RailBuild _buildRailModel(
    BuildContext context,
    int lineCount,
    bool hasItems,
    int activeOrdersCount,
    int handedOverCount,
  ) {
    final actions = <_Action>[];
    final dests = <NavigationRailDestination>[];

    final path = _safeCurrentPath(context);

    final inOrders =
        path.startsWith('/orders') || path.startsWith('/delivery-orders');
    final inReports = path.startsWith('/reports') ||
        path.startsWith('/product-dashboard') ||
        path.startsWith('/client-dashboard');

    final ordersOpen = _ordersExpanded || inOrders;
    final reportsOpen = _reportsExpanded || inReports;

    int add({
      required Widget icon,
      required Widget selectedIcon,
      required Widget label,
      required _Action action,
    }) {
      actions.add(action);
      dests.add(
        NavigationRailDestination(
          icon: icon,
          selectedIcon: selectedIcon,
          label: label,
        ),
      );
      return dests.length - 1;
    }

    // helpers (indent)
    const indentIconPad = EdgeInsets.only(left: 7);
    const indentLabelPad = EdgeInsets.only(left: 8);

    Widget chevronLabel(String text, bool expanded) => Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(text),
            const SizedBox(width: 6),
            AnimatedRotation(
              turns: expanded ? 0.5 : 0.0,
              duration: const Duration(milliseconds: 150),
              child: const Icon(Icons.expand_more, size: 14),
            ),
          ],
        );

    Widget indentedText(String t) => Padding(
          padding: indentLabelPad,
          child: Text(t),
        );

    Widget indentedIconWithBadge(IconData icon, int count) => Padding(
          padding: indentIconPad,
          child: _BadgeIcon(
            count: count,
            child: Icon(icon, size: 20),
          ),
        );

    // 1) Ana Sayfa
    add(
      icon: const Icon(Icons.dashboard_outlined),
      selectedIcon: const Icon(Icons.dashboard),
      label: const Text('Ana Sayfa'),
      action: const _Action.route('/dashboard'),
    );
    add(
      icon: const Icon(Icons.dashboard_outlined),
      selectedIcon: const Icon(Icons.dashboard),
      label: const Text('Operasyon'),
      action: const _Action.route('/operasyon'),
    );

    // 2) Siparişler (grup)
    add(
      icon: const Icon(Icons.receipt_long_outlined),
      selectedIcon: const Icon(Icons.receipt_long),
      label: chevronLabel('Siparişler', ordersOpen),
      action: const _Action.toggle('orders'),
    );

    if (ordersOpen) {
      add(
        icon: indentedIconWithBadge(Icons.receipt_long, activeOrdersCount),
        selectedIcon:
            indentedIconWithBadge(Icons.receipt_long, activeOrdersCount),
        label: indentedText('Aktif Siparişler'),
        action: const _Action.route('/orders'),
      );
      add(
        icon: indentedIconWithBadge(Icons.motorcycle, handedOverCount),
        selectedIcon: indentedIconWithBadge(Icons.motorcycle, handedOverCount),
        label: indentedText('Kuryeye Aktarılan'),
        action: const _Action.route('/delivery-orders'),
      );
    }

    // 3) İşletmeler / Müşteriler
    add(
      icon: const Icon(Icons.people_outline),
      selectedIcon: const Icon(Icons.people),
      label: const Text('İşletmeler'),
      action: const _Action.route('/customers'),
    );
    add(
      icon: const Icon(Icons.person_outline),
      selectedIcon: const Icon(Icons.person),
      label: const Text('Müşteriler'),
      action: const _Action.route('/users'),
    );

    // 4) Kuryeler
    add(
      icon: const Icon(Icons.delivery_dining_outlined),
      selectedIcon: const Icon(Icons.delivery_dining),
      label: const Text('Kuryeler'),
      action: const _Action.route('/couriers'),
    );

    // 5) Kasa
    add(
      icon: const Icon(Icons.point_of_sale_outlined),
      selectedIcon: const Icon(Icons.point_of_sale),
      label: const Text('Kasa'),
      action: const _Action.route('/cash'),
    );

    // 6) Raporlar (grup)
    add(
      icon: const Icon(Icons.insert_chart_outlined),
      selectedIcon: const Icon(Icons.insert_chart),
      label: chevronLabel('Raporlar', reportsOpen),
      action: const _Action.toggle('reports'),
    );

    if (reportsOpen) {
      add(
        icon: const Padding(
          padding: indentIconPad,
          child: Icon(Icons.circle, size: 14),
        ),
        selectedIcon: const Padding(
          padding: indentIconPad,
          child: Icon(Icons.circle, size: 14),
        ),
        label: indentedText('Kasa Raporu'),
        action: const _Action.route('/cash'),
      );
      add(
        icon: const Padding(
          padding: indentIconPad,
          child: Icon(Icons.circle, size: 14),
        ),
        selectedIcon: const Padding(
          padding: indentIconPad,
          child: Icon(Icons.circle, size: 14),
        ),
        label: indentedText('İşletme Raporu'),
        action: const _Action.route('/reports/customers'),
      );
      add(
        icon: const Padding(
          padding: indentIconPad,
          child: Icon(Icons.circle, size: 14),
        ),
        selectedIcon: const Padding(
          padding: indentIconPad,
          child: Icon(Icons.circle, size: 14),
        ),
        label: indentedText('Kurye Raporu'),
        action: const _Action.route('/reports/couriers'),
      );
      add(
        icon: const Padding(
          padding: indentIconPad,
          child: Icon(Icons.circle, size: 14),
        ),
        selectedIcon: const Padding(
          padding: indentIconPad,
          child: Icon(Icons.circle, size: 14),
        ),
        label: indentedText('Ürün Raporu'),
        action: const _Action.route('/product-dashboard'),
      );
      add(
        icon: const Padding(
          padding: indentIconPad,
          child: Icon(Icons.circle, size: 14),
        ),
        selectedIcon: const Padding(
          padding: indentIconPad,
          child: Icon(Icons.circle, size: 14),
        ),
        label: indentedText('İşletme Ürün Raporu'),
        action: const _Action.route('/client-dashboard'),
      );
    }

    // 7) Profil
    add(
      icon: const Icon(Icons.account_circle_outlined),
      selectedIcon: const Icon(Icons.account_circle),
      label: const Text('Profil'),
      action: const _Action.route('/profile'),
    );

    // selectedIndex
    int selectedIndex = actions.indexWhere((a) {
      if (a.type != _ActionType.route || a.route == null) return false;
      final r = a.route!;
      return path == r || path.startsWith('$r/');
    });
    if (selectedIndex < 0) selectedIndex = 0;

    return _RailBuild(dests, actions, selectedIndex);
  }
}

// =====================================================
//  LIGHT RAIL WRAPPER
// =====================================================
class _LightRail extends StatelessWidget {
  const _LightRail({
    required this.isExtended,
    required this.rail,
    required this.onAction,
  });

  final bool isExtended;
  final _RailBuild rail;
  final ValueChanged<_Action> onAction;

  @override
  Widget build(BuildContext context) {
    final railWidth = isExtended ? 280.0 : 94.0;

    return SizedBox(
      width: railWidth,
      child: Theme(
        data: Theme.of(context).copyWith(
          navigationRailTheme: const NavigationRailThemeData(
            backgroundColor: KClientsColors.card,
            elevation: 0,
          ),
          iconTheme: const IconThemeData(color: KClientsColors.muted),
        ),
        child: SafeArea(
          child: NavigationRail(
            backgroundColor: KClientsColors.card,
            extended: isExtended,
            minExtendedWidth: 280,
            labelType: isExtended
                ? NavigationRailLabelType.none
                : NavigationRailLabelType.selected,
            minWidth: isExtended ? 94 : 76,
            useIndicator: true,
            indicatorColor: KClientsColors.purple.withOpacity(.12),
            indicatorShape: const StadiumBorder(),
            selectedIconTheme: const IconThemeData(
              color: KClientsColors.purple,
              size: 20,
            ),
            unselectedIconTheme: const IconThemeData(
              color: KClientsColors.muted,
              size: 25,
            ),
            selectedLabelTextStyle: const TextStyle(
              color: KClientsColors.purple,
              fontWeight: FontWeight.w800,
            ),
            unselectedLabelTextStyle: const TextStyle(
              color: KClientsColors.muted,
              fontWeight: FontWeight.w700,
            ),
            groupAlignment: -1,
            leading: const _RailHeaderLight(
              title: 'haldeki.com',
              logoAsset: 'assets/logo/haldeki_logo_icon.png',
            ),
            destinations: rail.destinations.isEmpty
                ? const [
                    NavigationRailDestination(
                      icon: Icon(Icons.home_outlined),
                      selectedIcon: Icon(Icons.home),
                      label: Text('Ana Sayfa'),
                    ),
                  ]
                : rail.destinations,
            selectedIndex: rail.destinations.isEmpty
                ? 0
                : rail.selectedIndex.clamp(0, rail.destinations.length - 1),
            onDestinationSelected: (i) => onAction(rail.actions[i]),
          ),
        ),
      ),
    );
  }
}

// --- yardımcı yapılar ---
class _RailBuild {
  final List<NavigationRailDestination> destinations;
  final List<_Action> actions;
  final int selectedIndex;
  _RailBuild(this.destinations, this.actions, this.selectedIndex);
}

enum _ActionType { route, toggle }

class _Action {
  final _ActionType type;
  final String? route;
  final String? toggleKey;
  const _Action._(this.type, this.route, this.toggleKey);
  const _Action.route(this.route)
      : type = _ActionType.route,
        toggleKey = null;
  const _Action.toggle(this.toggleKey)
      : type = _ActionType.toggle,
        route = null;
}

class _RailHeaderLight extends StatelessWidget {
  const _RailHeaderLight({required this.title, this.logoAsset});
  final String title;
  final String? logoAsset;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
      child: Column(
        children: [
          Container(
            width: 52,
            height: 52,
            alignment: Alignment.center,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: logoAsset == null
                  ? const SizedBox.shrink()
                  : Image.asset(
                      logoAsset!,
                      width: 52,
                      height: 52,
                      fit: BoxFit.cover,
                    ),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: KClientsColors.text,
              fontWeight: FontWeight.w900,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: KClientsColors.purple.withOpacity(.10),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(
                color: KClientsColors.purple.withOpacity(.25),
              ),
            ),
            child: const Text(
              'BAYİ PANEL',
              style: TextStyle(
                color: KClientsColors.muted,
                fontWeight: FontWeight.w800,
                fontSize: 11,
                letterSpacing: .6,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Basit badge (palette uyumlu)
class _BadgeIcon extends StatelessWidget {
  final int count;
  final Widget child;
  const _BadgeIcon({required this.count, required this.child});

  @override
  Widget build(BuildContext context) {
    if (count <= 0) return child;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        child,
        Positioned(
          right: -7,
          top: -6,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: KClientsColors.orange,
              borderRadius: BorderRadius.circular(999),
              boxShadow: [
                BoxShadow(
                  blurRadius: 14,
                  color: KClientsColors.orange.withOpacity(.25),
                ),
              ],
            ),
            constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
            child: Text(
              count > 99 ? '99+' : '$count',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 10,
                fontWeight: FontWeight.w900,
                height: 1.2,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// ---- Projede kullanabileceğin durum chip'i ----
class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});

  @override
  Widget build(BuildContext context) {
    Color bg;
    Color fg;

    switch (status) {
      case 'Hazırlanıyor':
        bg = const Color(0xFFFFF3CD);
        fg = const Color(0xFF856404);
        break;
      case 'Sevk Edildi':
        bg = const Color(0xFFD1ECF1);
        fg = const Color(0xFF0C5460);
        break;
      case 'Yolda':
        bg = const Color(0xFFE2D9F3);
        fg = const Color(0xFF38215C);
        break;
      case 'Teslim Edildi':
        bg = const Color(0xFFD4EDDA);
        fg = const Color(0xFF155724);
        break;
      case 'İptal':
        bg = const Color(0xFFF8D7DA);
        fg = const Color(0xFF721C24);
        break;
      default:
        bg = const Color(0xFFEFF2F8);
        fg = const Color(0xFF334155);
    }

    return Chip(
      label: Text(status),
      backgroundColor: bg,
      labelStyle: TextStyle(color: fg, fontWeight: FontWeight.w700),
      padding: const EdgeInsets.symmetric(horizontal: 8),
      visualDensity: VisualDensity.compact,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
    );
  }
}

/// ---- Üst bar bileşeni (light) ----
class _TopBarLight extends StatelessWidget {
  final String title;
  final String businessName;
  final String businessEmail;
  final VoidCallback onLogout;

  const _TopBarLight({
    required this.title,
    required this.businessName,
    required this.businessEmail,
    required this.onLogout,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 58,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: const BoxDecoration(
        color: KClientsColors.card,
        border: Border(
          bottom: BorderSide(color: KClientsColors.line),
        ),
      ),
      child: Row(
        children: [
          // brand chip
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: KClientsColors.soft,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: KClientsColors.line),
            ),
            child: Row(
              children: [
                Image.asset(
                  'assets/logo/haldeki_logo_icon.png',
                  width: 18,
                  height: 18,
                  fit: BoxFit.cover,
                ),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(
                    color: KClientsColors.text,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),

          const Spacer(),

          // user info
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                businessName,
                style: const TextStyle(
                  color: KClientsColors.text,
                  fontWeight: FontWeight.w900,
                  fontSize: 13.5,
                ),
              ),
              if (businessEmail.isNotEmpty)
                Text(
                  businessEmail,
                  style: const TextStyle(
                    color: KClientsColors.muted,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
            ],
          ),

          const SizedBox(width: 12),

          // logout
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: KClientsColors.purple.withOpacity(.10),
              foregroundColor: KClientsColors.text,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: BorderSide(color: KClientsColors.purple.withOpacity(.22)),
              ),
            ),
            onPressed: onLogout,
            icon: const Icon(Icons.logout,
                size: 18, color: KClientsColors.orange),
            label: const Text(
              'Çıkış',
              style: TextStyle(fontWeight: FontWeight.w900),
            ),
          ),
        ],
      ),
    );
  }
}
