// lib/router.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:haldeki_admin_web/models/courier_models.dart';
import 'package:haldeki_admin_web/models/dealer_profile.dart';
import 'package:haldeki_admin_web/reports/daily_cash_dashboard.dart';
import 'package:haldeki_admin_web/reports/reports_cash_page.dart';
import 'package:haldeki_admin_web/reports/reports_couriers_page.dart';
import 'package:haldeki_admin_web/reports/reports_customers_page.dart';
import 'package:haldeki_admin_web/reports/reports_orders_page.dart';

import 'package:haldeki_admin_web/screens/admin/client_create_screen.dart';
import 'package:haldeki_admin_web/screens/client_dashboard_screen.dart';

import 'package:haldeki_admin_web/screens/courier_detail_screen.dart';
import 'package:haldeki_admin_web/screens/couriers_screen.dart';
import 'package:haldeki_admin_web/screens/customer_detail_screen.dart';
import 'package:haldeki_admin_web/screens/customer_report_screen.dart';
import 'package:haldeki_admin_web/screens/dealer_profile_screen.dart';

import 'package:haldeki_admin_web/screens/delivery_order_detail_screen.dart';
import 'package:haldeki_admin_web/screens/delivery_orders_screen.dart';
import 'package:haldeki_admin_web/screens/ops_map_screen.dart';
import 'package:haldeki_admin_web/screens/price_list_screen.dart';
import 'package:haldeki_admin_web/screens/product_dashboard_screen.dart';
import 'package:haldeki_admin_web/screens/supplier_profile_screen.dart';
import 'package:haldeki_admin_web/screens/users_screen%20.dart';
import 'package:haldeki_admin_web/services/api_client.dart';
import 'package:http/http.dart' as context;

import 'screens/login_screen.dart';
import 'screens/shell.dart';
import 'screens/dashboard_screen.dart';
import 'screens/market_screen.dart';
import 'screens/cart_screen.dart';
import 'screens/orders_screen.dart';
import 'screens/order_detail_screen.dart';
import 'screens/suppliers_screen.dart'; // ✅ yeni import
import 'screens/customers_screen.dart';

class AppRouter {
  static GoRouter build() {
    return GoRouter(
      initialLocation: '/login',
      routes: [
        GoRoute(
          path: '/login',
          builder: (context, state) => const LoginScreen(),
        ),
        ShellRoute(
          builder: (context, state, child) {
            final loc = state.uri.path;
            final index = _navIndexFor(loc);
            return ShellScaffold(child: child, currentIndex: index);
          },
          routes: [
            GoRoute(
                path: '/dashboard',
                builder: (_, __) => const DashboardScreen()),
            GoRoute(path: '/market', builder: (_, __) => const MarketScreen()),
            /*    GoRoute(
              path: '/cart',
              builder: (_, __) => const PriceListScreen(), // ✅ const YOK
            ),*/
            GoRoute(
                path: '/customers', builder: (c, s) => const ClientsScreen()),

            GoRoute(
              path: '/customers/:id',
              builder: (c, s) {
                final id = int.tryParse(s.pathParameters['id'] ?? '') ?? 0;
                final initial =
                    s.extra is CustomerLite ? s.extra as CustomerLite : null;
                return CustomerDetailScreen(id: id, initial: initial);
              },
            ),
            GoRoute(path: '/users', builder: (c, s) => const UsersScreen()),
            GoRoute(
              path: '/users/:id',
              builder: (c, s) {
                final id = int.tryParse(s.pathParameters['id'] ?? '') ?? 0;
                final initial =
                    s.extra is CustomerLite ? s.extra as CustomerLite : null;
                return CustomerDetailScreen(id: id, initial: initial);
              },
            ),

/*
            GoRoute(
              path: '/reports/customers',
              name: 'CustomerReport',
              builder: (context, state) => const CustomerReportScreen(),
            ),
*/
            GoRoute(
              path: '/admin/clients/create',
              builder: (ctx, st) => const ClientCreateScreen(),
            ),

            GoRoute(
              path: '/delivery-orders',
              builder: (_, __) => const DeliveryOrdersScreen(),
              routes: [
                GoRoute(
                  name: 'deliveryOrderDetail', // 👈 isim
                  path: ':orderNumber',
                  builder: (_, state) {
                    final orderNo = Uri.decodeComponent(
                        state.pathParameters['orderNumber']!);
                    final initialDeliveryStatus =
                        state.uri.queryParameters['status'];

                    return DeliveryOrderDetailScreen(
                      orderNumber: orderNo,
                      initialDeliveryStatus: initialDeliveryStatus,
                    );
                  },
                ),
              ],
            ),

            GoRoute(
                path: '/couriers', builder: (c, s) => const CouriersScreen()),
            GoRoute(
              path: '/couriers/:id',
              name: 'courier-detail',
              // Geçersiz id ise listeye yönlendir
              redirect: (context, state) {
                final id = int.tryParse(state.pathParameters['id'] ?? '');
                if (id == null || id <= 0) return '/couriers';
                return null;
              },
              builder: (context, state) {
                final id = int.parse(state.pathParameters['id']!);
                final initial = (state.extra is CourierLite)
                    ? state.extra as CourierLite
                    : null;

                return CourierDetailScreen(
                  id: id,
                  initial: initial,
                );
              },
            ),
            GoRoute(
              path: '/orders',
              builder: (_, __) => const OrdersScreen(),
              routes: [
                GoRoute(
                  path: ':orderNumber',
                  builder: (_, state) => OrderDetailScreen(
                    orderNumber: state.pathParameters['orderNumber']!,
                  ),
                ),
              ],
            ),
            /*   GoRoute(
                path: '/reports/cash',
                builder: (_, __) => const ReportsCashPage()),
                */
            GoRoute(
                path: '/reports/customers',
                builder: (_, __) => const ReportsCustomersPage()),
            GoRoute(
                path: '/reports/couriers',
                builder: (_, __) => const ReportsCouriersPage()),
            GoRoute(
                path: '/reports/orders',
                builder: (_, __) => const ReportsOrdersPage()),
            GoRoute(
                path: '/product-dashboard',
                builder: (_, __) => const ProductDashboardScreen()),
            GoRoute(
                path: '/client-dashboard',
                builder: (_, __) => const ClientProductDashboardScreen()),
            GoRoute(
                path: '/operasyon', builder: (_, __) => const OpsMapScreen()),

            GoRoute(
              path: '/cash',
              builder: (_, __) => const DailyCashDashboard(),
            ),
            // ✅ Suppliers
            GoRoute(
              path: '/suppliers',
              builder: (_, state) => SupplierProfileScreen(api: ApiClient()),
            ),
            GoRoute(
              path: '/profile',
              builder: (_, __) => const DealerProfileScreen(),
            ),
          ],
        ),
      ],
    );
  }

  // ✅ suppliers index=4
  static int _navIndexFor(String loc) {
    if (loc == '/dashboard') return 0;
    if (loc == '/market') return 1;
    if (loc == '/cart') return 2;
    if (loc == '/orders' || loc.startsWith('/orders/')) return 3;
    if (loc == '/suppliers') return 4;

    if (loc == '/cash') return 5;
    if (loc == '/profile') return 6;

    return 0;
  }
}
