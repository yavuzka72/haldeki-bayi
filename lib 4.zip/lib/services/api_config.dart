class ApiConfig {
  /// iOS Sim: http://localhost:8083/
  /// Android Emu: http://10.0.2.2:8000
  /// Prod: http://localhost:8083/
  static String base =
      'http://localhost:8083'; //'http://localhost:8083/'; // değiştirilebilir
  static String get v1 => '$base/api/v1';
}
