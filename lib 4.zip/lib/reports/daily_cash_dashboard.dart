import 'package:flutter/material.dart';
import 'package:haldeki_admin_web/services/api_client.dart';
import 'package:haldeki_admin_web/models/cash_report_models.dart';

/// Günlük Kasa & Komisyon Özeti
/// - ApiClient().fetchCashReport(...) ile backend /api/v1/cash çağrılır.
/// - from/to tarih aralığı HER ZAMAN gönderilir.
/// - initState: Bu ay başı -> bugün aralığı.
/// - Quick filter chip’ler: Bugün, Dün, Bu Hafta, Bu Ay.

class DailyCashDashboard extends StatefulWidget {
  const DailyCashDashboard({super.key});

  @override
  State<DailyCashDashboard> createState() => _DailyCashDashboardState();
}

class _DailyCashDashboardState extends State<DailyCashDashboard>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // ---------------------------------------------------------------------------
  // STATE
  // ---------------------------------------------------------------------------

  bool _loading = false;
  String? _errorMessage;

  // aktif filtre
  DateTime? _fromDate;
  DateTime? _toDate;
  int? _dealerId;
  int? _courierId;
  String _selectedQuickFilter = 'Bu Ay';

  // Günlük kasa özeti (vw_gunluk_kasa_ozet)
  List<DailyCashDay> dailyCash = [];

  // Müşteri tahsilat detayı (vw_musteri_tahsilat_detay)
  List<CustomerCollectionRow> customerRows = [];

  // Tedarikçi ödemeleri (vw_tedarikci_odeme_detay)
  List<SupplierPaymentRow> supplierRows = [];

  // Kurye ödemeleri (vw_kurye_odeme_detay)
  List<CourierPaymentRow> courierRows = [];

  // Bayi komisyonları (vw_bayi_komisyon_detay)
  List<VendorCommissionRow> vendorRows = [];

  // Toplamları hesapla
  double get totalTahsilat =>
      dailyCash.fold(0, (p, e) => p + e.musteriTahsilat);
  double get totalTedarikci =>
      dailyCash.fold(0, (p, e) => p + e.tedarikciOdeme);
  double get totalKurye => dailyCash.fold(0, (p, e) => p + e.kuryeOdeme);
  double get totalBayi => dailyCash.fold(0, (p, e) => p + e.bayiKomisyonu);
  double get totalNet => dailyCash.fold(0, (p, e) => p + e.netKasa);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);

    // Login olan user -> bayi id
    final api = ApiClient();
    _dealerId = api.currentUserId;

    // Default: Bu ay başı - bugün
    final now = DateTime.now();
    _fromDate = DateTime(now.year, now.month, 1);
    _toDate = DateTime(now.year, now.month, now.day);
    _selectedQuickFilter = 'Bu Ay';

    _fetchFromApi(
      from: _fromDate,
      to: _toDate,
      dealerId: _dealerId,
      courierId: _courierId,
    );
  }

  // ---------------------------------------------------------------------------
  // API
  // ---------------------------------------------------------------------------

  Future<void> _fetchFromApi({
    DateTime? from,
    DateTime? to,
    int? dealerId,
    int? courierId,
  }) async {
    setState(() {
      _loading = true;
      _errorMessage = null;
    });

    try {
      final api = ApiClient();

      // Eğer null geldiyse, state’teki son değerleri kullan
      from ??= _fromDate ?? DateTime.now();
      to ??= _toDate ?? DateTime.now();
      dealerId ??= _dealerId;
      courierId ??= _courierId;

      // state’e kaydet (filtre alanı güncel kalsın)
      _fromDate = from;
      _toDate = to;
      _dealerId = dealerId;
      _courierId = courierId;

      final res = await api.fetchCashReport(
        from: from,
        to: to,
        dealerId: dealerId,
        courierId: courierId,
      );

      setState(() {
        dailyCash = res.dailyCash;
        customerRows = res.customerCollections;
        supplierRows = res.supplierPayments;
        courierRows = res.courierPayments;
        vendorRows = res.vendorCommissions;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _errorMessage = e.toString();
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------------------
  // BUILD
  // ---------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surfaceVariant.withOpacity(0.15),
      appBar: AppBar(
        title: const Text('Günlük Kasa & Komisyon Özeti'),
        centerTitle: false,
      ),
      body: Center(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final maxW = constraints.maxWidth > 1400
                ? 1400.0
                : constraints.maxWidth - 32;

            return ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxW),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (_loading) const LinearProgressIndicator(minHeight: 2),
                    if (_errorMessage != null && !_loading)
                      Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(8),
                        color: Colors.red.shade50,
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(
                            color: Colors.red.shade700,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    _buildFilterBar(context),
                    const SizedBox(height: 16),
                    _buildSummaryRow(context),
                    const SizedBox(height: 16),
                    _buildChartsRow(context),
                    const SizedBox(height: 16),
                    _buildTabs(context),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // 1) FİLTRE BAR
  // ---------------------------------------------------------------------------

  Widget _buildFilterBar(BuildContext context) {
    String dateRangeLabel;
    if (_fromDate != null && _toDate != null) {
      if (_fromDate == _toDate) {
        dateRangeLabel =
            '${_fmtDate(_fromDate!)}'; // tek gün ise sadece tarihi yaz
      } else {
        dateRangeLabel = '${_fmtDate(_fromDate!)} - ${_fmtDate(_toDate!)}';
      }
    } else {
      dateRangeLabel = 'Seçili aralık';
    }

    return Card(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Wrap(
          spacing: 12,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            const Text(
              'Filtreler',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(width: 12),
            _quickFilterChip('Bugün'),
            _quickFilterChip('Dün'),
            _quickFilterChip('Bu Hafta'),
            _quickFilterChip('Bu Ay'),
            const SizedBox(width: 24),
          ],
        ),
      ),
    );
  }

  Widget _quickFilterChip(String label) {
    final isSelected = _selectedQuickFilter == label;

    return FilterChip(
      selected: isSelected,
      onSelected: (_) {
        final now = DateTime.now();
        DateTime from;
        DateTime to;

        if (label == 'Bugün') {
          from = DateTime(now.year, now.month, now.day);
          to = from;
        } else if (label == 'Dün') {
          final d = now.subtract(const Duration(days: 1));
          from = DateTime(d.year, d.month, d.day);
          to = from;
        } else if (label == 'Bu Hafta') {
          final weekStart =
              now.subtract(Duration(days: now.weekday - 1)); // Pazartesi
          from = DateTime(weekStart.year, weekStart.month, weekStart.day);
          to = DateTime(now.year, now.month, now.day);
        } else {
          // Bu Ay
          from = DateTime(now.year, now.month, 1);
          to = DateTime(now.year, now.month, now.day);
        }

        setState(() {
          _selectedQuickFilter = label;
        });

        _fetchFromApi(
          from: from,
          to: to,
          dealerId: _dealerId,
          courierId: _courierId,
        );
      },
      showCheckmark: false,
      label: Text(label),
    );
  }

  // ---------------------------------------------------------------------------
  // 2) ÖZET KARTLAR
  // ---------------------------------------------------------------------------

  Widget _buildSummaryRow(BuildContext context) {
    final cards = [
      _SummaryCardConfig(
        title: 'Müşteri Tahsilatı',
        value: totalTahsilat,
        subtitle: 'delivery_orders tahsilatları',
      ),
      _SummaryCardConfig(
        title: 'Tedarikçi Ödemeleri',
        value: totalTedarikci,
        subtitle: 'Tedarikçilere ödenecek',
      ),
      _SummaryCardConfig(
        title: 'Kurye Ödemeleri',
        value: totalKurye,
        subtitle: 'Kuryelere ödenecek',
      ),
      _SummaryCardConfig(
        title: 'Bayi Komisyonları',
        value: totalBayi,
        subtitle: 'Bayilere komisyon',
      ),
      _SummaryCardConfig(
        title: 'Net Kasa',
        value: totalNet,
        subtitle: 'Tahsilat - Giderler',
        highlight: true,
      ),
    ];

    return LayoutBuilder(
      builder: (context, c) {
        final isNarrow = c.maxWidth < 1000;
        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: cards
              .map(
                (cfg) => SizedBox(
                  width: isNarrow ? c.maxWidth : (c.maxWidth - 48) / 5,
                  child: _SummaryCard(cfg: cfg),
                ),
              )
              .toList(),
        );
      },
    );
  }

  // ---------------------------------------------------------------------------
  // 3) GRAFİK BENZERİ ORTA ALAN
  // ---------------------------------------------------------------------------

  Widget _buildChartsRow(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final isNarrow = c.maxWidth < 1000;
      if (isNarrow) {
        return Column(
          children: [
            _buildDailyNetBarChart(),
            const SizedBox(height: 12),
            _buildExpensePieLike(),
          ],
        );
      }

      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: _buildDailyNetBarChart()),
          const SizedBox(width: 12),
          SizedBox(width: 320, child: _buildExpensePieLike()),
        ],
      );
    });
  }

  /// Günlük net kasa bar grafiği (API verisiyle)
  Widget _buildDailyNetBarChart() {
    if (dailyCash.isEmpty) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Text('Günlük kasa verisi bulunamadı'),
        ),
      );
    }

    final maxNet = dailyCash
            .map((e) => e.netKasa.abs())
            .fold<double>(0, (p, e) => e > p ? e : p) +
        1; // 0’a bölünmesin

    return Card(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Günlük Net Kasa',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 4),
            Text(
              'Her gün için tahsilat - (tedarikçi + kurye + bayi)',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade700,
              ),
            ),
            const SizedBox(height: 12),
            Column(
              children: dailyCash.map((d) {
                final ratio = (d.netKasa.abs() / maxNet).clamp(0.05, 1.0);
                final isNegative = d.netKasa < 0;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 90,
                        child: Text(
                          _fmtDate(d.date),
                          style: const TextStyle(fontSize: 12),
                        ),
                      ),
                      Expanded(
                        child: Stack(
                          children: [
                            Container(
                              height: 18,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade200,
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                            FractionallySizedBox(
                              widthFactor: ratio,
                              alignment: Alignment.centerLeft,
                              child: Container(
                                height: 18,
                                decoration: BoxDecoration(
                                  color: isNegative
                                      ? Colors.red.shade400
                                      : Colors.green.shade400,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                            ),
                            Positioned.fill(
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 6),
                                  child: Text(
                                    _fmtCurrency(d.netKasa),
                                    style: const TextStyle(
                                      fontSize: 11,
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  /// Gider dağılımı (Tedarikçi / Kurye / Bayi)
  Widget _buildExpensePieLike() {
    final totalExpense = totalTedarikci + totalKurye + totalBayi;
    double pct(double v) => totalExpense == 0 ? 0 : ((v / totalExpense) * 100);

    return Card(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Gider Dağılımı',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 4),
            Text(
              'Tedarikçi + Kurye + Bayi giderleri',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
            ),
            const SizedBox(height: 12),
            _expenseRow('Tedarikçi Ödemeleri', totalTedarikci,
                pct(totalTedarikci), Colors.blue),
            const SizedBox(height: 6),
            _expenseRow(
                'Kurye Ödemeleri', totalKurye, pct(totalKurye), Colors.orange),
            const SizedBox(height: 6),
            _expenseRow(
                'Bayi Komisyonları', totalBayi, pct(totalBayi), Colors.purple),
            const Divider(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Toplam Gider'),
                Text(
                  _fmtCurrency(totalExpense),
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _expenseRow(String label, double value, double pct, Color color) {
    return Row(
      children: [
        Container(
          width: 10,
          height: 10,
          margin: const EdgeInsets.only(right: 6),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(fontSize: 13),
          ),
        ),
        Text(
          '${pct.toStringAsFixed(1)}%',
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const SizedBox(width: 8),
        Text(
          _fmtCurrency(value),
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
        ),
      ],
    );
  }

  // ---------------------------------------------------------------------------
  // 4) TABLAR (SEKMELER)
  // ---------------------------------------------------------------------------

  Widget _buildTabs(BuildContext context) {
    return Card(
      elevation: 1,
      child: SizedBox(
        height: 520, // sabit yükseklik, TabBarView içinde tablo + scroll
        child: Column(
          children: [
            TabBar(
              controller: _tabController,
              labelStyle: const TextStyle(fontWeight: FontWeight.w600),
              tabs: const [
                Tab(text: 'Müşteri Tahsilatları'),
                Tab(text: 'Tedarikçi Ödemeleri'),
                Tab(text: 'Kurye Ödemeleri'),
                Tab(text: 'Bayi Komisyonları'),
              ],
            ),
            const Divider(height: 1),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildCustomerTable(),
                  _buildSupplierTable(),
                  _buildCourierTable(),
                  _buildVendorTable(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomerTable() {
    final total = customerRows.fold<double>(0, (p, e) => p + e.collected);

    return Column(
      children: [
        _tableHeaderSummary('Toplam Tahsilat', total),
        const Divider(height: 1),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: DataTable(
              headingRowHeight: 36,
              columns: const [
                DataColumn(label: Text('Tarih')),
                DataColumn(label: Text('Teslimat Kodu')),
                DataColumn(label: Text('Müşteri')),
                DataColumn(label: Text('Sipariş Tutarı')),
                DataColumn(label: Text('Tahsil Edilen')),
                DataColumn(label: Text('Ödeme Durumu')),
                DataColumn(label: Text('Sipariş Durumu')),
              ],
              rows: customerRows.map((r) {
                return DataRow(
                  cells: [
                    DataCell(Text(_fmtDate(r.date))),
                    DataCell(Text(r.code)),
                    DataCell(Text(r.customerName)),
                    DataCell(Text(_fmtCurrency(r.amount))),
                    DataCell(Text(_fmtCurrency(r.collected))),
                    DataCell(Text(r.paymentStatus)),
                    DataCell(Text(r.orderStatus)),
                  ],
                );
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSupplierTable() {
    final total = supplierRows.fold<double>(0, (p, e) => p + e.payable);

    return Column(
      children: [
        _tableHeaderSummary('Toplam Tedarikçi Ödemesi', total),
        const Divider(height: 1),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: DataTable(
              headingRowHeight: 36,
              columns: const [
                DataColumn(label: Text('Tarih')),
                DataColumn(label: Text('Sipariş No')),
                DataColumn(label: Text('Tedarikçi')),
                DataColumn(label: Text('Sipariş Tutarı')),
                DataColumn(label: Text('Ödenecek Tutar')),
                DataColumn(label: Text('Sipariş Durumu')),
                DataColumn(label: Text('Ödeme Durumu')),
              ],
              rows: supplierRows.map((r) {
                return DataRow(
                  cells: [
                    DataCell(Text(_fmtDate(r.date))),
                    DataCell(Text(r.code)),
                    DataCell(Text(r.supplierName)),
                    DataCell(Text(_fmtCurrency(r.amount))),
                    DataCell(Text(_fmtCurrency(r.payable))),
                    DataCell(Text(r.status)),
                    DataCell(Text(r.paymentStatus)),
                  ],
                );
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCourierTable() {
    final total = courierRows.fold<double>(0, (p, e) => p + e.courierPayment);

    return Column(
      children: [
        _tableHeaderSummary('Toplam Kurye Ödemesi', total),
        const Divider(height: 1),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: DataTable(
              headingRowHeight: 36,
              columns: const [
                DataColumn(label: Text('Tarih')),
                DataColumn(label: Text('Teslimat Kodu')),
                DataColumn(label: Text('Kurye')),
                DataColumn(label: Text('Sipariş Tutarı')),
                DataColumn(label: Text('Kurye Ödemesi')),
                DataColumn(label: Text('Teslimat Durumu')),
                DataColumn(label: Text('Ödeme Durumu')),
              ],
              rows: courierRows.map((r) {
                return DataRow(
                  cells: [
                    DataCell(Text(_fmtDate(r.date))),
                    DataCell(Text(r.code)),
                    DataCell(Text(r.courierName)),
                    DataCell(Text(_fmtCurrency(r.amount))),
                    DataCell(Text(_fmtCurrency(r.courierPayment))),
                    DataCell(Text(r.status)),
                    DataCell(Text(r.paymentStatus)),
                  ],
                );
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildVendorTable() {
    final total = vendorRows.fold<double>(0, (p, e) => p + e.commission);

    return Column(
      children: [
        _tableHeaderSummary('Toplam Bayi Komisyonu', total),
        const Divider(height: 1),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: DataTable(
              headingRowHeight: 36,
              columns: const [
                DataColumn(label: Text('Tarih')),
                DataColumn(label: Text('Sipariş No')),
                //  DataColumn(label: Text('Bayi')),
                DataColumn(label: Text('Sipariş Tutarı')),
                DataColumn(label: Text('Komisyon')),
                DataColumn(label: Text('Sipariş Durumu')),
                DataColumn(label: Text('Ödeme Durumu')),
              ],
              rows: vendorRows.map((r) {
                return DataRow(
                  cells: [
                    DataCell(Text(_fmtDate(r.date))),
                    DataCell(Text(r.code)),
                    //DataCell(Text(r.bayi)),
                    DataCell(Text(_fmtCurrency(r.amount))),
                    DataCell(Text(_fmtCurrency(r.commission))),
                    DataCell(Text(r.status)),
                    DataCell(Text(r.paymentStatus)),
                  ],
                );
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _tableHeaderSummary(String label, double value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      alignment: Alignment.centerRight,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style:
                  const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
          Text(
            _fmtCurrency(value),
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // HELPERS
  // ---------------------------------------------------------------------------

  String _fmtCurrency(double v) {
    // Basit TR format
    return '${v.toStringAsFixed(2)} ₺';
  }

  String _fmtDate(DateTime d) {
    return '${d.day.toString().padLeft(2, '0')}.'
        '${d.month.toString().padLeft(2, '0')}.'
        '${d.year}';
  }
}

// ---------------------------------------------------------------------------
// Özet kart struct'ı
// ---------------------------------------------------------------------------

class _SummaryCardConfig {
  final String title;
  final double value;
  final String subtitle;
  final bool highlight;

  _SummaryCardConfig({
    required this.title,
    required this.value,
    required this.subtitle,
    this.highlight = false,
  });
}

class _SummaryCard extends StatelessWidget {
  final _SummaryCardConfig cfg;

  const _SummaryCard({required this.cfg, super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isPositive = cfg.highlight && cfg.value >= 0;

    return Card(
      elevation: 1.5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(cfg.title,
                style:
                    const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text(
              '${cfg.value.toStringAsFixed(2)} ₺',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: cfg.highlight
                    ? (isPositive ? Colors.green.shade700 : Colors.red.shade700)
                    : theme.colorScheme.primary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              cfg.subtitle,
              style: TextStyle(fontSize: 11, color: Colors.grey.shade700),
            ),
          ],
        ),
      ),
    );
  }
}
