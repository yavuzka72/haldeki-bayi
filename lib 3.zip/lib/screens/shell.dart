import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../models/cart.dart';

class ShellScaffold extends StatefulWidget {
  final Widget child;
  /// 0:dash, 1:market, 2:cart, 3:orders(any), 4:profile  (bottom nav için)
  final int currentIndex;
  const ShellScaffold({super.key, required this.child, required this.currentIndex});

  @override
  State<ShellScaffold> createState() => _ShellScaffoldState();
}

class _ShellScaffoldState extends State<ShellScaffold> {
  bool _ordersExpanded  = false; // Siparişler aç/kapa
  bool _reportsExpanded = false; // Raporlar aç/kapa

  // ⬇️ RAIL scroll için controller
  final ScrollController _railScroll = ScrollController();

  @override
  void dispose() {
    _railScroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 1000;

    final cart      = context.watch<Cart>();
    final lineCount = cart.lines;
    final hasItems  = lineCount > 0;

    final rail = _buildRailModel(context, lineCount, hasItems);

    return Scaffold(
      appBar: AppBar(title: const Text('Haldeki Bayi')),
      body: Row(
        children: [
          if (isWide)
            Theme( // seçili renkleri ve indicator’u özelleştir
              data: Theme.of(context).copyWith(
                navigationRailTheme: const NavigationRailThemeData(
                  indicatorColor: Color(0xFFEFF4EE),
                  indicatorShape: StadiumBorder(),
                  selectedIconTheme: IconThemeData(color: Color(0xFF2E7D32)),
                  selectedLabelTextStyle: TextStyle(
                    color: Color(0xFF2E7D32), fontWeight: FontWeight.w600),
                ),
              ),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return Scrollbar(
                    controller: _railScroll,
                    thumbVisibility: true,
                    child: SingleChildScrollView(
                      controller: _railScroll,
                      child: ConstrainedBox(
                        constraints: BoxConstraints(minHeight: constraints.maxHeight),
                        child: IntrinsicHeight(
                          child: NavigationRail(
                            labelType: NavigationRailLabelType.all,
                            minWidth: 92,
                            useIndicator: true,
                            groupAlignment: -1.0,
                            // ⬇️ ikonları küçük yap
                            unselectedIconTheme: const IconThemeData(size: 12),
                            selectedIconTheme: const IconThemeData(size: 12, color: Color(0xFF2E7D32)),
                            destinations: rail.destinations,
                            selectedIndex: rail.selectedIndex,
                            leading: const _RailHeader(title: 'Haldeki Bayi'),
                            onDestinationSelected: (i) {
                              final action = rail.actions[i];
                              switch (action.type) {
                                case _ActionType.toggle:
                                  setState(() {
                                    if (action.toggleKey == 'orders')  _ordersExpanded  = !_ordersExpanded;
                                    if (action.toggleKey == 'reports') _reportsExpanded = !_reportsExpanded;
                                  });
                                  break;
                                case _ActionType.route:
                                  if (action.route != null) context.go(action.route!);
                                  break;
                              }
                            },
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            )
          else
            const SizedBox(),
          Expanded(child: widget.child),
        ],
      ),
      // mobil alt menü aynı
      bottomNavigationBar: isWide ? null : NavigationBar(
        selectedIndex: widget.currentIndex.clamp(0, 4),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.store_mall_directory_outlined), selectedIcon: Icon(Icons.store_mall_directory), label: 'Market'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'Sepet'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Siparişler'),
          NavigationDestination(icon: Icon(Icons.account_circle_outlined), selectedIcon: Icon(Icons.account_circle), label: 'Profil'),
        ],
        onDestinationSelected: (i) {
          switch (i) {
            case 0: context.go('/dashboard'); break;
            case 1: context.go('/market'); break;
            case 2: context.go('/cart'); break;
            case 3: context.go('/orders'); break; // mobilde içeride sekme
            case 4: context.go('/suppliers'); break;
          }
        },
      ),
    );
  }

  // ---------- RAIL MODEL ----------
  _RailBuild _buildRailModel(BuildContext context, int lineCount, bool hasItems) {
    final actions = <_Action>[];
    final dests   = <NavigationRailDestination>[];
    int selectedIndex = 0;
    final path = GoRouterState.of(context).uri.toString();

    int add({
      required Widget icon,
      required Widget selectedIcon,
      required Widget label,
      required _Action action,
      required bool selected,
    }) {
      actions.add(action);
      dests.add(NavigationRailDestination(icon: icon, selectedIcon: selectedIcon, label: label));
      final idx = dests.length - 1;
      if (selected) selectedIndex = idx;
      return idx;
    }

    // helper’lar
    const indentIconPad  = EdgeInsets.only(left: 7);
    const indentLabelPad = EdgeInsets.only(left: 8);
    Widget chevronLabel(String text, bool expanded) => Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(text),
        const SizedBox(width: 6),
        AnimatedRotation(
          turns: expanded ? 0.5 : 0.0,
          duration: const Duration(milliseconds: 150),
          child: const Icon(Icons.expand_more, size: 10),
        ),
      ],
    );
    Widget dotIcon() => const Padding(
      padding: indentIconPad,
      child: Icon(Icons.circle, size: 6),
    );
    Widget indentedText(String t) => Padding(
      padding: indentLabelPad,
      child: Text(t),
    );

    // 1) Ana Sayfa
    add(
      icon: const Icon(Icons.dashboard_outlined),
      selectedIcon: const Icon(Icons.dashboard),
      label: const Text('Ana Sayfa'),
      action: const _Action.route('/dashboard'),
      selected: path.startsWith('/dashboard'),
    );

    // 2) Siparişler (toggle + alt maddeler)
    final ordersSelected = path.startsWith('/orders');
    add(
      icon: const Icon(Icons.receipt_long_outlined),
      selectedIcon: const Icon(Icons.receipt_long),
      label: chevronLabel('Siparişler', _ordersExpanded),
      action: const _Action.toggle('orders'),
      selected: ordersSelected && !_ordersExpanded,
    );
    if (_ordersExpanded) {
      add(
        icon: dotIcon(),
        selectedIcon: dotIcon(),
        label: indentedText('Aktif Siparişler'),
        action: const _Action.route('/orders'),
        selected: path.startsWith('/orders'),
      );
      add(
        icon: dotIcon(),
        selectedIcon: dotIcon(),
        label: indentedText('Teslim Edilenler'),
        action: const _Action.route('/orders/delivered'),
        selected: path.startsWith('/orders/delivered'),
      );
    }

    // 3) Müşteriler
    add(
      icon: const Icon(Icons.people_outline),
      selectedIcon: const Icon(Icons.people),
      label: const Text('Müşteriler'),
      action: const _Action.route('/customers'),
      selected: path.startsWith('/customers'),
    );

    // 4) Kuryeler
    add(
      icon: const Icon(Icons.motorcycle_outlined),
      selectedIcon: const Icon(Icons.motorcycle),
      label: const Text('Kuryeler'),
      action: const _Action.route('/couriers'),
      selected: path.startsWith('/couriers'),
    );

   
    // 6) Kasa
    add(
      icon: const Icon(Icons.point_of_sale_outlined),
      selectedIcon: const Icon(Icons.point_of_sale),
      label: const Text('Kasa'),
      action: const _Action.route('/cashbox'),
      selected: path.startsWith('/cashbox'),
    );

    // 7) Duyurular
    add(
      icon: const Icon(Icons.campaign_outlined),
      selectedIcon: const Icon(Icons.campaign),
      label: const Text('Duyurular'),
      action: const _Action.route('/announcements'),
      selected: path.startsWith('/announcements'),
    );

    // 8) Raporlar (toggle + alt maddeler)
    final reportsSelected = path.startsWith('/reports');
    add(
      icon: const Icon(Icons.insert_chart_outlined),
      selectedIcon: const Icon(Icons.insert_chart),
      label: chevronLabel('Raporlar', _reportsExpanded),
      action: const _Action.toggle('reports'),
      selected: reportsSelected && !_reportsExpanded,
    );
    if (_reportsExpanded) {
      add(
        icon: dotIcon(),
        selectedIcon: dotIcon(),
        label: indentedText('Kasa Raporu'),
        action: const _Action.route('/reports/cash'),
        selected: path.startsWith('/reports/cash'),
      );
      add(
        icon: dotIcon(),
        selectedIcon: dotIcon(),
        label: indentedText('Müşteri Raporu'),
        action: const _Action.route('/reports/customers'),
        selected: path.startsWith('/reports/customers'),
      );
      add(
        icon: dotIcon(),
        selectedIcon: dotIcon(),
        label: indentedText('Kurye Raporu'),
        action: const _Action.route('/reports/couriers'),
        selected: path.startsWith('/reports/couriers'),
      );
      add(
        icon: dotIcon(),
        selectedIcon: dotIcon(),
        label: indentedText('Sipariş Raporu'),
        action: const _Action.route('/reports/orders'),
        selected: path.startsWith('/reports/orders'),
      );
    }

    // 9) Ayarlar
    add(
      icon: const Icon(Icons.settings_outlined),
      selectedIcon: const Icon(Icons.settings),
      label: const Text('Ayarlar'),
      action: const _Action.route('/settings'),
      selected: path.startsWith('/settings'),
    );

    // 10) Fiyat Listesi (sepet/badge)
    add(
      icon: _BadgeIcon(
        count: lineCount,
        child: Icon(Icons.price_change_rounded, color: hasItems ? Colors.red : null),
      ),
      selectedIcon: _BadgeIcon(
        count: lineCount,
        child: Icon(Icons.price_change_rounded, color: hasItems ? Colors.red : null),
      ),
      label: const Text('Fiyat Listesi'),
      action: const _Action.route('/cart'),
      selected: path.startsWith('/cart'),
    );

    // 11) Profil (en altta)
    add(
      icon: const Icon(Icons.account_circle_outlined),
      selectedIcon: const Icon(Icons.account_circle),
      label: const Text('Profil'),
      action: const _Action.route('/suppliers'),
      selected: path.startsWith('/suppliers'),
    );

    return _RailBuild(dests, actions, selectedIndex);
  }
}

// --- yardımcı yapılar ---
class _RailBuild {
  final List<NavigationRailDestination> destinations;
  final List<_Action> actions;
  final int selectedIndex;
  _RailBuild(this.destinations, this.actions, this.selectedIndex);
}

enum _ActionType { route, toggle }

class _Action {
  final _ActionType type;
  final String? route;
  final String? toggleKey; // 'orders' | 'reports'
  const _Action._(this.type, this.route, this.toggleKey);
  const _Action.route(this.route) : type = _ActionType.route, toggleKey = null;
  const _Action.toggle(this.toggleKey) : type = _ActionType.toggle, route = null;
}

class _RailHeader extends StatelessWidget {
  const _RailHeader({required this.title, this.logoAsset});
  final String title;
  final String? logoAsset;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final avatar = Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(color: cs.primary.withOpacity(.12), shape: BoxShape.circle),
      alignment: Alignment.center,
      child: logoAsset == null
          ? Icon(Icons.apps, color: cs.primary)
          : ClipOval(child: Image.asset(logoAsset!, width: 44, height: 44, fit: BoxFit.cover)),
    );

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Column(
        children: [
          avatar,
          const SizedBox(height: 8),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

/// Basit badge
class _BadgeIcon extends StatelessWidget {
  final int count;
  final Widget child;
  const _BadgeIcon({required this.count, required this.child});

  @override
  Widget build(BuildContext context) {
    if (count <= 0) return child;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        child,
        Positioned(
          right: -6,
          top: -4,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
            decoration: const BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
            child: Text(
              count.toString(),
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold, height: 1),
            ),
          ),
        ),
      ],
    );
  }
}
