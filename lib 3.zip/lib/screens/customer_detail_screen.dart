import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

// Basit model
class CustomerLite {
  final int id;
  final String name;
  final String phone;
  final bool isOpen;
  CustomerLite({required this.id, required this.name, required this.phone, required this.isOpen});
}

class CustomerDetailScreen extends StatefulWidget {
  final int id;
  final CustomerLite? initial;
  const CustomerDetailScreen({super.key, required this.id, this.initial});

  @override
  State<CustomerDetailScreen> createState() => _CustomerDetailScreenState();
}

class _CustomerDetailScreenState extends State<CustomerDetailScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _nameC;
  late TextEditingController _phoneC;
  late TextEditingController _kmOpeningC;
  late TextEditingController _kmPriceC;

  bool _isOpen = true;
  bool _hasPickupPhoto = false;
  bool _hasDeliveryPhoto = false;
  String _commissionType = 'km';

  late final TabController _tabs;
bool _payReceiver = false; // Alıcı Ödeme
bool _paySender   = false; // Gönderici Ödeme
bool _payAdmin    = false; // Yönetici Ödeme
  @override
  void initState() {
    super.initState();
    final c = widget.initial ??
        CustomerLite(
          id: widget.id,
          name: 'CENTER VEGA MARKET **',
          phone: '(538) 328 40 94',
          isOpen: true,
        );
    _nameC = TextEditingController(text: c.name);
    _phoneC = TextEditingController(text: c.phone);
    _kmOpeningC = TextEditingController(text: '100,00');
    _kmPriceC = TextEditingController(text: '15,00');
    _isOpen = c.isOpen;

    _tabs = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _nameC.dispose();
    _phoneC.dispose();
    _kmOpeningC.dispose();
    _kmPriceC.dispose();
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: cs.surface,
      appBar: AppBar(
        title: const Text('Müşteriler'),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: FilledButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.add),
              label: const Text('Sipariş Ekle'),
            ),
          ),
          TextButton(onPressed: () {}, child: const Text('Çıkış Yap')),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Breadcrumb
          Padding(
            padding: const EdgeInsets.fromLTRB(3, 12, 16, 4),
            child: Wrap(
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: 6,
              children: [
                InkWell(
                  onTap: () => context.go('/customers'),
                  child: Text('Müşteriler',
                      style: TextStyle(
                          color: cs.primary,
                          decoration: TextDecoration.underline)),
                ),
                const Text('/'),
                Text(_nameC.text,
                    style: const TextStyle(fontWeight: FontWeight.w700)),
              ],
            ),
          ),

          // Sekme şeridi (tasarımdaki gibi içerikte, sol hizalı, ince underline)
          Padding(
            padding: const EdgeInsets.fromLTRB(3, 4, 16, 0),
            child: Theme(
              data: Theme.of(context).copyWith(
                tabBarTheme: TabBarTheme(
                  labelColor: cs.onSurface,
                  unselectedLabelColor: cs.onSurfaceVariant,
                  indicator: UnderlineTabIndicator(
                    borderSide: BorderSide(color: cs.primary, width: 2),
                  ),
                  labelPadding: const EdgeInsets.symmetric(horizontal: 12),
                ),
              ),
              child: TabBar(
                controller: _tabs,
                isScrollable: true,
                tabs: const [
                  Tab(text: 'Genel Bilgiler'),
                  Tab(text: 'Adresler'),
                  Tab(text: 'Siparişler'),
                  Tab(text: 'Kuryeler'),
                  Tab(text: 'Şifre Değiştir'),
                ],
              ),
            ),
          ),

          const SizedBox(height: 8),

          // İçerik
          Expanded(
            child: TabBarView(
              controller: _tabs,
              children: [
                _generalTab(context),
                _cardPlaceholder(context, 'Adresler',
                    'Adres listesi ve yeni adres ekleme burada olacak.'),
                _cardPlaceholder(context, 'Siparişler',
                    'Müşteriye ait geçmiş siparişler tablosu burada olacak.'),
                _cardPlaceholder(context, 'Kuryeler',
                    'Bu müşteriye atanan kuryeler listesi burada olacak.'),
                _passwordTab(context),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------- GENEL BİLGİLER (tasarıma sadık tek kolon etiket/alan) ----------

Widget _generalTab(BuildContext context) {
  final cs = Theme.of(context).colorScheme;

  return LayoutBuilder(
    builder: (context, cons) {
      return SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        child: ConstrainedBox(
          // Kart en az görünür alan kadar geniş olsun (sol boşluk kalmasın)
          constraints: BoxConstraints(minWidth: cons.maxWidth),
          child: Card(
            elevation: 0,
            color: cs.surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: BorderSide(color: cs.outlineVariant),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
              // Kutulu textfield teması
              child: Theme(
                data: Theme.of(context).copyWith(
                  inputDecorationTheme: const InputDecorationTheme(
                    isDense: true,
                    border: OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.green, width: 1.5),
                    ),
                  ),
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      _sectionHeader('Genel Bilgiler'),
                      const SizedBox(height: 12),

                      // Satır satır: sol etiket, sağ alan
                      _row(
                        label: 'ADI *',
                        field: TextFormField(
                          controller: _nameC,
                          validator: (v) =>
                              (v == null || v.trim().isEmpty) ? 'Zorunlu' : null,
                        ),
                      ),
                      // Checkboxlar solda, etiketle yan yana
                      _row(
                        label: 'SİPARİŞ VERME AÇIK MI?',
                        isCheckbox: true,
                        checkboxValue: _isOpen,
                        onCheckboxChanged: (v) => setState(() => _isOpen = v ?? false),
                      ),
                      _row(
                        label: 'ALIŞ FOTOĞRAFI VAR MI?',
                        isCheckbox: true,
                        checkboxValue: _hasPickupPhoto,
                        onCheckboxChanged: (v) =>
                            setState(() => _hasPickupPhoto = v ?? false),
                      ),
                      _row(
                        label: 'TESLİM FOTOĞRAFI VAR MI?',
                        isCheckbox: true,
                        checkboxValue: _hasDeliveryPhoto,
                        onCheckboxChanged: (v) =>
                            setState(() => _hasDeliveryPhoto = v ?? false),
                      ),
                      _row(
                        label: 'TELEFON NUMARASI',
                        help: 'GSM formatında giriniz',
                        field: TextFormField(
                          controller: _phoneC,
                          decoration: const InputDecoration(hintText: '(5xx) xxx xx xx'),
                        ),
                      ),

                      const SizedBox(height: 16),
                      _sectionHeader('Çalışma Şekli'),
                      const SizedBox(height: 12),

                      _row(
                        label: 'KOMİSYON HESAP TİPİ',
                        help: 'Kilometre ya da sabit',
                        field: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            RadioListTile<String>(
                              dense: true,
                              contentPadding: EdgeInsets.zero,
                              value: 'km',
                              groupValue: _commissionType,
                              title: const Text('Kilometre Hesabı'),
                              onChanged: (v) => setState(() => _commissionType = v!),
                            ),
                            RadioListTile<String>(
                              dense: true,
                              contentPadding: EdgeInsets.zero,
                              value: 'fixed',
                              groupValue: _commissionType,
                              title: const Text('Sabit Fiyat'),
                              onChanged: (v) => setState(() => _commissionType = v!),
                            ),
                          ],
                        ),
                      ),
                      _row(
                        label: 'KİLOMETRE AÇILIŞ ÜCRETİ',
                        help: 'İlk km için',
                        field: TextFormField(
                          controller: _kmOpeningC,
                          textAlign: TextAlign.right,
                          decoration: const InputDecoration(hintText: '0,00'),
                        ),
                      ),
                      _row(
                        label: 'KİLOMETRE ÜCRETİ',
                        help: 'Her km',
                        field: TextFormField(
                          controller: _kmPriceC,
                          textAlign: TextAlign.right,
                          decoration: const InputDecoration(hintText: '0,00'),
                        ),
                      ),

                      // Ödeme yöntemi (sağda 3 checkbox yatay)
                      _row(
                        label: 'ÖDEME YÖNTEMİ',
                        help: 'Kim ödeyecek',
                        field: Wrap(
                          spacing: 24,
                          runSpacing: 8,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Checkbox(
                                  value: _payReceiver,
                                  onChanged: (v) => setState(() => _payReceiver = v ?? false),
                                ),
                                const Text('Alıcı Ödeme'),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Checkbox(
                                  value: _paySender,
                                  onChanged: (v) => setState(() => _paySender = v ?? false),
                                ),
                                const Text('Gönderici Ödeme'),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Checkbox(
                                  value: _payAdmin,
                                  onChanged: (v) => setState(() => _payAdmin = v ?? false),
                                ),
                                const Text('Yönetici Ödeme'),
                              ],
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),
                      Row(
                        children: [
                          const Spacer(),
                          OutlinedButton(onPressed: () {}, child: const Text('Vazgeç')),
                          const SizedBox(width: 8),
                          FilledButton(
                            onPressed: () {
                              if (_formKey.currentState?.validate() ?? false) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Kaydedildi')),
                                );
                              }
                            },
                            child: const Text('Kaydet'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    },
  );
}

  // ---------- ŞİFRE DEĞİŞTİR ----------
  Widget _passwordTab(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final pass1 = TextEditingController();
    final pass2 = TextEditingController();

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: Card(
            elevation: 0,
            color: cs.surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: BorderSide(color: cs.outlineVariant),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionHeader('Şifre Değiştir'),
                  const SizedBox(height: 12),
                  _row(
                    label: 'Yeni Şifre',
                    field: TextField(
                      controller: pass1,
                      obscureText: true,
                      decoration: const InputDecoration(isDense: true),
                    ),
                  ),
                  _row(
                    label: 'Yeni Şifre (Tekrar)',
                    field: TextField(
                      controller: pass2,
                      obscureText: true,
                      decoration: const InputDecoration(isDense: true),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerRight,
                    child: FilledButton(
                      onPressed: () {
                        if (pass1.text.isEmpty || pass1.text != pass2.text) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Şifreler eşleşmiyor.')),
                          );
                          return;
                        }
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Şifre güncellendi.')),
                        );
                      },
                      child: const Text('Kaydet'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ---------- Ortak yardımcılar ----------
  Widget _sectionHeader(String title) => Row(
        children: [
          Container(
            width: 4,
            height: 16,
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Text(title, style: Theme.of(context).textTheme.titleMedium),
        ],
      );

  /// Görseldeki gibi: solda dar etiket sütunu, sağda alan.
  /// labelWidth ile sol sütun genişliği sabit.
Widget _row({
  String? label,
  Widget? field,
  String? help,
  double labelWidth = 260,
  bool isCheckbox = false,
  bool? checkboxValue,
  ValueChanged<bool?>? onCheckboxChanged,
}) {
  final helpIcon = help == null
      ? const SizedBox.shrink()
      : Tooltip(
          message: help,
          child: const Padding(
            padding: EdgeInsets.only(left: 6),
            child: Icon(Icons.info_outline, size: 16),
          ),
        );

  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Sol tarafta label + help ikonu
        SizedBox(
          width: labelWidth,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Flexible(
                child: Text(
                  label ?? '',
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ),
              helpIcon,
            ],
          ),
        ),

        const SizedBox(width: 12),

        // Sağda checkbox veya alan
        if (isCheckbox)
          Checkbox(
            value: checkboxValue ?? false,
            onChanged: onCheckboxChanged,
          )
        else
          Expanded(child: field ?? const SizedBox()),
      ],
    ),
  );
}

Widget _cardPlaceholder(BuildContext context, String title, String text) {
  final cs = Theme.of(context).colorScheme;
  return LayoutBuilder(
    builder: (context, cons) {
      return SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        child: ConstrainedBox(
          constraints: BoxConstraints(minWidth: cons.maxWidth),
          child: Card(
            elevation: 0,
            color: cs.surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: BorderSide(color: cs.outlineVariant),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionHeader(title),
                  const SizedBox(height: 12),
                  Text(text, style: TextStyle(color: cs.onSurfaceVariant)),
                ],
              ),
            ),
          ),
        ),
      );
    },
  );
}
}
