import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:haldeki_admin_web/models/courier_models.dart';
import 'package:haldeki_admin_web/models/courier_repo.dart';

class CourierDetailScreen extends StatefulWidget {
  final int id;
  final CourierLite? initial;

  const CourierDetailScreen({
    super.key,
    required this.id,
    this.initial,
  });

  @override
  State<CourierDetailScreen> createState() => _CourierDetailScreenState();
}

class _CourierDetailScreenState extends State<CourierDetailScreen> {
  // state
  late String _name;
  late String _phone;
  late String _plate;
  late String _bankOwner;
  late String _iban;
  late double _balance;
  bool _deleted = false;

  // forms
  final _editForm = GlobalKey<FormState>();
  late final TextEditingController _nameC;
  late final TextEditingController _phoneC;
  late final TextEditingController _plateC;
  late final TextEditingController _bankOwnerC;
  late final TextEditingController _ibanC;

  final _pass1 = TextEditingController();
  final _pass2 = TextEditingController();

  @override
  void initState() {
    super.initState();

    // 1) liste ekranından geldiyse onu kullan
    CourierLite? c = widget.initial;

    // 2) değilse repo'dan id ile çek
    c ??= CourierRepository.instance.getById(widget.id);

    // 3) yine yoksa boş değerlerle başla
    c ??= CourierLite(id: widget.id, name: '', phone: '', balance: 0, deleted: false);

    _name = c.name;
    _phone = c.phone;
    _balance = c.balance;
    _deleted = c.deleted;

    // MOCK alanlar
    _plate = '01A7U421';
    _bankOwner = _name.isEmpty ? '' : _name;
    _iban = 'TR6700062000026900006814734';

    _nameC = TextEditingController(text: _name);
    _phoneC = TextEditingController(text: _phone);
    _plateC = TextEditingController(text: _plate);
    _bankOwnerC = TextEditingController(text: _bankOwner);
    _ibanC = TextEditingController(text: _iban);
  }

  @override
  void dispose() {
    _nameC.dispose();
    _phoneC.dispose();
    _plateC.dispose();
    _bankOwnerC.dispose();
    _ibanC.dispose();
    _pass1.dispose();
    _pass2.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Text('Kurye Detay - ${(_name.isEmpty ? '—' : _name).split(' ').take(2).join(' ')}'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
            onPressed: () => context.go('/couriers'),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: FilledButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.add),
              label: const Text('Sipariş Ekle'),
            ),
          ),
          TextButton.icon(
            onPressed: () => context.go('/couriers'),
            icon: const Icon(Icons.arrow_back),
            label: const Text('Geri Dön'),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          if (_deleted)
            Container(
              width: double.infinity,
              color: Colors.red.withOpacity(.08),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Text(
                'Bu kurye silinmiştir',
                style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.w600),
              ),
            ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // SOL KART
                  SizedBox(
                    width: 220,
                    child: Card(
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                        side: BorderSide(color: cs.outlineVariant),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            const CircleAvatar(
                              radius: 38,
                              backgroundColor: Color(0xFFECEFF1),
                              child: Icon(Icons.delivery_dining, size: 40),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              '${_balance.toStringAsFixed(2)} ₺',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleLarge
                                  ?.copyWith(fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: 4),
                            Text('Bakiye', style: TextStyle(color: cs.onSurfaceVariant)),
                            const Spacer(),
                            FilledButton.tonalIcon(
                              onPressed: () => setState(() => _deleted = !_deleted),
                              icon: Icon(_deleted ? Icons.undo : Icons.delete_outline),
                              label: Text(_deleted ? 'Geri Al' : 'Kuryeyi Sil'),
                              style: FilledButton.styleFrom(
                                foregroundColor: _deleted ? null : Colors.red.shade700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),

                  // SAĞ PANEL (DefaultTabController)
                  Expanded(
                    child: DefaultTabController(
                      length: 6,
                      child: Card(
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                          side: BorderSide(color: cs.outlineVariant),
                        ),
                        child: Column(
                          children: [
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Theme(
                                data: Theme.of(context).copyWith(
                                  tabBarTheme: TabBarTheme(
                                    labelColor: cs.onSurface,
                                    unselectedLabelColor: cs.onSurfaceVariant,
                                    indicator: UnderlineTabIndicator(
                                      borderSide: BorderSide(color: cs.primary, width: 2),
                                    ),
                                    labelPadding: const EdgeInsets.symmetric(horizontal: 12),
                                  ),
                                ),
                                child: const TabBar(
                                  isScrollable: true,
                                  tabs: [
                                    Tab(text: 'Genel Bilgiler'),
                                    Tab(text: 'Profil Düzenle'),
                                    Tab(text: 'Belgeler'),
                                    Tab(text: 'Hesap Özeti'),
                                    Tab(text: 'Cüzdan Özeti'),
                                    Tab(text: 'Şifre Değiştir'),
                                  ],
                                ),
                              ),
                            ),
                            const Divider(height: 1),
                            Expanded(
                              child: TabBarView(
                                children: [
                                  _tabGenel(context),
                                  _tabProfilDuzenle(context),
                                  _tabBelgeler(context),
                                  _tabHesapOzeti(context),
                                  _tabCuzdanOzeti(context),
                                  _tabSifre(context),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ---------- TABS (senin fonksiyonların aynı, kısalttım) ----------
  Widget _tabGenel(BuildContext context) { /* ... senin aynısı ... */ return SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Column(
      children: [
        _lr('ADI SOYADI', _name.isEmpty ? '—' : _name),
        _lr('TELEFON NUMARASI', _phone.isEmpty ? '—' : _phone, link: true),
        _lr('KAYIT TARİHİ', '—'),
        _lr('PLAKA', _plate),
        _lr('BANKA HESAP SAHİBİ AD SOYAD', _bankOwner, copy: true),
        _lr('IBAN NUMARASI', _iban, copy: true),
      ],
    ),
  ); }

  Widget _tabProfilDuzenle(BuildContext context) { /* ... senin aynısı ... */ return SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Form(
      key: _editForm,
      child: Column(
        children: [
          _editField('ADI *', _nameC, required: true),
          _editField('SOYADI', TextEditingController(), enabled: false),
          _editField('TELEFON NUMARASI *', _phoneC, required: true, hint: '(5xx) xxx xx xx'),
          _editField('PLAKA', _plateC),
          _editField('BANKA HESAP SAHİBİ AD SOYAD', _bankOwnerC),
          _editField('IBAN NUMARASI', _ibanC),
          const SizedBox(height: 8),
          Row(
            children: [
              const Spacer(),
              FilledButton(
                onPressed: () {
                  if (!(_editForm.currentState?.validate() ?? false)) return;
                  setState(() {
                    _name = _nameC.text.trim();
                    _phone = _phoneC.text.trim();
                    _plate = _plateC.text.trim();
                    _bankOwner = _bankOwnerC.text.trim();
                    _iban = _ibanC.text.trim();
                  });
                  ScaffoldMessenger.of(context)
                      .showSnackBar(const SnackBar(content: Text('Profil güncellendi.')));
                },
                child: const Text('Kaydet'),
              ),
            ],
          ),
        ],
      ),
    ),
  ); }

  Widget _tabBelgeler(BuildContext context) { /* ... senin aynısı ... */ return SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _subHeader('Kimlik Kartı'),
        const SizedBox(height: 8),
        _docCard(
          title: 'Ehliyet Resmi (Ön)',
          child: Container(
            width: 200, height: 130, clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceVariant,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Image.network('https://picsum.photos/seed/driver/400/260', fit: BoxFit.cover),
          ),
        ),
        const SizedBox(height: 12),
        TextButton.icon(onPressed: () {}, icon: const Icon(Icons.file_upload_outlined), label: const Text('Belge Yükle (PDF)')),
      ],
    ),
  ); }

  Widget _tabHesapOzeti(BuildContext context) { 
    final rows = const [
      ['Tarih', 'İşlem', 'Tutar'],
      ['24.07.2024 22:13:48', 'DENEME', '-200,00 ₺'],
    ];
    return _simpleTable(context, 'Hesap Özeti', rows);
  }

  Widget _tabCuzdanOzeti(BuildContext context) {
    final rows = const [
      ['Adı Soyadı', 'Tarih', 'Açıklama', 'Tutar'],
      ['CEZALI İŞLETME', '24.07.2024 22:13:48', 'DENEME', '-200,00 ₺'],
    ];
    return _simpleTable(context, 'Cüzdan Özeti', rows);
  }

  Widget _tabSifre(BuildContext context) { /* ... senin aynısı ... */ return SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Column(
      children: [
        if (_deleted)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text('(Bu kurye silinmiştir)', style: TextStyle(color: Colors.red.shade700)),
          ),
        _editField('Mevcut Şifre', TextEditingController(text: '123456'), enabled: false),
        _editField('Yeni Şifre', _pass1, obscure: true),
        _editField('Şifreyi Tekrar Giriniz', _pass2, obscure: true),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton(
            onPressed: () {
              if (_pass1.text.isEmpty || _pass1.text != _pass2.text) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Şifreler eşleşmiyor.')));
                return;
              }
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Şifre güncellendi.')));
              _pass1.clear(); _pass2.clear();
            },
            child: const Text('Kaydet'),
          ),
        ),
      ],
    ),
  ); }

  // ---- helpers (senin mevcut fonksiyonların) ----
  Widget _lr(String label, String value, {bool link = false, bool copy = false}) { /* ... aynı ... */ 
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(width: 240, child: Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54))),
          const SizedBox(width: 8),
          Expanded(
            child: Row(
              children: [
                Flexible(child: link ? Text(value, style: const TextStyle(color: Colors.blue, decoration: TextDecoration.underline)) : Text(value)),
                if (copy) ...[
                  const SizedBox(width: 6),
                  IconButton(onPressed: () {}, icon: const Icon(Icons.copy_all_outlined, size: 18), tooltip: 'Kopyala', color: cs.onSurfaceVariant),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _editField(String label, TextEditingController controller, {bool required = false, String? hint, bool obscure = false, bool enabled = true}) { /* ... aynı ... */ 
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      child: Row(
        children: [
          SizedBox(
            width: 240,
            child: Row(
              children: [
                Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                const SizedBox(width: 6),
                Icon(Icons.info_outline, size: 16, color: cs.onSurfaceVariant),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextFormField(
              controller: controller,
              enabled: enabled,
              obscureText: obscure,
              validator: required ? (v) => (v == null || v.trim().isEmpty) ? 'Zorunlu' : null : null,
              decoration: InputDecoration(
                isDense: true,
                hintText: hint,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6),
                  borderSide: BorderSide(color: cs.outlineVariant),
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _subHeader(String text) { /* ... aynı ... */ 
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Container(width: 4, height: 16, margin: const EdgeInsets.only(right: 8), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(2))),
          Text(text, style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
    );
  }

  Widget _docCard({required String title, required Widget child}) { /* ... aynı ... */ 
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(border: Border.all(color: cs.outlineVariant), borderRadius: BorderRadius.circular(8)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        child,
        const SizedBox(height: 6),
        TextButton(onPressed: () {}, child: const Text('Görüntüle')),
      ]),
    );
  }

  Widget _simpleTable(BuildContext context, String title, List<List<String>> rows) { /* ... aynı ... */ 
    final cs = Theme.of(context).colorScheme;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _subHeader(title),
          const SizedBox(height: 8),
          DecoratedBox(
            decoration: BoxDecoration(border: Border.all(color: cs.outlineVariant), borderRadius: BorderRadius.circular(8)),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                headingRowHeight: 40,
                dataRowMinHeight: 44,
                dataRowMaxHeight: 50,
                columns: rows.first.map((h) => DataColumn(label: Text(h))).toList(),
                rows: rows.skip(1).map((r) => DataRow(cells: r.map((c) => DataCell(Text(c))).toList())).toList(),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(child: FilledButton.tonal(onPressed: () {}, child: const Text('1'))),
        ],
      ),
    );
  }
}
