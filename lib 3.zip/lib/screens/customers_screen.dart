import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:haldeki_admin_web/screens/customer_detail_screen.dart';

// --- MODEL ---
class Customer {
  final int id;
  final String name;
  final String phone;
  final String createdAt;
  final bool isOpen; // sipariş alma açık mı?

  Customer({
    required this.id,
    required this.name,
    required this.phone,
    required this.createdAt,
    required this.isOpen,
  });

  factory Customer.fromJson(Map<String, dynamic> j) => Customer(
        id: j['id'] as int,
        name: j['ad_soyad'] as String,
        phone: j['telefon'] as String,
        createdAt: j['kayit_tarihi'] as String,
        isOpen: (j['siparis_alma_durumu'] as String).toLowerCase().contains('açık'),
      );
}

// --- DUMMY DATA (ekrandaki görsele göre) ---
final List<Map<String, dynamic>> kDummyCustomersJson = [
  {"id":1987,"ad_soyad":"GFDGFDGFDGDF **","telefon":"(6456) 328 40 94","kayit_tarihi":"15.09.2025 14:12:21","siparis_alma_durumu":"Açık"},
  {"id":1967,"ad_soyad":"GFDGDFGDF 64","telefon":"(6456) 791 88 92","kayit_tarihi":"11.09.2025 11:08:16","siparis_alma_durumu":"Açık"},
  {"id":1965,"ad_soyad":"GDFGDF SHOP **","telefon":"(654645) 404 92 65493","kayit_tarihi":"11.09.2025 10:17:55","siparis_alma_durumu":"Açık"},
  {"id":1953,"ad_soyad":"6456 645 GDFGDFG **","telefon":"(456546) 254 94 44","kayit_tarihi":"07.09.2025 15:04:25","siparis_alma_durumu":"Açık"},
  {"id":1883,"ad_soyad":"6456 SHOP **","telefon":"(645645) 645 35 10","kayit_tarihi":"23.08.2025 15:08:19","siparis_alma_durumu":"Açık"},
  {"id":1868,"ad_soyad":"64564 MER645CAN **","telefon":"(654645) 645 44 35","kayit_tarihi":"21.08.2025 19:11:40","siparis_alma_durumu":"Açık"},
  {"id":1860,"ad_soyad":"6456 645 **","telefon":"(645645) 645 52 91","kayit_tarihi":"20.08.2025 10:03:35","siparis_alma_durumu":"Açık"},
  {"id":1857,"ad_soyad":"64564564 ETİKET","telefon":"(164523) 645 53 21","kayit_tarihi":"19.08.2025 15:49:49","siparis_alma_durumu":"Açık"},
  {"id":1853,"ad_soyad":"6456 645 645 **","telefon":"(64564) 645 95 07","kayit_tarihi":"09.08.2025 15:02:28","siparis_alma_durumu":"Açık"},
];

final List<Customer> kDummyCustomers =
    kDummyCustomersJson.map((e) => Customer.fromJson(e)).toList();

// --- UI EKRANI ---
class CustomersScreen extends StatefulWidget {
  const CustomersScreen({super.key});
  @override
  State<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  final TextEditingController _searchC = TextEditingController();
  late List<Customer> _all;
  late List<Customer> _filtered;

  @override
  void initState() {
    super.initState();
    _all      = List<Customer>.from(kDummyCustomers);
    _filtered = List<Customer>.from(_all);
  }

  void _applyFilter() {
    final q = _searchC.text.trim().toLowerCase();
    setState(() {
      if (q.isEmpty) {
        _filtered = List<Customer>.from(_all);
      } else {
        _filtered = _all.where((c) {
          return c.name.toLowerCase().contains(q) ||
                 c.phone.toLowerCase().contains(q) ||
                 c.id.toString().contains(q);
        }).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs   = Theme.of(context).colorScheme;
    final isWide = MediaQuery.of(context).size.width > 900;

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: Padding(
    padding: const EdgeInsets.only(top: 16, right: 16, bottom: 16),
 
        child: Column(
             crossAxisAlignment: CrossAxisAlignment.start, // ⬅️ kritik: solda hizala
 
          children: [
            // Başlık + "Yeni Müşteri Ekle"

            Row(
              children: [
                Text('Müşteriler', style: Theme.of(context).textTheme.headlineSmall),
                const Spacer(),
                FilledButton.icon(
                  onPressed: () {/* yeni müşteri formuna git */},
                  icon: const Icon(Icons.person_add_alt_1),
                  label: const Text('Yeni Müşteri Ekle'),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Üst araç çubuğu: Arama + Filtrele
            Row(
              children: [
                Text('Müşteriler', style: Theme.of(context).textTheme.titleMedium),
                const Spacer(),
                SizedBox(
                  width: isWide ? 280 : 200,
                  child: TextField(
                    controller: _searchC,
                    decoration: const InputDecoration(
                      hintText: 'Ad Soyad / Telefon ile filtre',
                      prefixIcon: Icon(Icons.search),
                      isDense: true,
                    ),
                    onSubmitted: (_) => _applyFilter(),
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: _applyFilter,
                  icon: const Icon(Icons.tune),
                  label: const Text('Filtrele'),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // TABLO
           Expanded(
          child: LayoutBuilder(
            builder: (context, cons) {
              return DecoratedBox(
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                ),
                child: Scrollbar(
                  thumbVisibility: true,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: ConstrainedBox(
                      // ⬅️ tablo genişliği en az görünür alan kadar olsun
                      constraints: BoxConstraints(minWidth: cons.maxWidth),
                      child: SingleChildScrollView(
                        child: DataTable(
                          headingRowHeight: 44,
                          dataRowMinHeight: 50,
                          dataRowMaxHeight: 56,
                          horizontalMargin: 10,   // ⬅️ hücre sol/sağ iç boşluk
                          columnSpacing: 32,     // ⬅️ sütun arası boşluk
                          columns: const [
                            DataColumn(label: Text('NO')),
                            DataColumn(label: Text('ADI SOYADI')),
                            DataColumn(label: Text('TELEFON NUMARASI')),
                            DataColumn(label: Text('KAYIT TARİHİ')),
                            DataColumn(label: Text('SİPARİŞ ALMA AÇIK MI?')),
                            DataColumn(label: Text('')),
                          ],
                          rows: _filtered.map((c) => _rowOf(context, c)).toList(),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ), ],
        ),
      ),
    );
  }

  DataRow _rowOf(BuildContext context, Customer c) {
    final cs = Theme.of(context).colorScheme;
    return DataRow(
      cells: [
        DataCell(Text(c.id.toString(),
            style: const TextStyle(
              color: Colors.blue, // görselde mavi link tonu
              decoration: TextDecoration.underline,
            ))),
        DataCell(Text(c.name)),
        DataCell(SelectableText(c.phone)),
        DataCell(Text(c.createdAt)),
        DataCell(Align(
          alignment: Alignment.centerLeft,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: c.isOpen ? Colors.green.withOpacity(.1) : Colors.red.withOpacity(.1),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: c.isOpen ? Colors.green : Colors.red),
            ),
            child: Text(
              c.isOpen ? 'Açık' : 'Kapalı',
              style: TextStyle(
                color: c.isOpen ? Colors.green[700] : Colors.red[700],
                fontWeight: FontWeight.w600,
                fontSize: 12,
              ),
            ),
          ),
        )),
        DataCell(OutlinedButton(
        onPressed: () {
  final lite = CustomerLite(id: c.id, name: c.name, phone: c.phone, isOpen: c.isOpen);
  context.go('/customers/${c.id}', extra: lite);
},

          child: const Text('Detay'),
        )),
      ],
    );
  }
}
