import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:haldeki_admin_web/models/courier_models.dart';

class Courier {
  final int id;
  final String name;
  final String phone;
  final String createdAt;
  final bool isActive;

  // ⬇️ yeni alanlar
  final String? avatarUrl;     // ikon/avatara link
  final double balance;        // bakiye (₺)
  final int jobCount;          // iş sayısı
  final String approvalStatus; // onay durumu metni (örn: "Sipariş Onaylandı")

  Courier({
    required this.id,
    required this.name,
    required this.phone,
    required this.createdAt,
    required this.isActive,
    this.avatarUrl,
    this.balance = 0.0,
    this.jobCount = 0,
    this.approvalStatus = '—',
  });

  factory Courier.fromJson(Map<String, dynamic> j) => Courier(
        id: j['id'] as int,
        name: j['ad_soyad'] as String,
        phone: j['telefon'] as String,
        createdAt: j['kayit_tarihi'] as String,
        isActive: (j['durum'] as String).toLowerCase().contains('aktif'),
        avatarUrl: j['avatar'] as String?,
        balance: _toDouble(j['bakiye']),
        jobCount: (j['is_sayisi'] ?? 0) is int
            ? j['is_sayisi'] as int
            : int.tryParse('${j['is_sayisi']}') ?? 0,
        approvalStatus: (j['onay'] ?? '—').toString(),
      );

  static double _toDouble(dynamic v) {
    if (v is num) return v.toDouble();
    return double.tryParse('$v'.replaceAll(',', '.')) ?? 0.0;
  }
}

// --- ÖRNEK VERİ (yeni alanlarla) ---
final List<Map<String, dynamic>> kDummyCouriersJson = [
  {
    "id": 501,
    "ad_soyad": "Ali Çelik",
    "telefon": "(532) 111 22 33",
    "kayit_tarihi": "12.09.2025 10:12:11",
    "durum": "Aktif",
    "avatar": null,
    "bakiye": 0.06,
    "is_sayisi": 1,
    "onay": "Sipariş Alabilir"
  },
  {
    "id": 502,
    "ad_soyad": "Zeynep Kaya",
    "telefon": "(555) 444 55 66",
    "kayit_tarihi": "10.09.2025 14:05:45",
    "durum": "Aktif",
    "avatar": null,
    "bakiye": 120.50,
    "is_sayisi": 7,
    "onay": "Sipariş Alabilir"
  },
  {
    "id": 503,
    "ad_soyad": "Mert Yılmaz",
    "telefon": "(530) 987 65 43",
    "kayit_tarihi": "08.09.2025 09:20:00",
    "durum": "Pasif",
    "avatar": null,
    "bakiye": -32.75,
    "is_sayisi": 0,
    "onay": "Sipariş Alamaz"
  },
];

final List<Courier> kDummyCouriers =
    kDummyCouriersJson.map((e) => Courier.fromJson(e)).toList();

class CouriersScreen extends StatefulWidget {
  const CouriersScreen({super.key});

  @override
  State<CouriersScreen> createState() => _CouriersScreenState();
}

class _CouriersScreenState extends State<CouriersScreen> {
  final TextEditingController _searchC = TextEditingController();
  String _statusFilter = 'Tümü'; // Tümü / Aktif / Pasif

  late List<Courier> _all;
  late List<Courier> _filtered;

  @override
  void initState() {
    super.initState();
    _all = List<Courier>.from(kDummyCouriers);
    _filtered = List<Courier>.from(_all);
  }

  @override
  void dispose() {
    _searchC.dispose();
    super.dispose();
  }

  String _trLower(String s) =>
      s.replaceAll('I', 'ı').replaceAll('İ', 'i').toLowerCase();

  void _applyFilter() {
    final q = _trLower(_searchC.text.trim());
    setState(() {
      Iterable<Courier> list = _all;
      if (_statusFilter != 'Tümü') {
        final wantActive = _statusFilter == 'Aktif';
        list = list.where((c) => c.isActive == wantActive);
      }
      if (q.isNotEmpty) {
        list = list.where((c) =>
            _trLower(c.name).contains(q) ||
            _trLower(c.phone).contains(q) ||
            c.id.toString().contains(q));
      }
      _filtered = list.toList();
    });
  }

  void _clearSearch() {
    _searchC.clear();
    _applyFilter();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isWide = MediaQuery.of(context).size.width > 900;
    final screenW = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: cs.surface,
      body: Padding(
        padding:
            const EdgeInsets.only(top: 16, right: 16, bottom: 16), // soldan yok
        child: Column(
          children: [
            Row(
              children: [
                Text('Kuryeler',
                    style: Theme.of(context).textTheme.headlineSmall),
                const Spacer(),
                FilledButton.icon(
                  onPressed: () {/* yeni kurye formu */},
                  icon: const Icon(Icons.person_add_alt_1),
                  label: const Text('Yeni Kurye Ekle'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Text('Kuryeler',
                    style: Theme.of(context).textTheme.titleMedium),
                const Spacer(),
                DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _statusFilter,
                    items: const [
                      DropdownMenuItem(value: 'Tümü', child: Text('Tümü')),
                      DropdownMenuItem(value: 'Aktif', child: Text('Aktif')),
                      DropdownMenuItem(value: 'Pasif', child: Text('Pasif')),
                    ],
                    onChanged: (v) {
                      if (v == null) return;
                      _statusFilter = v;
                      _applyFilter();
                    },
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  width: isWide ? 280 : 200,
                  child: TextField(
                    controller: _searchC,
                    decoration: InputDecoration(
                      hintText: 'Ad Soyad / Telefon ile filtre',
                      prefixIcon: const Icon(Icons.search),
                      isDense: true,
                      suffixIcon: (_searchC.text.isEmpty)
                          ? null
                          : IconButton(
                              onPressed: _clearSearch,
                              icon: const Icon(Icons.close),
                              tooltip: 'Temizle',
                            ),
                    ),
                    onChanged: (_) => setState(() {}),
                    onSubmitted: (_) => _applyFilter(),
                  ),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: _applyFilter,
                  icon: const Icon(Icons.tune),
                  label: const Text('Filtrele'),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // TABLO
            Expanded(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: cs.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: cs.outlineVariant),
                ),
                child: _filtered.isEmpty
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Text('Kayıt bulunamadı',
                              style: TextStyle(color: cs.onSurfaceVariant)),
                        ),
                      )
                    : Scrollbar(
                        thumbVisibility: true,
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: ConstrainedBox(
                            constraints: BoxConstraints(minWidth: screenW),
                            child: SingleChildScrollView(
                              child: DataTable(
                                headingRowHeight: 42,
                                dataRowMinHeight: 48,
                                dataRowMaxHeight: 52,
                                horizontalMargin: 10,
                                columnSpacing: 28,
                                columns: const [
                                  DataColumn(label: Text('NO')),
                                  DataColumn(label: Text('')),// avatar
                                  DataColumn(label: Text('ADI SOYADI')),
                                  DataColumn(label: Text('TELEFON NUMARASI')),
                                  DataColumn(label: Text('BAKİYE')),
                                  DataColumn(label: Text('İŞ SAYISI')),
                                  DataColumn(label: Text('ONAY DURUMU')),
                                  DataColumn(label: Text('KAYIT TARİHİ')),
                                  DataColumn(label: Text('')),
                                ],
                                rows: _filtered.map(_rowOf).toList(),
                              ),
                            ),
                          ),
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openCourier(Courier c) {
    final lite = CourierLite(
      id: c.id,
      name: c.name,
      phone: c.phone,
      balance: c.balance,
      deleted: false,
    );
    context.go('/couriers/${c.id}', extra: lite);
  }
  DataRow _rowOf(Courier c) {
    final cs = Theme.of(context).colorScheme;
    final chipColor = c.isActive ? Colors.green : Colors.grey;
    final textColor =
        c.isActive ? Colors.green[700] : Colors.grey[700];

    return DataRow(
      cells: [
        // NO
        DataCell(
          InkWell(
            onTap: () => context.go('/couriers/${c.id}'),
            child: Text(
              c.id.toString(),
              style: const TextStyle(
                color: Colors.blue,
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ),
        // Avatar/Icon
        DataCell(_avatarCell(c)),
        // Ad Soyad
        DataCell(Text(c.name)),
        // Telefon
        DataCell(SelectableText(c.phone)),
        // Bakiye
        DataCell(Text(_formatTL(c.balance),
            style: TextStyle(
                color: c.balance < 0 ? Colors.red : cs.onSurface))),
        // İş Sayısı
        DataCell(Text('${c.jobCount}')),
        // Onay Durumu (chip)
        DataCell(_statusChip(c.approvalStatus)),
        // Kayıt Tarihi
        DataCell(Text(c.createdAt)),
        // Detay
        DataCell(
          OutlinedButton(
         //   onPressed: () => context.go('/couriers/${c.id}'),
              onPressed: () => _openCourier(c),
            child: const Text('Detay'),
          ),
        ),
      ],
    );
  }

  // --- küçük yardımcılar ---
  String _formatTL(double v) {
    final sign = v < 0 ? '-' : '';
    final abs = v.abs();
    return '$sign${abs.toStringAsFixed(2)} ₺';
  }

  Widget _avatarCell(Courier c) {
    final initials = _initials(c.name);
    if (c.avatarUrl != null && c.avatarUrl!.isNotEmpty) {
      return CircleAvatar(
        radius: 14,
        backgroundImage: NetworkImage(c.avatarUrl!),
      );
    }
    return CircleAvatar(
      radius: 14,
      child: Text(initials,
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
    );
  }

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts.first.characters.take(2).toString().toUpperCase();
    return (parts.first.characters.first + parts.last.characters.first)
        .toUpperCase();
  }

  Widget _statusChip(String status) {
    Color border;
    Color bg;
    Color fg;

    switch (status.toLowerCase()) {
      case 'Sipariş Alabilir':
     case 'Alabilir':
    
        border = Colors.green;
        bg = Colors.green.withOpacity(.08);
        fg = Colors.green[800]!;
        break;
      case 'bekliyor':
      case 'beklemede':
        border = Colors.orange;
        bg = Colors.orange.withOpacity(.08);
        fg = Colors.orange[800]!;
        break;
  
     case 'Sipariş Alamaz':
        case ' Alamaz':
        border = Colors.red;
        bg = Colors.red.withOpacity(.08);
        fg = Colors.red[800]!;
        break;
      default:
        border = Colors.grey;
        bg = Colors.grey.withOpacity(.08);
        fg = Colors.grey[800]!;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        border: Border.all(color: border),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(status,
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: fg)),
    );
  }
}
